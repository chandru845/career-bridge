<?php

declare(strict_types=1);

$path = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';

header('X-Powered-By: Studio PHP');

if ($path === '/api/ping') {
    header('Content-Type: application/json');
    echo json_encode(['message' => 'pong']);
    return;
}

header('Content-Type: text/html; charset=utf-8');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>PHP Hello</title>
    <style>
        body { font-family: sans-serif; margin: 4rem auto; max-width: 640px; text-align: center; }
        code { background: #f4f4f4; padding: 0.15rem 0.35rem; border-radius: 4px; }
    </style>
</head>
<body>
    <h1>Hello from the PHP!</h1>
    <p>Your server is up and running.</p>
    <p>Try calling <code>/api/ping</code> to receive a JSON response.</p>
</body>
</html>
