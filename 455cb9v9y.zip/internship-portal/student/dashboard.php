
<?php
session_start();
require_once '../config/database.php';

/*
|--------------------------------------------------------------------------
| CareerBridge - Student Dashboard
|--------------------------------------------------------------------------
| Features:
| 1. Student authentication
| 2. Application statistics
| 3. Recent applications
| 4. Latest internships
| 5. Profile completion
| 6. Responsive animated black/orange UI
|--------------------------------------------------------------------------
*/

// Authentication
if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit;
}

$userId = (int) $_SESSION['user_id'];

if (!isset($pdo) || !($pdo instanceof PDO)) {
    die('Database connection is unavailable. Check config/database.php.');
}

// Escape HTML output
function h($value): string
{
    return htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8');
}

// Check if a database table exists
function tableExists(PDO $pdo, string $table): bool
{
    $stmt = $pdo->prepare(
        "SELECT COUNT(*)
         FROM information_schema.tables
         WHERE table_schema = DATABASE()
         AND table_name = ?"
    );
    $stmt->execute([$table]);

    return (int)$stmt->fetchColumn() > 0;
}

// Check if a table has a column
function columnExists(PDO $pdo, string $table, string $column): bool
{
    $stmt = $pdo->prepare(
        "SELECT COUNT(*)
         FROM information_schema.columns
         WHERE table_schema = DATABASE()
         AND table_name = ?
         AND column_name = ?"
    );
    $stmt->execute([$table, $column]);

    return (int)$stmt->fetchColumn() > 0;
}

// Return a status CSS class
function statusClass(string $status): string
{
    switch (strtolower(trim($status))) {
        case 'selected':
            return 'selected';

        case 'shortlisted':
            return 'shortlisted';

        case 'interview':
            return 'interview';

        case 'rejected':
            return 'rejected';

        case 'under review':
        case 'pending':
        case 'applied':
        default:
            return 'pending';
    }
}

$user = [];
$student = [];
$applications = [];
$internships = [];

$totalApplications = 0;
$pendingApplications = 0;
$shortlistedApplications = 0;
$selectedApplications = 0;
$profileCompletion = 0;

$errorMessage = '';

try {
    // -------------------------------------------------------
    // 1. Get the logged-in user
    // -------------------------------------------------------
    $stmt = $pdo->prepare(
        "SELECT *
         FROM users
         WHERE id = ?
         LIMIT 1"
    );

    $stmt->execute([$userId]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC) ?: [];

    if (!$user) {
        session_destroy();
        header('Location: ../login.php');
        exit;
    }

    if (
        isset($user['role']) &&
        strtolower($user['role']) !== 'student'
    ) {
        header('Location: ../login.php');
        exit;
    }

    // -------------------------------------------------------
    // 2. Get student profile
    // -------------------------------------------------------
    $studentId = $userId;

    if (tableExists($pdo, 'students')) {
        $stmt = $pdo->prepare(
            "SELECT *
             FROM students
             WHERE user_id = ?
             LIMIT 1"
        );

        $stmt->execute([$userId]);
        $student = $stmt->fetch(PDO::FETCH_ASSOC) ?: [];

        // Use the actual student record ID for relationships
        if (!empty($student['id'])) {
            $studentId = (int)$student['id'];
        }
    }

    // -------------------------------------------------------
    // 3. Application statistics
    // -------------------------------------------------------
    if (
        tableExists($pdo, 'applications') &&
        columnExists($pdo, 'applications', 'student_id')
    ) {
        /*
         * The code assumes applications.student_id references
         * students.id. If your schema stores users.id instead,
         * change $studentId to $userId in these queries.
         */

        $stmt = $pdo->prepare(
            "SELECT COUNT(*)
             FROM applications
             WHERE student_id = ?"
        );

        $stmt->execute([$studentId]);
        $totalApplications = (int)$stmt->fetchColumn();

        $stmt = $pdo->prepare(
            "SELECT COUNT(*)
             FROM applications
             WHERE student_id = ?
             AND LOWER(status) IN
                 ('applied', 'pending', 'under review')"
        );

        $stmt->execute([$studentId]);
        $pendingApplications = (int)$stmt->fetchColumn();

        $stmt = $pdo->prepare(
            "SELECT COUNT(*)
             FROM applications
             WHERE student_id = ?
             AND LOWER(status) = 'shortlisted'"
        );

        $stmt->execute([$studentId]);
        $shortlistedApplications = (int)$stmt->fetchColumn();

        $stmt = $pdo->prepare(
            "SELECT COUNT(*)
             FROM applications
             WHERE student_id = ?
             AND LOWER(status) = 'selected'"
        );

        $stmt->execute([$studentId]);
        $selectedApplications = (int)$stmt->fetchColumn();

        // ---------------------------------------------------
        // 4. Recent applications
        // ---------------------------------------------------
        if (
            tableExists($pdo, 'internships') &&
            columnExists($pdo, 'applications', 'internship_id') &&
            columnExists($pdo, 'internships', 'id')
        ) {
            $hasLocation = columnExists(
                $pdo,
                'internships',
                'location'
            );

            $hasAppliedAt = columnExists(
                $pdo,
                'applications',
                'applied_at'
            );

            $locationField = $hasLocation
                ? 'i.location'
                : "'' AS location";

            $dateField = $hasAppliedAt
                ? 'a.applied_at'
                : "NULL AS applied_at";

            $stmt = $pdo->prepare(
                "SELECT a.id, a.status,
                        $dateField,
                        i.title,
                        $locationField
                 FROM applications a
                 LEFT JOIN internships i
                    ON i.id = a.internship_id
                 WHERE a.student_id = ?
                 ORDER BY a.id DESC
                 LIMIT 5"
            );

            $stmt->execute([$studentId]);
            $applications = $stmt->fetchAll(PDO::FETCH_ASSOC);
        }
    }

    // -------------------------------------------------------
    // 5. Latest internships
    // -------------------------------------------------------
    if (tableExists($pdo, 'internships')) {
        $hasLocation = columnExists(
            $pdo,
            'internships',
            'location'
        );

        $hasStipend = columnExists(
            $pdo,
            'internships',
            'stipend'
        );

        $locationField = $hasLocation
            ? 'location'
            : "'' AS location";

        $stipendField = $hasStipend
            ? 'stipend'
            : "'' AS stipend";

        $stmt = $pdo->query(
            "SELECT id, title,
                    $locationField,
                    $stipendField
             FROM internships
             ORDER BY id DESC
             LIMIT 4"
        );

        $internships = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // -------------------------------------------------------
    // 6. Calculate profile completion
    // -------------------------------------------------------
    $profileFields = ['phone', 'college', 'course', 'skills'];
    $completedFields = 0;
    $availableFields = 0;

    foreach ($profileFields as $field) {
        if (array_key_exists($field, $student)) {
            $availableFields++;

            if (trim((string)$student[$field]) !== '') {
                $completedFields++;
            }
        }
    }

    if ($availableFields > 0) {
        $profileCompletion = (int)round(
            ($completedFields / count($profileFields)) * 100
        );
    }

} catch (PDOException $e) {
    // Log technical details on the server, not in the page
    error_log('CareerBridge dashboard error: ' . $e->getMessage());

    $errorMessage =
        'Some dashboard information could not be loaded. Please check your database tables and relationships.';
}

$studentName = $user['name'] ?? 'Student';
$firstName = explode(' ', trim($studentName))[0] ?: 'Student';
$email = $user['email'] ?? '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Student Dashboard | CareerBridge</title>

    <style>
        :root {
            --bg: #090909;
            --surface: #141414;
            --surface2: #1c1c1c;
            --orange: #ff7900;
            --orange-light: #ffad5c;
            --text: #f8f8f8;
            --muted: #a2a2a2;
            --border: rgba(255,255,255,.09);
            --green: #39d6a0;
            --blue: #70aaff;
            --purple: #bd91ff;
            --red: #ff7777;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        html {
            scroll-behavior: smooth;
        }

        body {
            min-height: 100vh;
            color: var(--text);
            background:
                radial-gradient(
                    circle at 80% 0%,
                    rgba(255,121,0,.10),
                    transparent 32%
                ),
                var(--bg);
            font-family: "Segoe UI", Arial, sans-serif;
        }

        a {
            color: inherit;
            text-decoration: none;
        }

        .layout {
            min-height: 100vh;
        }

        /* SIDEBAR */

        .sidebar {
            position: fixed;
            inset: 0 auto 0 0;
            z-index: 100;
            width: 250px;
            padding: 27px 18px;
            background: rgba(15,15,15,.97);
            border-right: 1px solid var(--border);
            display: flex;
            flex-direction: column;
            animation: slideIn .65s ease both;
        }

        .brand {
            display: flex;
            align-items: center;
            gap: 11px;
            margin: 0 0 38px 7px;
            font-size: 21px;
            font-weight: 800;
        }

        .brand-icon {
            width: 40px;
            height: 40px;
            display: grid;
            place-items: center;
            color: #111;
            border-radius: 12px;
            background: linear-gradient(
                135deg,
                var(--orange-light),
                var(--orange)
            );
            box-shadow: 0 0 25px rgba(255,121,0,.25);
        }

        .brand-name span {
            color: var(--orange);
        }

        .nav-label {
            color: #777;
            padding: 0 12px;
            margin-bottom: 13px;
            font-size: 10px;
            font-weight: 800;
            letter-spacing: 2px;
        }

        .nav-links {
            display: grid;
            gap: 8px;
        }

        .nav-link {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 13px 14px;
            color: #aaa;
            border: 1px solid transparent;
            border-radius: 12px;
            font-size: 13px;
            transition: .3s ease;
        }

        .nav-icon {
            width: 24px;
            text-align: center;
            font-size: 18px;
        }

        .nav-link:hover,
        .nav-link.active {
            color: white;
            background: rgba(255,121,0,.12);
            border-color: rgba(255,121,0,.2);
            transform: translateX(4px);
        }

        .nav-link.active {
            box-shadow: inset 3px 0 var(--orange);
        }

        .sidebar-bottom {
            margin-top: auto;
        }

        .tip-card {
            padding: 17px;
            margin-bottom: 20px;
            border-radius: 15px;
            background: linear-gradient(
                140deg,
                #2a190c,
                #17130f
            );
            border: 1px solid rgba(255,121,0,.2);
        }

        .tip-card h3 {
            font-size: 13px;
            margin-bottom: 8px;
        }

        .tip-card p {
            color: var(--muted);
            font-size: 11px;
            line-height: 1.7;
        }

        .logout {
            display: block;
            padding: 12px;
            color: #ff8585;
            border: 1px solid rgba(255,100,100,.18);
            border-radius: 11px;
            text-align: center;
            font-size: 13px;
            transition: .25s;
        }

        .logout:hover {
            background: rgba(255,80,80,.1);
        }

        /* MAIN */

        .main {
            width: calc(100% - 250px);
            margin-left: 250px;
            padding: 28px 35px 35px;
        }

        .topbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 20px;
            margin-bottom: 32px;
            animation: fadeDown .7s ease both;
        }

        .breadcrumb {
            color: var(--muted);
            margin-bottom: 8px;
            font-size: 12px;
        }

        .breadcrumb span {
            color: var(--orange);
        }

        .page-title {
            font-size: clamp(23px, 3vw, 31px);
            letter-spacing: -.8px;
        }

        .page-title span {
            color: var(--orange);
        }

        .top-right {
            display: flex;
            align-items: center;
            gap: 13px;
        }

        .date-box {
            padding: 10px 13px;
            color: #bbb;
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: 10px;
            font-size: 12px;
        }

        .avatar {
            width: 44px;
            height: 44px;
            display: grid;
            place-items: center;
            color: #111;
            border-radius: 14px;
            font-weight: 800;
            background: linear-gradient(
                135deg,
                var(--orange-light),
                var(--orange)
            );
            box-shadow: 0 5px 20px rgba(255,121,0,.2);
        }

        /* WELCOME BANNER */

        .welcome {
            position: relative;
            overflow: hidden;
            padding: 30px;
            margin-bottom: 30px;
            border-radius: 22px;
            border: 1px solid rgba(255,121,0,.25);
            background: linear-gradient(
                115deg,
                #28170a,
                #17120e 60%,
                #111
            );
            animation: fadeUp .7s .1s ease both;
        }

        .welcome::before {
            content: "";
            position: absolute;
            width: 230px;
            height: 230px;
            top: -110px;
            right: 10%;
            border-radius: 50%;
            background: rgba(255,121,0,.17);
            filter: blur(65px);
            animation: pulse 4s ease-in-out infinite;
        }

        .welcome::after {
            content: "";
            position: absolute;
            right: 5%;
            bottom: -100px;
            width: 160px;
            height: 160px;
            border: 1px solid rgba(255,155,66,.3);
            border-radius: 50%;
            box-shadow:
                0 0 0 20px rgba(255,121,0,.025),
                0 0 0 40px rgba(255,121,0,.025);
        }

        .welcome-content {
            position: relative;
            z-index: 1;
        }

        .tag {
            display: inline-block;
            padding: 6px 10px;
            margin-bottom: 14px;
            color: var(--orange-light);
            background: rgba(255,121,0,.12);
            border-radius: 6px;
            font-size: 10px;
            font-weight: 800;
            letter-spacing: 1.5px;
        }

        .welcome h2 {
            margin-bottom: 10px;
            font-size: clamp(23px, 3vw, 31px);
        }

        .welcome h2 span {
            color: var(--orange);
        }

        .welcome p {
            max-width: 590px;
            margin-bottom: 22px;
            color: #aaa;
            font-size: 13px;
            line-height: 1.8;
        }

        .primary-btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 9px;
            padding: 12px 17px;
            color: #111;
            background: linear-gradient(
                135deg,
                var(--orange-light),
                var(--orange)
            );
            border-radius: 10px;
            font-size: 12px;
            font-weight: 800;
            transition: .3s ease;
        }

        .primary-btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 9px 25px rgba(255,121,0,.25);
        }

        /* SECTION HEADINGS */

        .section-heading {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 12px;
            margin-bottom: 17px;
        }

        .section-heading h2 {
            font-size: 17px;
        }

        .section-heading p {
            margin-top: 5px;
            color: var(--muted);
            font-size: 11px;
        }

        .section-heading > a {
            color: var(--orange-light);
            font-size: 12px;
        }

        /* STATISTICS */

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(4, minmax(0, 1fr));
            gap: 16px;
            margin-bottom: 30px;
        }

        .stat-card {
            position: relative;
            overflow: hidden;
            padding: 20px;
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: 17px;
            animation: fadeUp .65s ease both;
            transition:
                transform .35s ease,
                border-color .35s ease,
                box-shadow .35s ease;
        }

        .stat-card:nth-child(1) { animation-delay: .10s; }
        .stat-card:nth-child(2) { animation-delay: .18s; }
        .stat-card:nth-child(3) { animation-delay: .26s; }
        .stat-card:nth-child(4) { animation-delay: .34s; }

        .stat-card::after {
            content: "";
            position: absolute;
            top: -35px;
            right: -35px;
            width: 100px;
            height: 100px;
            border-radius: 50%;
            background: var(--glow);
            filter: blur(30px);
            transition: .35s;
        }

        .stat-card:hover {
            transform: translateY(-7px);
            border-color: rgba(255,121,0,.45);
            box-shadow: 0 12px 35px rgba(0,0,0,.25);
        }

        .stat-card:hover::after {
            transform: scale(1.6);
        }

        .stat-top {
            position: relative;
            z-index: 1;
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 19px;
        }

        .stat-icon {
            width: 42px;
            height: 42px;
            display: grid;
            place-items: center;
            border-radius: 12px;
            color: var(--icon-color);
            background: var(--icon-bg);
            font-size: 19px;
        }

        .stat-tag {
            color: #999;
            font-size: 10px;
        }

        .stat-number {
            position: relative;
            z-index: 1;
            font-size: 31px;
            font-weight: 800;
            letter-spacing: -1px;
        }

        .stat-label {
            position: relative;
            z-index: 1;
            margin-top: 7px;
            color: #aaa;
            font-size: 12px;
        }

        /* CONTENT PANELS */

        .content-grid {
            display: grid;
            grid-template-columns: minmax(0, 1.5fr) minmax(260px, 1fr);
            gap: 22px;
            align-items: start;
        }

        .panel {
            min-width: 0;
            padding: 22px;
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: 18px;
            animation: fadeUp .8s .2s ease both;
        }

        .application-list,
        .internship-list {
            display: grid;
            gap: 12px;
        }

        .application-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 14px;
            padding: 15px;
            background: #191919;
            border: 1px solid rgba(255,255,255,.055);
            border-radius: 13px;
            transition: .3s ease;
        }

        .application-item:hover {
            transform: translateX(4px);
            background: #1e1a16;
            border-color: rgba(255,121,0,.3);
        }

        .application-title {
            margin-bottom: 7px;
            font-size: 13px;
            font-weight: 700;
        }

        .application-meta {
            color: #999;
            font-size: 11px;
            line-height: 1.8;
        }

        .status {
            display: inline-block;
            flex-shrink: 0;
            padding: 6px 9px;
            border-radius: 7px;
            font-size: 10px;
            font-weight: 800;
            white-space: nowrap;
        }

        .status.pending {
            color: #ffc46a;
            background: rgba(255,196,106,.1);
        }

        .status.shortlisted {
            color: #70aaff;
            background: rgba(112,170,255,.12);
        }

        .status.interview {
            color: #bd91ff;
            background: rgba(189,145,255,.12);
        }

        .status.selected {
            color: #39d6a0;
            background: rgba(57,214,160,.12);
        }

        .status.rejected {
            color: #ff7777;
            background: rgba(255,119,119,.12);
        }

        /* INTERNSHIP CARDS */

        .internship-card {
            padding: 16px;
            background: #191919;
            border: 1px solid rgba(255,255,255,.055);
            border-radius: 13px;
            transition: .3s ease;
        }

        .internship-card:hover {
            transform: translateY(-4px);
            border-color: rgba(255,121,0,.35);
            background: #1e1a16;
        }

        .internship-card h3 {
            margin-bottom: 8px;
            font-size: 13px;
            line-height: 1.5;
        }

        .meta {
            color: #999;
            font-size: 11px;
            line-height: 1.8;
        }

        .card-bottom {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 10px;
            margin-top: 12px;
        }

        .stipend {
            color: var(--green);
            font-size: 11px;
            font-weight: 700;
        }

        .text-link {
            color: var(--orange-light);
            font-size: 11px;
            font-weight: 700;
        }

        .text-link:hover {
            text-decoration: underline;
        }

        /* QUICK ACTIONS */

        .quick-actions {
            display: grid;
            gap: 12px;
        }

        .action-link {
            display: flex;
            align-items: center;
            gap: 13px;
            padding: 15px;
            background: #191919;
            border: 1px solid rgba(255,255,255,.055);
            border-radius: 13px;
            transition: .3s ease;
        }

        .action-link:hover {
            transform: translateX(4px);
            border-color: rgba(255,121,0,.35);
        }

        .action-icon {
            flex-shrink: 0;
            width: 40px;
            height: 40px;
            display: grid;
            place-items: center;
            color: var(--orange-light);
            background: rgba(255,121,0,.12);
            border-radius: 12px;
            font-size: 19px;
        }

        .action-link h3 {
            margin-bottom: 5px;
            font-size: 12px;
        }

        .action-link p {
            color: #999;
            font-size: 10px;
            line-height: 1.6;
        }

        /* PROFILE COMPLETION */

        .profile-panel {
            padding: 22px;
            margin-top: 22px;
            border: 1px solid rgba(255,121,0,.2);
            border-radius: 17px;
            background: linear-gradient(120deg, #19130e, #131313);
            animation: fadeUp .8s .25s ease both;
        }

        .profile-top {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 12px;
            margin-bottom: 14px;
        }

        .profile-top h3 {
            font-size: 14px;
        }

        .profile-percent {
            color: var(--orange-light);
            font-size: 13px;
            font-weight: 800;
        }

        .progress-track {
            height: 8px;
            overflow: hidden;
            background: #292929;
            border-radius: 20px;
        }

        .progress-bar {
            width: 0;
            height: 100%;
            border-radius: inherit;
            background: linear-gradient(
                90deg,
                var(--orange),
                #ffc078
            );
            box-shadow: 0 0 15px rgba(255,121,0,.3);
            transition: width 1.3s cubic-bezier(.2,.8,.2,1);
        }

        .profile-note {
            margin-top: 12px;
            color: #999;
            font-size: 11px;
            line-height: 1.8;
        }

        .profile-note a {
            color: var(--orange-light);
            font-weight: 700;
        }

        .empty-state {
            padding: 28px 12px;
            color: var(--muted);
            text-align: center;
            font-size: 12px;
            line-height: 1.8;
        }

        .empty-icon {
            margin-bottom: 10px;
            font-size: 30px;
        }

        .empty-state .primary-btn {
            margin-top: 15px;
        }

        .error-message {
            padding: 14px;
            margin-bottom: 20px;
            color: #ffaaaa;
            background: #301717;
            border: 1px solid #663030;
            border-radius: 12px;
            font-size: 13px;
        }

        .footer {
            padding-top: 28px;
            color: #666;
            text-align: center;
            font-size: 11px;
        }

        .footer span {
            color: var(--orange);
        }

        /* ANIMATIONS */

        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateX(-25px);
            }
            to {
                opacity: 1;
                transform: translateX(0);
            }
        }

        @keyframes fadeDown {
            from {
                opacity: 0;
                transform: translateY(-14px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @keyframes fadeUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @keyframes pulse {
            0%, 100% {
                opacity: .5;
                transform: scale(1);
            }
            50% {
                opacity: 1;
                transform: scale(1.15);
            }
        }

        /* RESPONSIVE */

        @media (max-width: 1150px) {
            .stats-grid {
                grid-template-columns: repeat(2, minmax(0, 1fr));
            }

            .content-grid {
                grid-template-columns: 1fr;
            }

            .main {
                padding: 25px;
            }
        }

        @media (max-width: 760px) {
            .sidebar {
                width: 72px;
                padding: 20px 9px;
            }

            .brand {
                justify-content: center;
                margin: 0 0 30px;
            }

            .brand-name,
            .nav-label,
            .nav-text,
            .tip-card {
                display: none;
            }

            .nav-link {
                justify-content: center;
                padding: 13px 5px;
            }

            .nav-icon {
                width: auto;
            }

            .logout {
                font-size: 0;
                padding: 12px 4px;
            }

            .logout::after {
                content: "↪";
                font-size: 19px;
            }

            .main {
                width: calc(100% - 72px);
                margin-left: 72px;
                padding: 20px 15px;
            }

            .topbar {
                align-items: flex-start;
            }

            .date-box {
                display: none;
            }

            .welcome {
                padding: 22px;
            }

            .panel,
            .profile-panel {
                padding: 16px;
            }
        }

        @media (max-width: 420px) {
            .stats-grid {
                gap: 10px;
            }

            .stat-card {
                padding: 13px;
            }

            .stat-icon {
                width: 35px;
                height: 35px;
                font-size: 16px;
            }

            .stat-number {
                font-size: 24px;
            }

            .stat-label {
                font-size: 10px;
            }

            .stat-tag {
                display: none;
            }

            .application-item {
                align-items: flex-start;
                flex-direction: column;
            }

            .card-bottom {
                align-items: flex-start;
                flex-direction: column;
            }
        }

        @media (prefers-reduced-motion: reduce) {
            *,
            *::before,
            *::after {
                animation-duration: .01ms !important;
                animation-iteration-count: 1 !important;
                transition-duration: .01ms !important;
                scroll-behavior: auto !important;
            }
        }
    </style>
</head>

<body>
<div class="layout">

    <!-- SIDEBAR -->
    <aside class="sidebar">

        <a href="dashboard.php" class="brand">
            <span class="brand-icon">C</span>
            <span class="brand-name">Career<span>Bridge</span></span>
        </a>

        <div class="nav-label">STUDENT MENU</div>

        <nav class="nav-links">
            <a href="dashboard.php" class="nav-link active">
                <span class="nav-icon">⌂</span>
                <span class="nav-text">Dashboard</span>
            </a>

            <a href="profile.php" class="nav-link">
                <span class="nav-icon">♙</span>
                <span class="nav-text">My Profile</span>
            </a>

            <a href="internships.php" class="nav-link">
                <span class="nav-icon">▣</span>
                <span class="nav-text">Find Internships</span>
            </a>

            <a href="applications.php" class="nav-link">
                <span class="nav-icon">☷</span>
                <span class="nav-text">My Applications</span>
            </a>
        </nav>

        <div class="sidebar-bottom">
            <div class="tip-card">
                <h3>Career tip</h3>
                <p>
                    Keep your profile updated and apply to internships
                    that match your skills and interests.
                </p>
            </div>

            <a href="../logout.php" class="logout">
                ↪ &nbsp; Sign Out
            </a>
        </div>

    </aside>

    <!-- MAIN CONTENT -->
    <main class="main">

        <header class="topbar">
            <div>
                <div class="breadcrumb">
                    Student Portal / <span>Dashboard</span>
                </div>

                <h1 class="page-title">
                    Student <span>Dashboard</span>
                </h1>
            </div>

            <div class="top-right">
                <div class="date-box" id="todayDate">
                    Welcome back!
                </div>

                <div class="avatar">
                    <?= h(strtoupper(substr($firstName, 0, 1))) ?>
                </div>
            </div>
        </header>

        <?php if ($errorMessage !== ''): ?>
            <div class="error-message">
                <?= h($errorMessage) ?>
            </div>
        <?php endif; ?>

        <!-- WELCOME BANNER -->
        <section class="welcome">
            <div class="welcome-content">

                <div class="tag">YOUR CAREER JOURNEY</div>

                <h2>
                    Welcome back,
                    <span><?= h($firstName) ?>!</span> 👋
                </h2>

                <p>
                    Your next opportunity could be one application away.
                    Explore internships, track your applications, and take
                    the next step toward your career goals.
                </p>

                <a href="internships.php" class="primary-btn">
                    Explore Internships <span>→</span>
                </a>

            </div>
        </section>

        <!-- STATISTICS -->
        <div class="section-heading">
            <div>
                <h2>Your Overview</h2>
                <p>Track your internship journey at a glance.</p>
            </div>
        </div>

        <section class="stats-grid">

            <article class="stat-card"
                style="--glow:rgba(255,121,0,.17);
                       --icon-bg:rgba(255,121,0,.12);
                       --icon-color:#ff9b42;">

                <div class="stat-top">
                    <div class="stat-icon">▤</div>
                    <span class="stat-tag">TOTAL</span>
                </div>

                <div class="stat-number counter"
                     data-target="<?= $totalApplications ?>">0</div>

                <div class="stat-label">Applications Submitted</div>
            </article>

            <article class="stat-card"
                style="--glow:rgba(112,170,255,.17);
                       --icon-bg:rgba(112,170,255,.12);
                       --icon-color:#70aaff;">

                <div class="stat-top">
                    <div class="stat-icon">◷</div>
                    <span class="stat-tag">IN PROGRESS</span>
                </div>

                <div class="stat-number counter"
                     data-target="<?= $pendingApplications ?>">0</div>

                <div class="stat-label">Pending / Under Review</div>
            </article>

            <article class="stat-card"
                style="--glow:rgba(189,145,255,.17);
                       --icon-bg:rgba(189,145,255,.12);
                       --icon-color:#bd91ff;">

                <div class="stat-top">
                    <div class="stat-icon">✦</div>
                    <span class="stat-tag">OPPORTUNITY</span>
                </div>

                <div class="stat-number counter"
                     data-target="<?= $shortlistedApplications ?>">0</div>

                <div class="stat-label">Shortlisted</div>
            </article>

            <article class="stat-card"
                style="--glow:rgba(57,214,160,.17);
                       --icon-bg:rgba(57,214,160,.12);
                       --icon-color:#39d6a0;">

                <div class="stat-top">
                    <div class="stat-icon">✓</div>
                    <span class="stat-tag">SUCCESS</span>
                </div>

                <div class="stat-number counter"
                     data-target="<?= $selectedApplications ?>">0</div>

                <div class="stat-label">Selected</div>
            </article>

        </section>

        <!-- APPLICATIONS AND INTERNSHIPS -->
        <section class="content-grid">

            <!-- RECENT APPLICATIONS -->
            <div class="panel">

                <div class="section-heading">
                    <div>
                        <h2>Recent Applications</h2>
                        <p>Your latest application updates.</p>
                    </div>

                    <a href="applications.php">View all →</a>
                </div>

                <div class="application-list">

                    <?php if (empty($applications)): ?>

                        <div class="empty-state">
                            <div class="empty-icon">📄</div>

                            <strong>No applications yet</strong>

                            <p>
                                Find an internship and submit your first
                                application to get started.
                            </p>

                            <a href="internships.php" class="primary-btn">
                                Find Internships →
                            </a>
                        </div>

                    <?php else: ?>

                        <?php foreach ($applications as $application): ?>

                            <?php
                                $status = (string)(
                                    $application['status'] ?? 'Applied'
                                );

                                $title = $application['title']
                                    ?? 'Internship';

                                $location = $application['location']
                                    ?? 'Location not specified';

                                $appliedAt = $application['applied_at']
                                    ?? '';
                            ?>

                            <article class="application-item">

                                <div>
                                    <div class="application-title">
                                        <?= h($title) ?>
                                    </div>

                                    <div class="application-meta">
                                        📍 <?= h($location) ?><br>

                                        <?php if (
                                            $appliedAt !== '' &&
                                            strtotime((string)$appliedAt) !== false
                                        ): ?>
                                            Applied:
                                            <?= h(date(
                                                'd M Y',
                                                strtotime((string)$appliedAt)
                                            )) ?>
                                        <?php else: ?>
                                            Application submitted
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <span class="status <?= h(statusClass($status)) ?>">
                                    <?= h(ucwords($status)) ?>
                                </span>

                            </article>

                        <?php endforeach; ?>

                    <?php endif; ?>

                </div>
            </div>

            <!-- LATEST INTERNSHIPS -->
            <div class="panel">

                <div class="section-heading">
                    <div>
                        <h2>Latest Internships</h2>
                        <p>Discover new opportunities.</p>
                    </div>

                    <a href="internships.php">Explore →</a>
                </div>

                <div class="internship-list">

                    <?php if (empty($internships)): ?>

                        <div class="empty-state">
                            <div class="empty-icon">💼</div>

                            <strong>No internships available</strong>

                            <p>
                                Please check again later for new opportunities.
                            </p>
                        </div>

                    <?php else: ?>

                        <?php foreach ($internships as $internship): ?>

                            <article class="internship-card">

                                <h3>
                                    <?= h($internship['title'] ?? 'Internship') ?>
                                </h3>

                                <div class="meta">
                                    📍
                                    <?= h(
                                        $internship['location']
                                        ?? 'Location not specified'
                                    ) ?>
                                </div>

                                <div class="card-bottom">

                                    <span class="stipend">
                                        <?php
                                            $stipend = $internship['stipend'] ?? '';

                                            echo trim((string)$stipend) !== ''
                                                ? h($stipend)
                                                : 'Stipend not specified';
                                        ?>
                                    </span>

                                    <a
                                        href="internships.php"
                                        class="text-link"
                                    >
                                        View details →
                                    </a>

                                </div>

                            </article>

                        <?php endforeach; ?>

                    <?php endif; ?>

                </div>
            </div>

        </section>

        <!-- QUICK ACTIONS -->
        <section class="panel" style="margin-top:22px;">

            <div class="section-heading">
                <div>
                    <h2>Quick Actions</h2>
                    <p>Access your most-used student features.</p>
                </div>
            </div>

            <div class="quick-actions">

                <a href="profile.php" class="action-link">
                    <div class="action-icon">♙</div>

                    <div>
                        <h3>Update My Profile</h3>
                        <p>Manage your personal and academic information.</p>
                    </div>
                </a>

                <a href="internships.php" class="action-link">
                    <div class="action-icon">▣</div>

                    <div>
                        <h3>Browse Internships</h3>
                        <p>Find opportunities that match your interests.</p>
                    </div>
                </a>

                <a href="applications.php" class="action-link">
                    <div class="action-icon">☷</div>

                    <div>
                        <h3>Track Applications</h3>
                        <p>Check the current status of your applications.</p>
                    </div>
                </a>

            </div>
        </section>

        <!-- PROFILE COMPLETION -->
        <section class="profile-panel">

            <div class="profile-top">
                <h3>Profile Completion</h3>

                <span class="profile-percent">
                    <?= $profileCompletion ?>%
                </span>
            </div>

            <div class="progress-track">
                <div
                    class="progress-bar"
                    id="profileProgress"
                    data-progress="<?= $profileCompletion ?>"
                ></div>
            </div>

            <p class="profile-note">
                Add your phone number, college, course, and skills to
                complete your profile.
                <a href="profile.php">Update your profile →</a>
            </p>

        </section>

        <footer class="footer">
            © <?= date('Y') ?>
            <span>CareerBridge</span>.
            Build your future, one opportunity at a time.
        </footer>

    </main>
</div>

<script>
    // Display the current date
    const dateElement = document.getElementById('todayDate');

    if (dateElement) {
        dateElement.textContent = new Date().toLocaleDateString(
            'en-IN',
            {
                day: '2-digit',
                month: 'short',
                year: 'numeric'
            }
        );
    }

    // Animate statistic counters
    document.querySelectorAll('.counter').forEach(counter => {
        const target = Number(counter.dataset.target || 0);
        const duration = 1000;
        const startTime = performance.now();

        function updateCounter(currentTime) {
            const elapsed = currentTime - startTime;
            const progress = Math.min(elapsed / duration, 1);
            const eased = 1 - Math.pow(1 - progress, 3);

            counter.textContent = Math.round(target * eased);

            if (progress < 1) {
                requestAnimationFrame(updateCounter);
            } else {
                counter.textContent = target;
            }
        }

        requestAnimationFrame(updateCounter);
    });

    // Animate profile progress bar
    const progressBar = document.getElementById('profileProgress');

    if (progressBar) {
        const progress = Math.max(
            0,
            Math.min(100, Number(progressBar.dataset.progress || 0))
        );

        requestAnimationFrame(() => {
            progressBar.style.width = progress + '%';
        });
    }
</script>

</body>
</html>
