
<?php
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

require_once __DIR__ . '/../config/database.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit;
}

if (($_SESSION['role'] ?? '') !== 'student') {
    header('Location: ../index.php');
    exit;
}

function h($value): string {
    return htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8');
}

function statusClass($status): string {
    return match (strtolower(trim((string)$status))) {
        'shortlisted', 'selected' => 'good',
        'rejected' => 'bad',
        'interview' => 'purple',
        'under review' => 'wait',
        default => 'neutral'
    };
}

$apps = [];
$error = '';

try {
    $pdo = getPDO();

    $stmt = $pdo->prepare(
        'SELECT id FROM students WHERE user_id = ? LIMIT 1'
    );
    $stmt->execute([$_SESSION['user_id']]);
    $student = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$student) {
        throw new RuntimeException(
            'Your student profile is missing. Please contact the administrator to link your student profile to your account.'
        );
    }

    $stmt = $pdo->prepare(
        'SELECT
            a.id,
            a.status,
            a.applied_at,
            i.title,
            i.location,
            c.company_name
         FROM applications a
         INNER JOIN internships i ON i.id = a.internship_id
         LEFT JOIN companies c ON c.id = i.company_id
         WHERE a.student_id = ?
         ORDER BY a.applied_at DESC, a.id DESC'
    );

    $stmt->execute([(int)$student['id']]);
    $apps = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (Throwable $e) {
    error_log('CareerBridge applications error: ' . $e->getMessage());
    $error = $e->getMessage();
}

$total = count($apps);
$review = 0;
$shortlisted = 0;
$selected = 0;
$rejected = 0;

foreach ($apps as $app) {
    $status = strtolower(trim((string)($app['status'] ?? 'Applied')));

    if (in_array($status, ['applied', 'under review'], true)) {
        $review++;
    }

    if (in_array($status, ['shortlisted', 'interview'], true)) {
        $shortlisted++;
    }

    if ($status === 'selected') {
        $selected++;
    }

    if ($status === 'rejected') {
        $rejected++;
    }
}

$firstName = explode(
    ' ',
    trim((string)($_SESSION['name'] ?? 'Student'))
)[0] ?: 'Student';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<title>My Applications | CareerBridge</title>

<style>
:root {
    --bg: #080808;
    --sidebar: #101010;
    --panel: #151515;
    --panel-light: #1c1c1c;
    --line: #2b2b2b;
    --text: #ffffff;
    --muted: #a3a3a3;
    --orange: #ff7900;
    --orange-light: #ffad55;
    --orange-soft: rgba(255,121,0,.12);
    --green: #55dfa0;
    --red: #ff7777;
    --purple: #c3a1ff;
    --yellow: #ffd27b;
}

* {
    box-sizing: border-box;
    margin: 0;
    padding: 0;
}

html {
    scroll-behavior: smooth;
}

body {
    min-height: 100vh;
    background:
        radial-gradient(ellipse at 85% 0%, rgba(255,121,0,.10), transparent 32%),
        var(--bg);
    color: var(--text);
    font-family: "Segoe UI", Arial, sans-serif;
    overflow-x: hidden;
}

a {
    color: inherit;
    text-decoration: none;
}

button,
input,
select {
    font: inherit;
}

@keyframes pageEnter {
    from { opacity: 0; transform: translateY(8px); }
    to { opacity: 1; transform: translateY(0); }
}

@keyframes riseIn {
    from {
        opacity: 0;
        transform: translateY(17px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

@keyframes floatIcon {
    0%, 100% { transform: translateY(0); }
    50% { transform: translateY(-7px); }
}

@keyframes shine {
    from { transform: translateX(-150%); }
    to { transform: translateX(150%); }
}

@keyframes pulseDot {
    0%, 100% { box-shadow: 0 0 0 0 rgba(255,121,0,.4); }
    50% { box-shadow: 0 0 0 6px rgba(255,121,0,0); }
}

/* LEFT SIDEBAR */

.sidebar {
    position: fixed;
    inset: 0 auto 0 0;
    z-index: 100;
    display: flex;
    flex-direction: column;
    width: 250px;
    padding: 27px 17px 20px;
    background: var(--sidebar);
    border-right: 1px solid var(--line);
}

.brand {
    display: flex;
    align-items: center;
    gap: 11px;
    padding: 0 10px 27px;
    border-bottom: 1px solid var(--line);
    font-size: 22px;
    font-weight: 950;
    letter-spacing: -.8px;
}

.brand-icon {
    display: grid;
    place-items: center;
    width: 39px;
    height: 39px;
    flex-shrink: 0;
    border-radius: 12px;
    background: linear-gradient(135deg, #ff9b2e, #ff6500);
    color: #111;
    font-size: 20px;
    box-shadow: 0 5px 20px rgba(255,121,0,.2);
}

.brand-name span {
    color: var(--orange);
}

.sidebar-label {
    margin: 27px 10px 12px;
    color: #777;
    font-size: 9px;
    font-weight: 900;
    letter-spacing: 1.8px;
}

.sidebar-links {
    display: flex;
    flex-direction: column;
    gap: 7px;
}

.sidebar-link {
    display: flex;
    align-items: center;
    gap: 13px;
    min-height: 47px;
    padding: 12px 13px;
    border: 1px solid transparent;
    border-radius: 11px;
    color: #b8b8b8;
    font-size: 12px;
    font-weight: 700;
    transition: .25s ease;
}

.sidebar-link:hover {
    color: white;
    background: #1b1b1b;
    transform: translateX(3px);
}

.sidebar-link.active {
    color: var(--orange-light);
    background: rgba(255,121,0,.11);
    border-color: rgba(255,121,0,.22);
    box-shadow: inset 3px 0 0 var(--orange);
}

.link-icon {
    display: grid;
    place-items: center;
    width: 24px;
    flex-shrink: 0;
    font-size: 18px;
}

.sidebar-bottom {
    margin-top: auto;
}

.profile-mini {
    display: flex;
    align-items: center;
    gap: 11px;
    padding: 15px 10px;
    margin-bottom: 12px;
    border: 1px solid var(--line);
    border-radius: 13px;
    background: #171717;
}

.profile-avatar {
    display: grid;
    place-items: center;
    width: 37px;
    height: 37px;
    flex-shrink: 0;
    border-radius: 11px;
    background: var(--orange-soft);
    border: 1px solid rgba(255,121,0,.3);
    color: var(--orange-light);
    font-size: 15px;
    font-weight: 900;
}

.profile-name {
    overflow: hidden;
    color: white;
    font-size: 11px;
    font-weight: 800;
    text-overflow: ellipsis;
    white-space: nowrap;
}

.profile-role {
    margin-top: 4px;
    color: #888;
    font-size: 10px;
}

.logout-link {
    color: #ff8585;
}

.logout-link:hover {
    background: rgba(255,70,70,.09);
    color: #ff9b9b;
}

/* MAIN CONTENT */

.main {
    min-height: 100vh;
    margin-left: 250px;
    padding: 32px clamp(20px, 4vw, 48px) 25px;
    animation: pageEnter .65s ease both;
}

.topbar {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 15px;
    margin-bottom: 26px;
}

.breadcrumb {
    color: #888;
    font-size: 11px;
}

.breadcrumb span {
    color: var(--orange-light);
}

.topbar-right {
    display: flex;
    align-items: center;
    gap: 9px;
    color: #b9b9b9;
    font-size: 11px;
}

.online-dot {
    width: 7px;
    height: 7px;
    border-radius: 50%;
    background: var(--orange);
    animation: pulseDot 2s infinite;
}

/* HERO */

.hero {
    position: relative;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 22px;
    overflow: hidden;
    padding: 30px;
    margin-bottom: 27px;
    border: 1px solid rgba(255,121,0,.23);
    border-radius: 20px;
    background:
        radial-gradient(circle at 95% 15%, rgba(255,121,0,.16), transparent 35%),
        linear-gradient(120deg, #1c140e, #151515 65%, #111111);
    animation: riseIn .6s ease both;
}

.hero::after {
    content: "";
    position: absolute;
    top: 0;
    bottom: 0;
    left: 0;
    width: 3px;
    background: linear-gradient(var(--orange), #ffb16d, transparent);
}

.eyebrow {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    color: var(--orange-light);
    font-size: 10px;
    font-weight: 900;
    letter-spacing: 1.8px;
}

.eyebrow-dot {
    width: 7px;
    height: 7px;
    border-radius: 50%;
    background: var(--orange);
}

.hero h1 {
    margin: 12px 0;
    font-size: clamp(28px, 3.4vw, 39px);
    font-weight: 950;
    letter-spacing: -1.3px;
}

.hero h1 span {
    color: var(--orange);
}

.hero p {
    max-width: 570px;
    color: var(--muted);
    font-size: 12px;
    line-height: 1.9;
}

.hero-icon {
    flex-shrink: 0;
    color: var(--orange);
    font-size: 64px;
    filter: drop-shadow(0 0 18px rgba(255,121,0,.17));
    animation: floatIcon 4s ease-in-out infinite;
}

.hero-actions {
    display: flex;
    flex-wrap: wrap;
    gap: 10px;
    margin-top: 19px;
}

/* BUTTONS */

.btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    padding: 12px 16px;
    border: 1px solid transparent;
    border-radius: 10px;
    background: linear-gradient(135deg, #ff9d35, #ff7200);
    color: #111;
    font-size: 11px;
    font-weight: 900;
    cursor: pointer;
    transition: .25s ease;
}

.btn:hover {
    transform: translateY(-3px);
    box-shadow: 0 8px 24px rgba(255,121,0,.2);
}

.btn:active {
    transform: scale(.97);
}

.btn.secondary {
    color: #eee;
    background: #191919;
    border-color: #353535;
}

.btn.secondary:hover {
    color: var(--orange-light);
    border-color: var(--orange);
}

/* SECTION TITLES */

.section-heading {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 12px;
    margin: 28px 0 15px;
}

.section-heading h2 {
    color: #fff;
    font-size: 16px;
    font-weight: 900;
}

.section-heading p {
    margin-top: 6px;
    color: var(--muted);
    font-size: 11px;
}

.mini-label {
    color: var(--orange-light);
    font-size: 9px;
    font-weight: 900;
    letter-spacing: 1.4px;
}

/* STAT CARDS */

.stats {
    display: grid;
    grid-template-columns: repeat(4, minmax(0,1fr));
    gap: 13px;
}

.stat {
    position: relative;
    overflow: hidden;
    padding: 19px;
    border: 1px solid var(--line);
    border-radius: 15px;
    background: linear-gradient(145deg, #1b1b1b, #121212);
    animation: riseIn .6s ease both;
    transition: .25s ease;
}

.stat:nth-child(1) { animation-delay: .05s; }
.stat:nth-child(2) { animation-delay: .12s; }
.stat:nth-child(3) { animation-delay: .19s; }
.stat:nth-child(4) { animation-delay: .26s; }

.stat:hover {
    transform: translateY(-5px);
    border-color: rgba(255,121,0,.45);
    box-shadow: 0 12px 30px rgba(0,0,0,.25);
}

.stat-top {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 8px;
}

.stat-icon {
    display: grid;
    place-items: center;
    width: 40px;
    height: 40px;
    border: 1px solid rgba(255,121,0,.24);
    border-radius: 12px;
    background: rgba(255,121,0,.11);
    color: var(--orange-light);
    font-size: 19px;
}

.stat-tag {
    color: #858585;
    font-size: 9px;
    font-weight: 800;
}

.stat-number {
    margin-top: 16px;
    color: white;
    font-size: 30px;
    font-weight: 950;
    letter-spacing: -.6px;
    font-variant-numeric: tabular-nums;
    transition: color .25s;
}

.stat:hover .stat-number {
    color: var(--orange-light);
}

.stat-description {
    margin-top: 6px;
    color: var(--muted);
    font-size: 10px;
    line-height: 1.6;
}

/* APPLICATION PANEL */

.panel {
    overflow: hidden;
    border: 1px solid var(--line);
    border-radius: 16px;
    background: rgba(19,19,19,.95);
    box-shadow: 0 12px 35px rgba(0,0,0,.17);
    animation: riseIn .65s .1s ease both;
}

.panel-head {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 13px;
    flex-wrap: wrap;
    padding: 20px;
    border-bottom: 1px solid var(--line);
}

.panel-head h2 {
    font-size: 14px;
    font-weight: 900;
}

.panel-head p {
    margin-top: 6px;
    color: var(--muted);
    font-size: 11px;
}

.live-indicator {
    display: inline-flex;
    align-items: center;
    gap: 7px;
    color: var(--orange-light);
    font-size: 10px;
}

.live-dot {
    width: 7px;
    height: 7px;
    border-radius: 50%;
    background: var(--orange);
    animation: pulseDot 2s infinite;
}

/* SEARCH AND FILTERS */

.toolbar {
    display: flex;
    flex-wrap: wrap;
    gap: 10px;
    padding: 15px 19px;
    border-bottom: 1px solid #282828;
}

.search-wrap {
    position: relative;
    flex: 1;
    min-width: 190px;
}

.search-icon {
    position: absolute;
    top: 50%;
    left: 13px;
    color: var(--orange-light);
    transform: translateY(-50%);
    pointer-events: none;
}

.search-input,
.filter-select {
    min-height: 42px;
    width: 100%;
    padding: 10px 13px;
    outline: none;
    border: 1px solid #333;
    border-radius: 9px;
    background: #101010;
    color: #eee;
    font-size: 11px;
    transition: .25s ease;
}

.search-input {
    padding-left: 36px;
}

.search-input::placeholder {
    color: #858585;
}

.search-input:focus,
.filter-select:focus {
    border-color: var(--orange);
    box-shadow: 0 0 0 3px rgba(255,121,0,.1);
}

.filter-select {
    width: auto;
    min-width: 155px;
    cursor: pointer;
}

.filter-select option {
    background: #151515;
    color: white;
}

/* APPLICATION TABLE */

.table-wrap {
    width: 100%;
    overflow-x: auto;
    scrollbar-color: #555 #151515;
    scrollbar-width: thin;
}

table {
    width: 100%;
    min-width: 720px;
    border-collapse: collapse;
}

th,
td {
    padding: 17px 19px;
    text-align: left;
    border-bottom: 1px solid #282828;
    font-size: 11px;
}

th {
    background: #191919;
    color: #999;
    font-size: 9px;
    font-weight: 900;
    letter-spacing: 1.1px;
    text-transform: uppercase;
}

td {
    color: #e7e7e7;
}

tbody tr {
    transition: background .2s ease;
    animation: riseIn .45s ease both;
}

tbody tr:hover {
    background: rgba(255,121,0,.045);
}

tbody tr:last-child td {
    border-bottom: none;
}

.job-cell {
    display: flex;
    align-items: center;
    gap: 11px;
    min-width: 185px;
}

.company-icon {
    display: grid;
    place-items: center;
    width: 37px;
    height: 37px;
    flex-shrink: 0;
    border: 1px solid rgba(255,121,0,.24);
    border-radius: 11px;
    background: rgba(255,121,0,.1);
    color: var(--orange-light);
    font-size: 15px;
}

.job-title {
    color: #fff;
    font-size: 11px;
    font-weight: 800;
    line-height: 1.6;
    overflow-wrap: anywhere;
}

.job-subtitle {
    margin-top: 3px;
    color: #888;
    font-size: 10px;
}

.company-name {
    font-size: 11px;
    font-weight: 700;
}

.location-name,
.date-name {
    color: #bbb;
    font-size: 10px;
    white-space: nowrap;
}

/* STATUS BADGES */

.status {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 7px 10px;
    border: 1px solid transparent;
    border-radius: 30px;
    font-size: 10px;
    font-weight: 800;
    white-space: nowrap;
}

.status::before {
    content: "";
    width: 5px;
    height: 5px;
    border-radius: 50%;
    background: currentColor;
}

.good {
    color: #75e6a8;
    background: rgba(85,223,160,.09);
    border-color: rgba(85,223,160,.19);
}

.bad {
    color: #ff8989;
    background: rgba(255,80,80,.09);
    border-color: rgba(255,80,80,.18);
}

.purple {
    color: #d0b3ff;
    background: rgba(166,123,255,.09);
    border-color: rgba(166,123,255,.18);
}

.wait {
    color: #ffd27b;
    background: rgba(255,194,94,.09);
    border-color: rgba(255,194,94,.18);
}

.neutral {
    color: var(--orange-light);
    background: rgba(255,121,0,.08);
    border-color: rgba(255,121,0,.18);
}

/* MESSAGES AND EMPTY STATE */

.notice {
    padding: 15px 17px;
    margin-bottom: 18px;
    border: 1px solid rgba(255,121,0,.4);
    border-radius: 11px;
    background: rgba(255,121,0,.08);
    color: #ffd3a6;
    font-size: 12px;
    line-height: 1.8;
    overflow-wrap: anywhere;
}

.success-notice {
    padding: 14px 17px;
    margin-bottom: 18px;
    border: 1px solid rgba(255,121,0,.35);
    border-radius: 11px;
    background: rgba(255,121,0,.08);
    color: var(--orange-light);
    font-size: 12px;
    line-height: 1.7;
    animation: riseIn .5s ease both;
}

.empty {
    padding: 48px 20px;
    text-align: center;
}

.empty-icon {
    display: grid;
    place-items: center;
    width: 75px;
    height: 75px;
    margin: 0 auto 18px;
    border: 1px solid rgba(255,121,0,.24);
    border-radius: 22px;
    background: rgba(255,121,0,.1);
    color: var(--orange);
    font-size: 31px;
    animation: floatIcon 4s ease-in-out infinite;
}

.empty h3 {
    margin: 12px 0 8px;
    font-size: 18px;
}

.empty p {
    max-width: 390px;
    margin: 0 auto 20px;
    color: var(--muted);
    font-size: 12px;
    line-height: 1.8;
}

.no-results {
    display: none;
    padding: 28px 15px;
    color: var(--muted);
    text-align: center;
    font-size: 12px;
}

.foot {
    padding: 22px 10px 8px;
    color: #777;
    text-align: center;
    font-size: 10px;
}

.foot span {
    color: var(--orange);
    font-weight: 800;
}

/* ACCESSIBILITY */

a:focus-visible,
button:focus-visible,
input:focus-visible,
select:focus-visible {
    outline: 2px solid var(--orange);
    outline-offset: 3px;
}

/* TABLET */

@media(max-width:1100px) {
    .sidebar {
        width: 220px;
    }

    .main {
        margin-left: 220px;
        padding-right: 23px;
        padding-left: 23px;
    }

    .stats {
        grid-template-columns: repeat(2, minmax(0,1fr));
    }

    .hero {
        padding: 24px;
    }

    .hero-icon {
        font-size: 48px;
    }
}

/* MOBILE */

@media(max-width:700px) {
    .sidebar {
        position: relative;
        inset: auto;
        width: 100%;
        padding: 14px 15px;
        border-right: none;
        border-bottom: 1px solid var(--line);
    }

    .brand {
        padding: 0 4px 13px;
        font-size: 20px;
    }

    .brand-icon {
        width: 34px;
        height: 34px;
    }

    .sidebar-label {
        margin: 14px 4px 8px;
    }

    .sidebar-links {
        display: grid;
        grid-template-columns: repeat(2, minmax(0,1fr));
        gap: 6px;
    }

    .sidebar-link {
        min-height: 41px;
        padding: 9px;
        font-size: 11px;
    }

    .sidebar-link:hover {
        transform: none;
    }

    .sidebar-bottom {
        margin-top: 12px;
    }

    .profile-mini {
        display: none;
    }

    .main {
        min-height: auto;
        margin-left: 0;
        padding: 21px 15px;
    }

    .topbar {
        margin-bottom: 20px;
    }

    .hero {
        padding: 23px 19px;
    }

    .hero h1 {
        font-size: 29px;
    }

    .hero-icon {
        font-size: 40px;
    }

    .hero p {
        font-size: 11px;
    }

    .section-heading {
        margin-top: 23px;
    }

    .stat {
        padding: 15px;
    }

    .stat-number {
        font-size: 27px;
    }

    .panel-head {
        padding: 16px;
    }

    .toolbar {
        padding: 13px;
    }

    .filter-select {
        flex: 1;
    }
}

@media(max-width:420px) {
    .hero-icon {
        display: none;
    }

    .hero h1 {
        font-size: 26px;
    }

    .stats {
        gap: 9px;
    }

    .stat {
        padding: 13px;
    }

    .stat-icon {
        width: 34px;
        height: 34px;
    }

    .stat-tag {
        font-size: 8px;
    }

    .stat-number {
        font-size: 25px;
    }

    .topbar-right {
        font-size: 10px;
    }

    .section-heading h2 {
        font-size: 14px;
    }
}

@media(prefers-reduced-motion:reduce) {
    *,
    *::before,
    *::after {
        animation-duration: .01ms !important;
        animation-iteration-count: 1 !important;
        transition-duration: .01ms !important;
        scroll-behavior: auto !important;
    }
}
</style>
</head>

<body>

<!-- LEFT SIDEBAR NAVIGATION -->
<aside class="sidebar">

    <a class="brand" href="dashboard.php">
        <span class="brand-icon">C</span>
        <span class="brand-name">Career<span>Bridge</span></span>
    </a>

    <div class="sidebar-label">MAIN MENU</div>

    <nav class="sidebar-links">
        <a class="sidebar-link" href="dashboard.php">
            <span class="link-icon">⌂</span>
            <span>Dashboard</span>
        </a>

        <a class="sidebar-link" href="profile.php">
            <span class="link-icon">♙</span>
            <span>My Profile</span>
        </a>

        <a class="sidebar-link" href="internships.php">
            <span class="link-icon">⌕</span>
            <span>Internships</span>
        </a>

        <a class="sidebar-link active" href="applications.php">
            <span class="link-icon">▤</span>
            <span>My Applications</span>
        </a>
    </nav>

    <div class="sidebar-bottom">

        <div class="sidebar-label">MY ACCOUNT</div>

        <div class="profile-mini">
            <div class="profile-avatar">
                <?= h(strtoupper(substr($firstName, 0, 1))) ?>
            </div>

            <div style="min-width:0">
                <div class="profile-name"><?= h($firstName) ?></div>
                <div class="profile-role">Student account</div>
            </div>
        </div>

        <a class="sidebar-link logout-link" href="../logout.php">
            <span class="link-icon">↪</span>
            <span>Sign out</span>
        </a>

    </div>
</aside>

<!-- MAIN CONTENT -->
<main class="main">

    <div class="topbar">
        <div class="breadcrumb">
            Student Portal &nbsp; / &nbsp; <span>My Applications</span>
        </div>

        <div class="topbar-right">
            <span class="online-dot"></span>
            CareerBridge Portal
        </div>
    </div>

    <section class="hero">
        <div>
            <div class="eyebrow">
                <span class="eyebrow-dot"></span>
                YOUR CAREER JOURNEY
            </div>

            <h1>My <span>Applications.</span></h1>

            <p>
                Every application is a step towards your future.
                Track your progress, discover opportunities, and stay ready
                for your next career milestone.
            </p>

            <div class="hero-actions">
                <a class="btn" href="internships.php">
                    + Find Internships
                </a>

                <a class="btn secondary" href="dashboard.php">
                    ← Dashboard
                </a>
            </div>
        </div>

        <div class="hero-icon" aria-hidden="true">↗</div>
    </section>

    <?php if (isset($_GET['applied'])): ?>
        <div class="success-notice">
            ✓ Application submitted successfully. Good luck with your application!
        </div>
    <?php endif; ?>

    <?php if ($error): ?>
        <div class="notice">
            <strong>Could not load your applications.</strong><br>
            <?= h($error) ?><br>
            Check your database connection and ensure the required tables and columns exist.
        </div>
    <?php endif; ?>

    <div class="section-heading">
        <div>
            <h2>Application Overview</h2>
            <p>Your current application statistics</p>
        </div>

        <span class="mini-label">CAREER INSIGHTS</span>
    </div>

    <section class="stats">

        <article class="stat">
            <div class="stat-top">
                <div class="stat-icon">▤</div>
                <span class="stat-tag">TOTAL</span>
            </div>

            <div class="stat-number counter" data-count="<?= $total ?>">0</div>
            <div class="stat-description">Total applications</div>
        </article>

        <article class="stat">
            <div class="stat-top">
                <div class="stat-icon">◷</div>
                <span class="stat-tag">IN PROGRESS</span>
            </div>

            <div class="stat-number counter" data-count="<?= $review ?>">0</div>
            <div class="stat-description">Waiting for a decision</div>
        </article>

        <article class="stat">
            <div class="stat-top">
                <div class="stat-icon">✦</div>
                <span class="stat-tag">NEXT STAGE</span>
            </div>

            <div class="stat-number counter" data-count="<?= $shortlisted ?>">0</div>
            <div class="stat-description">Shortlisted / interview</div>
        </article>

        <article class="stat">
            <div class="stat-top">
                <div class="stat-icon">✓</div>
                <span class="stat-tag">SUCCESS</span>
            </div>

            <div class="stat-number counter" data-count="<?= $selected ?>">0</div>
            <div class="stat-description">Selected applications</div>
        </article>

    </section>

    <div class="section-heading">
        <div>
            <h2>Application History</h2>
            <p>Search and filter your submitted applications.</p>
        </div>

        <div class="live-indicator">
            <span class="live-dot"></span>
            Your activity
        </div>
    </div>

    <section class="panel">

        <div class="panel-head">
            <div>
                <h2>All Applications</h2>
                <p>Your most recent application appears first.</p>
            </div>

            <a class="btn secondary" href="internships.php">
                Explore more →
            </a>
        </div>

        <?php if (!$error && $apps): ?>

            <div class="toolbar">
                <div class="search-wrap">
                    <span class="search-icon">⌕</span>

                    <input
                        type="search"
                        id="applicationSearch"
                        class="search-input"
                        placeholder="Search internship or company..."
                        aria-label="Search applications"
                    >
                </div>

                <select
                    id="statusFilter"
                    class="filter-select"
                    aria-label="Filter applications by status"
                >
                    <option value="">All statuses</option>
                    <option value="applied">Applied</option>
                    <option value="under review">Under Review</option>
                    <option value="shortlisted">Shortlisted</option>
                    <option value="interview">Interview</option>
                    <option value="selected">Selected</option>
                    <option value="rejected">Rejected</option>
                </select>
            </div>

            <div class="table-wrap">
                <table>
                    <thead>
                        <tr>
                            <th>Internship</th>
                            <th>Company</th>
                            <th>Location</th>
                            <th>Applied On</th>
                            <th>Status</th>
                        </tr>
                    </thead>

                    <tbody id="applicationRows">

                    <?php foreach ($apps as $index => $app): ?>
                        <?php
                            $status = (string)($app['status'] ?? 'Applied');
                            $title = (string)($app['title'] ?? 'Internship');
                            $companyName = (string)($app['company_name'] ?? 'Company');
                            $location = (string)($app['location'] ?? '');
                            $appliedAt = $app['applied_at'] ?? '';

                            $searchText = strtolower(
                                $title . ' ' . $companyName . ' ' .
                                $location . ' ' . $status
                            );

                            $formattedDate = '—';

                            if (!empty($appliedAt)) {
                                $timestamp = strtotime((string)$appliedAt);

                                if ($timestamp !== false) {
                                    $formattedDate = date('d M Y', $timestamp);
                                }
                            }
                        ?>

                        <tr
                            class="application-row"
                            data-search="<?= h($searchText) ?>"
                            data-status="<?= h(strtolower(trim($status))) ?>"
                            style="animation-delay:<?= min($index * 0.055, 0.5) ?>s"
                        >
                            <td>
                                <div class="job-cell">
                                    <div class="company-icon">✦</div>

                                    <div>
                                        <div class="job-title">
                                            <?= h($title) ?>
                                        </div>

                                        <div class="job-subtitle">
                                            Application #<?= (int)$app['id'] ?>
                                        </div>
                                    </div>
                                </div>
                            </td>

                            <td>
                                <span class="company-name">
                                    <?= h($companyName) ?>
                                </span>
                            </td>

                            <td>
                                <span class="location-name">
                                    <?= h($location !== '' ? $location : 'Not specified') ?>
                                </span>
                            </td>

                            <td>
                                <span class="date-name">
                                    <?= h($formattedDate) ?>
                                </span>
                            </td>

                            <td>
                                <span class="status <?= h(statusClass($status)) ?>">
                                    <?= h($status) ?>
                                </span>
                            </td>
                        </tr>

                    <?php endforeach; ?>

                    </tbody>
                </table>
            </div>

            <div class="no-results" id="noResults">
                No applications match your search. Try another keyword or status.
            </div>

        <?php elseif (!$error): ?>

            <div class="empty">
                <div class="empty-icon">▤</div>

                <h3>Your journey starts here, <?= h($firstName) ?>!</h3>

                <p>
                    You have not applied for an internship yet.
                    Explore opportunities that match your skills and take
                    your first step towards your career.
                </p>

                <a class="btn" href="internships.php">
                    Browse Internships →
                </a>
            </div>

        <?php else: ?>

            <div class="empty">
                <div class="empty-icon">!</div>

                <h3>Applications are temporarily unavailable</h3>

                <p>
                    Please check the database configuration and try again.
                </p>

                <a class="btn secondary" href="dashboard.php">
                    Return to Dashboard
                </a>
            </div>

        <?php endif; ?>

    </section>

    <footer class="foot">
        © <?= date('Y') ?> <span>CareerBridge</span> · Build your future, one application at a time.
    </footer>

</main>

<script>
document.addEventListener('DOMContentLoaded', () => {
    const reducedMotion = window.matchMedia(
        '(prefers-reduced-motion: reduce)'
    ).matches;

    // Animate statistics.
    document.querySelectorAll('.counter').forEach((counter, index) => {
        const target = Math.max(0, Number(counter.dataset.count) || 0);

        if (reducedMotion) {
            counter.textContent = target.toLocaleString();
            return;
        }

        const duration = 1000;
        const startTime = performance.now();

        function updateCounter(now) {
            const progress = Math.min((now - startTime) / duration, 1);
            const eased = 1 - Math.pow(1 - progress, 4);

            counter.textContent = Math.round(
                target * eased
            ).toLocaleString();

            if (progress < 1) {
                requestAnimationFrame(updateCounter);
            } else {
                counter.textContent = target.toLocaleString();
            }
        }

        setTimeout(() => {
            requestAnimationFrame(updateCounter);
        }, index * 100);
    });

    // Search and status filter.
    const searchInput = document.getElementById('applicationSearch');
    const statusFilter = document.getElementById('statusFilter');
    const rows = Array.from(document.querySelectorAll('.application-row'));
    const noResults = document.getElementById('noResults');

    function filterApplications() {
        const keyword = (searchInput?.value || '').trim().toLowerCase();
        const selectedStatus = (statusFilter?.value || '').toLowerCase();
        let visibleCount = 0;

        rows.forEach(row => {
            const searchableText = row.dataset.search || '';
            const rowStatus = row.dataset.status || '';

            const matchesSearch = searchableText.includes(keyword);
            const matchesStatus =
                !selectedStatus || rowStatus === selectedStatus;

            const visible = matchesSearch && matchesStatus;

            row.style.display = visible ? '' : 'none';

            if (visible) {
                visibleCount++;
            }
        });

        if (noResults) {
            noResults.style.display =
                rows.length > 0 && visibleCount === 0 ? 'block' : 'none';
        }
    }

    searchInput?.addEventListener('input', filterApplications);
    statusFilter?.addEventListener('change', filterApplications);
});
</script>

</body>
</html>
