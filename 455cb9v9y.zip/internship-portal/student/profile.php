
<?php
require_once __DIR__ . '/student_helper.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$success = '';
$error = '';
$student = [];
$pdo = null;
$newResumePath = null;
$resumeColumn = null;

try {
    $pdo = getPDO();
    $student = getStudentProfile();
    $studentId = (int)$student['id'];

    $availableColumns = $pdo
        ->query('SHOW COLUMNS FROM students')
        ->fetchAll(PDO::FETCH_COLUMN);

    foreach (['resume_path', 'resume', 'cv_path', 'cv'] as $candidate) {
        if (in_array($candidate, $availableColumns, true)) {
            $resumeColumn = $candidate;
            break;
        }
    }

    $uploadDirectory = __DIR__ . '/../uploads/resumes/';

    if (!is_dir($uploadDirectory)) {
        if (!mkdir($uploadDirectory, 0750, true) && !is_dir($uploadDirectory)) {
            throw new RuntimeException('Cannot create resume upload directory.');
        }
    }

    if (!is_writable($uploadDirectory)) {
        throw new RuntimeException('Resume upload directory is not writable.');
    }

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $phoneInput = trim($_POST['phone'] ?? '');
        $college = trim($_POST['college'] ?? '');
        $course = trim($_POST['course'] ?? '');
        $skills = trim($_POST['skills'] ?? '');

        $phoneDigits = preg_replace('/\D/', '', $phoneInput);

        if (strlen($phoneDigits) === 12 && substr($phoneDigits, 0, 2) === '91') {
            $phoneDigits = substr($phoneDigits, 2);
        }

        $phone = '';

        if ($phoneDigits !== '') {
            if (!preg_match('/^[6-9][0-9]{9}$/', $phoneDigits)) {
                $error = 'Enter a valid 10-digit Indian mobile number.';
            } else {
                $phone = '+91' . $phoneDigits;
            }
        }

        $updates = [];
        $values = [];

        foreach ([
            'phone' => $phone,
            'college' => $college,
            'course' => $course,
            'skills' => $skills
        ] as $column => $value) {
            if (in_array($column, $availableColumns, true)) {
                $updates[] = "`$column` = ?";
                $values[] = $value;
            }
        }

        $oldResumePath = $resumeColumn
            ? ($student[$resumeColumn] ?? '')
            : '';

        if (
            $error === '' &&
            isset($_FILES['resume']) &&
            $_FILES['resume']['error'] !== UPLOAD_ERR_NO_FILE
        ) {
            $file = $_FILES['resume'];

            if ($resumeColumn === null) {
                $error = 'Resume upload needs a resume_path column in the students table.';
            } elseif ($file['error'] !== UPLOAD_ERR_OK) {
                $error = 'The resume upload failed. Please try again.';
            } elseif ($file['size'] > 5 * 1024 * 1024) {
                $error = 'Resume file size must not exceed 5 MB.';
            } elseif (!is_uploaded_file($file['tmp_name'])) {
                $error = 'Invalid file upload.';
            } else {
                $extension = strtolower(
                    pathinfo($file['name'], PATHINFO_EXTENSION)
                );

                $allowedExtensions = ['pdf', 'doc', 'docx'];

                if (!in_array($extension, $allowedExtensions, true)) {
                    $error = 'Only PDF, DOC, and DOCX files are accepted.';
                } else {
                    $finfo = new finfo(FILEINFO_MIME_TYPE);
                    $mime = $finfo->file($file['tmp_name']);

                    $allowedMimeTypes = [
                        'pdf' => [
                            'application/pdf',
                            'application/x-pdf'
                        ],
                        'doc' => [
                            'application/msword',
                            'application/CDFV2',
                            'application/octet-stream'
                        ],
                        'docx' => [
                            'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
                            'application/zip',
                            'application/x-zip',
                            'application/octet-stream'
                        ]
                    ];

                    if (!in_array($mime, $allowedMimeTypes[$extension], true)) {
                        $error = 'The uploaded file is not a valid supported resume format.';
                    } else {
                        $fileName = bin2hex(random_bytes(20)) . '.' . $extension;
                        $destination = $uploadDirectory . $fileName;

                        if (!move_uploaded_file($file['tmp_name'], $destination)) {
                            $error = 'Could not save your resume. Check folder permissions.';
                        } else {
                            $newResumePath = 'uploads/resumes/' . $fileName;
                        }
                    }
                }
            }
        }

        if ($error === '') {
            if ($newResumePath !== null && $resumeColumn !== null) {
                $updates[] = "`$resumeColumn` = ?";
                $values[] = $newResumePath;
            }

            if (!$updates) {
                $error = 'No editable profile columns were found in your students table.';
            } else {
                $values[] = $studentId;

                $sql = 'UPDATE students SET '
                    . implode(', ', $updates)
                    . ' WHERE id = ?';

                try {
                    $stmt = $pdo->prepare($sql);
                    $stmt->execute($values);

                    $success = $newResumePath !== null
                        ? 'Profile saved and resume uploaded successfully!'
                        : 'Your profile has been saved successfully!';

                    if (
                        $newResumePath !== null &&
                        $oldResumePath !== '' &&
                        $oldResumePath !== $newResumePath &&
                        strpos($oldResumePath, '..') === false
                    ) {
                        $oldFile = __DIR__ . '/../' . ltrim($oldResumePath, '/');

                        $realOldFile = realpath($oldFile);
                        $realUploadDirectory = realpath($uploadDirectory);

                        if (
                            $realOldFile !== false &&
                            $realUploadDirectory !== false &&
                            is_file($realOldFile) &&
                            strpos(
                                $realOldFile,
                                $realUploadDirectory . DIRECTORY_SEPARATOR
                            ) === 0
                        ) {
                            @unlink($realOldFile);
                        }
                    }

                    $newResumePath = null;
                } catch (Throwable $e) {
                    if ($newResumePath !== null) {
                        $uploadedFile = $uploadDirectory . basename($newResumePath);

                        if (is_file($uploadedFile)) {
                            @unlink($uploadedFile);
                        }
                    }

                    throw $e;
                }
            }
        }

        $student = getStudentProfile();
    }
} catch (Throwable $e) {
    error_log('Student profile error: ' . $e->getMessage());
    http_response_code(500);

    exit(
        'Unable to load or save your profile. Check your database configuration, '
        . 'student table columns, and resume upload directory permissions.'
    );
}

$displayName = $student['full_name']
    ?? $student['name']
    ?? $student['user_name']
    ?? 'Student';

$email = $student['email'] ?? '';
$phoneValue = $student['phone'] ?? '';

if ($phoneValue !== '' && strpos($phoneValue, '+91') !== 0) {
    $digits = preg_replace('/\D/', '', $phoneValue);

    if (strlen($digits) === 10) {
        $phoneValue = '+91' . $digits;
    }
}

$currentResume = $resumeColumn !== null
    ? ($student[$resumeColumn] ?? '')
    : '';

$resumeFileName = $currentResume !== ''
    ? basename($currentResume)
    : '';

function profileEsc($value): string {
    return htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="theme-color" content="#090909">
<title>My Profile | CareerBridge</title>

<style>
:root {
    --bg: #090909;
    --sidebar: #111111;
    --panel: #171717;
    --panel-light: #202020;
    --orange: #ff7200;
    --orange-light: #ffa34d;
    --text: #f7f7f7;
    --muted: #a6a6a6;
    --line: #333333;
    --success: #8ee5a5;
    --danger: #ffaaaa;
}

* {
    box-sizing: border-box;
}

html {
    scroll-behavior: smooth;
}

body {
    margin: 0;
    min-height: 100vh;
    background:
        radial-gradient(ellipse at 85% 5%, #ff720014, transparent 35%),
        var(--bg);
    color: var(--text);
    font-family: "Segoe UI", Arial, sans-serif;
}

/* LEFT NAVIGATION */

.sidebar {
    position: fixed;
    inset: 0 auto 0 0;
    z-index: 10;
    width: 250px;
    padding: 28px 18px;
    display: flex;
    flex-direction: column;
    background: var(--sidebar);
    border-right: 1px solid var(--line);
}

.brand {
    display: block;
    padding: 8px 12px 32px;
    color: white;
    font-size: 23px;
    font-weight: 900;
    letter-spacing: -.7px;
    text-decoration: none;
}

.brand span {
    color: var(--orange);
}

.nav-label {
    margin: 0 12px 15px;
    color: #777;
    font-size: 10px;
    font-weight: 800;
    letter-spacing: 2px;
}

.nav-links {
    display: flex;
    flex-direction: column;
    gap: 8px;
}

.nav-links a {
    display: flex;
    align-items: center;
    gap: 13px;
    padding: 14px 15px;
    border: 1px solid transparent;
    border-radius: 10px;
    color: #bcbcbc;
    font-size: 13px;
    font-weight: 600;
    text-decoration: none;
    transition: background .25s, color .25s, border-color .25s;
}

.nav-icon {
    width: 22px;
    text-align: center;
    font-size: 17px;
}

.nav-links a:hover {
    color: white;
    background: #ffffff08;
    border-color: #333;
}

.nav-links a.active {
    color: var(--orange-light);
    background: #ff720016;
    border-color: #ff720044;
    box-shadow: inset 3px 0 var(--orange);
}

.sidebar-bottom {
    margin-top: auto;
    padding-top: 20px;
    border-top: 1px solid var(--line);
}

.sidebar-note {
    padding: 15px;
    background: var(--panel);
    border: 1px solid var(--line);
    border-radius: 12px;
}

.sidebar-note strong {
    display: block;
    margin-bottom: 6px;
    font-size: 12px;
}

.sidebar-note p {
    margin: 0;
    color: var(--muted);
    font-size: 11px;
    line-height: 1.7;
}

/* MAIN LAYOUT */

.main-content {
    margin-left: 250px;
    padding: 32px clamp(20px, 4vw, 55px);
}

.topbar {
    display: flex;
    justify-content: flex-end;
    margin-bottom: 24px;
}

.top-link {
    color: var(--orange-light);
    font-size: 13px;
    font-weight: 700;
    text-decoration: none;
    transition: color .2s;
}

.top-link:hover {
    color: white;
}

.profile-card {
    width: 100%;
    max-width: 1000px;
    margin: 0 auto;
    overflow: hidden;
    background: var(--panel);
    border: 1px solid var(--line);
    border-radius: 18px;
    box-shadow: 0 25px 70px #0005;
    animation: cardEnter .65s ease both;
}

@keyframes cardEnter {
    from {
        opacity: 0;
        transform: translateY(18px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

/* ORANGE PROFILE HEADER */

.hero {
    position: relative;
    overflow: hidden;
    padding: 34px;
    background: linear-gradient(110deg, #ff7900, #e85a00 70%, #a93800);
}

.hero::after {
    content: "";
    position: absolute;
    width: 190px;
    height: 190px;
    top: -100px;
    right: -35px;
    border: 30px solid #ffffff16;
    border-radius: 50%;
    pointer-events: none;
}

.hero h1 {
    position: relative;
    z-index: 1;
    margin: 0 0 10px;
    color: #111;
    font-size: clamp(26px, 4vw, 35px);
    letter-spacing: -.7px;
}

.hero p {
    position: relative;
    z-index: 1;
    max-width: 650px;
    margin: 0;
    color: #351900;
    font-size: 13px;
    line-height: 1.8;
}

.profile-content {
    padding: 30px 35px 35px;
}

/* STUDENT INFORMATION */

.account-panel {
    display: flex;
    align-items: center;
    gap: 18px;
    padding: 20px;
    margin-bottom: 28px;
    background: #202020;
    border: 1px solid #373737;
    border-radius: 13px;
}

.avatar {
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
    width: 60px;
    height: 60px;
    border-radius: 15px;
    background: var(--orange);
    color: #111;
    font-size: 25px;
    font-weight: 900;
}

.account-panel h2 {
    margin: 0 0 7px;
    font-size: 20px;
    overflow-wrap: anywhere;
}

.account-panel p {
    margin: 0;
    color: var(--muted);
    font-size: 13px;
    overflow-wrap: anywhere;
}

/* FORM SECTIONS */

.section-heading {
    margin: 28px 0 18px;
    padding-bottom: 13px;
    border-bottom: 1px solid var(--line);
    font-size: 17px;
    font-weight: 800;
}

.section-heading span {
    margin-right: 7px;
    color: var(--orange);
}

.form-grid {
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: 20px;
}

.field {
    min-width: 0;
}

.field.full {
    grid-column: 1 / -1;
}

label {
    display: block;
    margin-bottom: 9px;
    color: #f0f0f0;
    font-size: 13px;
    font-weight: 700;
}

input,
textarea {
    width: 100%;
    padding: 14px;
    border: 1px solid #414141;
    border-radius: 9px;
    outline: none;
    background: #101010;
    color: white;
    font: inherit;
    transition: border-color .25s, box-shadow .25s;
}

input::placeholder,
textarea::placeholder {
    color: #777;
}

input:focus,
textarea:focus {
    border-color: var(--orange);
    box-shadow: 0 0 0 3px #ff72001b;
}

textarea {
    min-height: 125px;
    resize: vertical;
    line-height: 1.7;
}

.phone-wrap {
    display: flex;
    overflow: hidden;
    border: 1px solid #414141;
    border-radius: 9px;
    background: #101010;
}

.phone-wrap:focus-within {
    border-color: var(--orange);
    box-shadow: 0 0 0 3px #ff72001b;
}

.phone-prefix {
    display: flex;
    align-items: center;
    padding: 0 14px;
    background: #252525;
    border-right: 1px solid #414141;
    color: var(--orange-light);
    font-weight: 800;
}

.phone-wrap input {
    border: 0;
    border-radius: 0;
    box-shadow: none;
}

.help {
    margin-top: 8px;
    color: #969696;
    font-size: 12px;
    line-height: 1.6;
}

/* RESUME UPLOAD */

.upload-box {
    padding: 22px;
    background: #131313;
    border: 1px dashed #6d4a30;
    border-radius: 12px;
    transition: border-color .25s, background .25s;
}

.upload-box:hover {
    border-color: var(--orange);
    background: #19140f;
}

.upload-icon {
    margin-bottom: 10px;
    color: var(--orange);
    font-size: 28px;
}

.upload-box input[type="file"] {
    margin-top: 12px;
    padding: 10px;
    font-size: 12px;
}

.upload-box input[type="file"]::file-selector-button {
    padding: 9px 12px;
    margin-right: 10px;
    border: 0;
    border-radius: 6px;
    background: var(--orange);
    color: #111;
    font-weight: 800;
    cursor: pointer;
}

.current-resume {
    display: flex;
    align-items: center;
    justify-content: space-between;
    flex-wrap: wrap;
    gap: 12px;
    margin-top: 16px;
    padding: 13px;
    background: #222;
    border: 1px solid #3d3d3d;
    border-radius: 9px;
}

.current-resume strong {
    overflow-wrap: anywhere;
}

.resume-label {
    margin-bottom: 5px;
    color: var(--orange-light);
    font-size: 11px;
    font-weight: 800;
}

.resume-check {
    color: var(--success);
    font-size: 22px;
}

/* MESSAGES */

.message {
    margin-bottom: 20px;
    padding: 14px 16px;
    border-radius: 9px;
    font-size: 13px;
    line-height: 1.6;
}

.success {
    color: var(--success);
    background: #123321;
    border: 1px solid #256340;
}

.error {
    color: var(--danger);
    background: #391919;
    border: 1px solid #743232;
}

/* ACTION BUTTONS */

.actions {
    display: flex;
    flex-wrap: wrap;
    gap: 12px;
    margin-top: 28px;
}

.btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    min-height: 46px;
    padding: 12px 20px;
    border: 1px solid transparent;
    border-radius: 9px;
    font-size: 13px;
    font-weight: 800;
    text-decoration: none;
    cursor: pointer;
    transition: transform .2s, box-shadow .2s, background .2s;
}

.btn:hover {
    transform: translateY(-2px);
}

.btn-primary {
    background: var(--orange);
    color: #111;
    box-shadow: 0 5px 18px #ff720020;
}

.btn-primary:hover {
    background: #ffa34d;
    box-shadow: 0 8px 25px #ff720044;
}

.btn-secondary {
    background: #292929;
    color: white;
    border-color: #454545;
}

.btn-secondary:hover {
    background: #383838;
}

.footer-note {
    margin: 22px 0 0;
    color: #888;
    font-size: 12px;
    line-height: 1.7;
}

/* RESPONSIVE NAVIGATION AND FORM */

@media (max-width: 850px) {
    .sidebar {
        position: relative;
        inset: auto;
        width: 100%;
        padding: 15px 18px;
        border-right: 0;
        border-bottom: 1px solid var(--line);
    }

    .brand {
        padding: 5px 5px 15px;
        font-size: 22px;
    }

    .nav-label,
    .sidebar-bottom {
        display: none;
    }

    .nav-links {
        flex-direction: row;
        flex-wrap: wrap;
        gap: 7px;
    }

    .nav-links a {
        flex: 1 1 auto;
        justify-content: center;
        padding: 11px 12px;
        font-size: 11px;
    }

    .nav-links a.active {
        box-shadow: inset 0 -3px var(--orange);
    }

    .main-content {
        margin-left: 0;
        padding: 24px 18px;
    }
}

@media (max-width: 600px) {
    .main-content {
        padding: 18px 10px;
    }

    .profile-content {
        padding: 22px 16px;
    }

    .hero {
        padding: 25px 20px;
    }

    .form-grid {
        grid-template-columns: 1fr;
        gap: 17px;
    }

    .field.full {
        grid-column: auto;
    }

    .account-panel {
        align-items: flex-start;
        padding: 14px;
    }

    .avatar {
        width: 48px;
        height: 48px;
        font-size: 21px;
    }

    .actions .btn {
        width: 100%;
    }

    .nav-links a {
        flex: 1 1 40%;
    }
}

@media (prefers-reduced-motion: reduce) {
    *,
    *::before,
    *::after {
        animation: none !important;
        transition: none !important;
        scroll-behavior: auto !important;
    }
}
</style>
</head>

<body>

<!-- LEFT SIDEBAR -->
<aside class="sidebar">
    <a class="brand" href="dashboard.php">
        Career<span>Bridge</span>
    </a>

    <p class="nav-label">STUDENT MENU</p>

    <nav class="nav-links" aria-label="Student navigation">
        <a href="dashboard.php">
            <span class="nav-icon">⌂</span>
            Dashboard
        </a>

        <a href="profile.php" class="active" aria-current="page">
            <span class="nav-icon">◉</span>
            My Profile
        </a>

        <a href="internships.php">
            <span class="nav-icon">▤</span>
            Internships
        </a>

        <a href="applications.php">
            <span class="nav-icon">✓</span>
            Applications
        </a>

        <a href="../logout.php">
            <span class="nav-icon">↪</span>
            Sign out
        </a>
    </nav>

    <div class="sidebar-bottom">
        <div class="sidebar-note">
            <strong>Your career starts here.</strong>
            <p>Keep your profile updated and prepare for your next opportunity.</p>
        </div>
    </div>
</aside>

<!-- MAIN PROFILE PAGE -->
<main class="main-content">

    <div class="topbar">
        <a class="top-link" href="dashboard.php">&larr; Back to Dashboard</a>
    </div>

    <section class="profile-card">

        <header class="hero">
            <h1>My Student Profile</h1>
            <p>
                Build your professional profile and keep your resume ready
                for internship applications.
            </p>
        </header>

        <div class="profile-content">

            <div class="account-panel">
                <div class="avatar">
                    <?= profileEsc(strtoupper(substr(trim($displayName), 0, 1))) ?>
                </div>

                <div>
                    <h2><?= profileEsc($displayName) ?></h2>
                    <p><?= profileEsc($email) ?></p>
                </div>
            </div>

            <?php if ($success !== ''): ?>
                <div class="message success" role="status">
                    &#10003; <?= profileEsc($success) ?>
                </div>
            <?php endif; ?>

            <?php if ($error !== ''): ?>
                <div class="message error" role="alert">
                    <?= profileEsc($error) ?>
                </div>
            <?php endif; ?>

            <form method="post" enctype="multipart/form-data">

                <h3 class="section-heading">
                    <span>01.</span> Personal &amp; Academic Details
                </h3>

                <div class="form-grid">

                    <div class="field">
                        <label for="phone">Mobile Number</label>

                        <div class="phone-wrap">
                            <span class="phone-prefix">+91</span>
                            <input
                                id="phone"
                                name="phone"
                                type="tel"
                                inputmode="numeric"
                                maxlength="10"
                                pattern="[6-9][0-9]{9}"
                                placeholder="9876543210"
                                value="<?= profileEsc(
                                    preg_replace('/^\+91/', '', $phoneValue)
                                ) ?>"
                            >
                        </div>

                        <div class="help">
                            Enter your 10-digit Indian mobile number.
                        </div>
                    </div>

                    <div class="field">
                        <label for="college">College / University</label>
                        <input
                            id="college"
                            name="college"
                            type="text"
                            maxlength="150"
                            placeholder="Enter your college name"
                            value="<?= profileEsc($student['college'] ?? '') ?>"
                        >
                    </div>

                    <div class="field full">
                        <label for="course">Course / Department</label>
                        <input
                            id="course"
                            name="course"
                            type="text"
                            maxlength="150"
                            placeholder="Example: B.E. Computer Science"
                            value="<?= profileEsc($student['course'] ?? '') ?>"
                        >
                    </div>

                    <div class="field full">
                        <label for="skills">Skills</label>
                        <textarea
                            id="skills"
                            name="skills"
                            maxlength="5000"
                            placeholder="Example: PHP, MySQL, HTML, CSS, JavaScript"
                        ><?= profileEsc($student['skills'] ?? '') ?></textarea>

                        <div class="help">
                            Separate your skills with commas.
                        </div>
                    </div>

                </div>

                <h3 class="section-heading">
                    <span>02.</span> Resume &amp; Documents
                </h3>

                <div class="upload-box">
                    <div class="upload-icon" aria-hidden="true">&#128196;</div>

                    <label for="resume">Upload Your Resume</label>

                    <div class="help">
                        Supported formats: PDF, DOC, DOCX. Maximum size: 5 MB.
                    </div>

                    <input
                        id="resume"
                        name="resume"
                        type="file"
                        accept=".pdf,.doc,.docx"
                    >

                    <?php if ($resumeFileName !== ''): ?>
                        <div class="current-resume">
                            <div>
                                <div class="resume-label">CURRENT RESUME</div>
                                <strong><?= profileEsc($resumeFileName) ?></strong>
                            </div>
                            <span class="resume-check" aria-label="Resume uploaded">
                                &#10003;
                            </span>
                        </div>
                    <?php else: ?>
                        <div class="help">
                            No resume uploaded yet. Select a file above to add one.
                        </div>
                    <?php endif; ?>

                    <div class="help">
                        Uploading a new resume replaces your previous resume.
                    </div>
                </div>

                <div class="actions">
                    <button type="submit" class="btn btn-primary">
                        &#10003; Save Profile
                    </button>

                    <a href="dashboard.php" class="btn btn-secondary">
                        Back to Dashboard
                    </a>
                </div>

                <p class="footer-note">
                    Keep your profile and resume updated before applying for internships.
                    Your account name and email are managed by your login account.
                </p>

            </form>
        </div>
    </section>
</main>

<script>
const resumeInput = document.getElementById('resume');

resumeInput.addEventListener('change', function () {
    const file = this.files[0];

    if (!file) return;

    if (!/\.(pdf|doc|docx)$/i.test(file.name)) {
        alert('Please choose a PDF, DOC, or DOCX file.');
        this.value = '';
        return;
    }

    if (file.size > 5 * 1024 * 1024) {
        alert('Your resume must be 5 MB or smaller.');
        this.value = '';
    }
});

const phoneInput = document.getElementById('phone');

phoneInput.addEventListener('input', function () {
    this.value = this.value.replace(/\D/g, '').slice(0, 10);
});
</script>

</body>
</html>
