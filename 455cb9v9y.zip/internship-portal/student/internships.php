
<?php
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

require_once __DIR__ . '/../config/database.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit;
}

if (($_SESSION['role'] ?? '') !== 'student') {
    header('Location: ../index.php');
    exit;
}

function cbEsc($value): string {
    return htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8');
}

function cbColumns(PDO $pdo, string $table): array {
    $allowed = [
        'users', 'students', 'companies',
        'internships', 'applications'
    ];

    if (!in_array($table, $allowed, true)) {
        return [];
    }

    return $pdo->query("SHOW COLUMNS FROM `$table`")
        ->fetchAll(PDO::FETCH_COLUMN);
}

function cbPick(array $available, array $choices): ?string {
    foreach ($choices as $choice) {
        if (in_array($choice, $available, true)) {
            return $choice;
        }
    }

    return null;
}

$internships = [];
$error = '';
$q = trim((string)($_GET['q'] ?? ''));
$location = trim((string)($_GET['location'] ?? ''));

try {
    $pdo = getPDO();

    $studentCols = cbColumns($pdo, 'students');
    $internCols = cbColumns($pdo, 'internships');
    $companyCols = cbColumns($pdo, 'companies');
    $appCols = cbColumns($pdo, 'applications');

    $studentUserCol = cbPick($studentCols, [
        'user_id', 'users_id', 'userId'
    ]);

    $studentIdCol = cbPick($studentCols, [
        'id', 'student_id'
    ]);

    if (!$studentUserCol || !$studentIdCol) {
        throw new RuntimeException(
            'The students table needs student ID and user ID columns.'
        );
    }

    $stmt = $pdo->prepare(
        "SELECT `$studentIdCol`
         FROM students
         WHERE `$studentUserCol` = ?
         LIMIT 1"
    );

    $stmt->execute([$_SESSION['user_id']]);
    $studentId = $stmt->fetchColumn();

    if (!$studentId) {
        throw new RuntimeException(
            'Student profile not found. Check students.user_id and users.id.'
        );
    }

    $idCol = cbPick($internCols, [
        'id', 'internship_id'
    ]);

    $titleCol = cbPick($internCols, [
        'title', 'internship_title', 'name', 'position'
    ]);

    $descriptionCol = cbPick($internCols, [
        'description', 'details', 'job_description'
    ]);

    $skillsCol = cbPick($internCols, [
        'skills_required', 'required_skills', 'skills',
        'skill_requirements'
    ]);

    $locationCol = cbPick($internCols, [
        'location', 'work_location', 'city'
    ]);

    $durationCol = cbPick($internCols, [
        'duration', 'internship_duration'
    ]);

    $stipendCol = cbPick($internCols, [
        'stipend', 'salary', 'monthly_stipend', 'pay'
    ]);

    $deadlineCol = cbPick($internCols, [
        'deadline', 'application_deadline', 'last_date'
    ]);

    $createdCol = cbPick($internCols, [
        'created_at', 'posted_at', 'date_posted'
    ]);

    $companyFk = cbPick($internCols, [
        'company_id', 'companies_id'
    ]);

    $companyIdCol = cbPick($companyCols, [
        'id', 'company_id'
    ]);

    $companyNameCol = cbPick($companyCols, [
        'company_name', 'name', 'business_name'
    ]);

    if (!$idCol || !$titleCol) {
        throw new RuntimeException(
            'The internships table needs an ID column and a title column.'
        );
    }

    $field = function (?string $column, string $alias): string {
        return $column
            ? "i.`$column` AS `$alias`"
            : "'' AS `$alias`";
    };

    $select = [
        $field($idCol, 'id'),
        $field($titleCol, 'title'),
        $field($descriptionCol, 'description'),
        $field($skillsCol, 'skills_required'),
        $field($locationCol, 'location'),
        $field($durationCol, 'duration'),
        $field($stipendCol, 'stipend'),
        $field($deadlineCol, 'deadline'),
        $field($createdCol, 'created_at')
    ];

    $joinCompany = $companyFk && $companyIdCol;

    if ($joinCompany) {
        $select[] = $companyNameCol
            ? "c.`$companyNameCol` AS company_name"
            : "'Company' AS company_name";
    } else {
        $select[] = "'Company' AS company_name";
    }

    $where = [];
    $params = [];

    if ($deadlineCol) {
        $where[] = "(
            i.`$deadlineCol` IS NULL
            OR i.`$deadlineCol` = ''
            OR i.`$deadlineCol` >= CURDATE()
        )";
    }

    if ($q !== '') {
        $searchParts = [];

        foreach ([$titleCol, $descriptionCol, $skillsCol] as $column) {
            if ($column) {
                $searchParts[] = "i.`$column` LIKE ?";
                $params[] = '%' . $q . '%';
            }
        }

        if ($joinCompany && $companyNameCol) {
            $searchParts[] = "c.`$companyNameCol` LIKE ?";
            $params[] = '%' . $q . '%';
        }

        if ($searchParts) {
            $where[] = '(' . implode(' OR ', $searchParts) . ')';
        }
    }

    if ($location !== '' && $locationCol) {
        $where[] = "i.`$locationCol` LIKE ?";
        $params[] = '%' . $location . '%';
    }

    $appInternCol = cbPick($appCols, [
        'internship_id', 'internships_id'
    ]);

    $appStudentCol = cbPick($appCols, [
        'student_id', 'students_id'
    ]);

    $hasApplicationInfo = $appInternCol && $appStudentCol;

    if ($hasApplicationInfo) {
        $select[] = "CASE WHEN EXISTS (
            SELECT 1
            FROM applications a
            WHERE a.`$appInternCol` = i.`$idCol`
              AND a.`$appStudentCol` = ?
        ) THEN 1 ELSE 0 END AS already_applied";

        array_unshift($params, (int)$studentId);
    } else {
        $select[] = '0 AS already_applied';
    }

    $sql = 'SELECT ' . implode(', ', $select) . ' FROM internships i';

    if ($joinCompany) {
        $sql .= " LEFT JOIN companies c
                  ON c.`$companyIdCol` = i.`$companyFk`";
    }

    if ($where) {
        $sql .= ' WHERE ' . implode(' AND ', $where);
    }

    $sql .= $createdCol
        ? " ORDER BY i.`$createdCol` DESC, i.`$idCol` DESC"
        : " ORDER BY i.`$idCol` DESC";

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $internships = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (Throwable $e) {
    error_log('Internships page error: ' . $e->getMessage());
    $error = $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="theme-color" content="#080808">
<title>Find Internships | CareerBridge</title>

<style>
:root {
    --bg: #080808;
    --sidebar: #101010;
    --panel: #151515;
    --panel-hover: #1d1d1d;
    --line: #303030;
    --text: #f7f7f7;
    --muted: #a6a6a6;
    --orange: #ff6a00;
    --orange-light: #ff9d45;
    --orange-soft: rgba(255, 106, 0, .12);
}

* {
    box-sizing: border-box;
}

html {
    scroll-behavior: smooth;
}

body {
    margin: 0;
    min-height: 100vh;
    background: var(--bg);
    color: var(--text);
    font-family: "Segoe UI", Arial, sans-serif;
}

a {
    color: inherit;
    text-decoration: none;
}

button,
input {
    font: inherit;
}

/* LEFT SIDEBAR */

.sidebar {
    position: fixed;
    inset: 0 auto 0 0;
    z-index: 10;
    width: 250px;
    padding: 28px 18px;
    display: flex;
    flex-direction: column;
    background: var(--sidebar);
    border-right: 1px solid var(--line);
}

.brand {
    display: block;
    padding: 8px 12px 30px;
    font-size: 24px;
    font-weight: 900;
    letter-spacing: -.8px;
}

.brand span {
    color: var(--orange);
}

.side-label {
    margin: 10px 12px 14px;
    color: #777;
    font-size: 10px;
    font-weight: 800;
    letter-spacing: 2px;
}

.nav-links {
    display: flex;
    flex-direction: column;
    gap: 8px;
}

.nav-links a {
    display: flex;
    align-items: center;
    gap: 13px;
    padding: 14px 15px;
    border: 1px solid transparent;
    border-radius: 10px;
    color: #bcbcbc;
    font-size: 13px;
    font-weight: 600;
    transition: .25s ease;
}

.nav-icon {
    width: 22px;
    text-align: center;
    font-size: 17px;
}

.nav-links a:hover {
    color: white;
    background: #ffffff08;
    border-color: #303030;
    transform: translateX(3px);
}

.nav-links a.active {
    color: var(--orange-light);
    background: var(--orange-soft);
    border-color: #ff6a003d;
    box-shadow: inset 3px 0 var(--orange);
}

.sidebar-bottom {
    margin-top: auto;
    padding-top: 20px;
    border-top: 1px solid var(--line);
}

.account-card {
    padding: 15px;
    border: 1px solid var(--line);
    border-radius: 12px;
    background: #171717;
}

.account-title {
    margin: 0 0 5px;
    font-size: 12px;
    font-weight: 800;
}

.account-subtitle {
    margin: 0;
    color: var(--muted);
    font-size: 11px;
    line-height: 1.6;
}

/* MAIN PAGE */

.main-content {
    min-height: 100vh;
    margin-left: 250px;
    padding: 38px clamp(20px, 4vw, 55px);
}

.page-header {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    gap: 20px;
    margin-bottom: 30px;
}

.eyebrow {
    display: inline-flex;
    align-items: center;
    gap: 9px;
    color: var(--orange-light);
    font-size: 10px;
    font-weight: 900;
    letter-spacing: 2px;
}

.eyebrow::before {
    content: "";
    width: 7px;
    height: 7px;
    border-radius: 50%;
    background: var(--orange);
    box-shadow: 0 0 12px #ff6a0080;
}

h1 {
    margin: 12px 0;
    font-size: clamp(28px, 3.2vw, 40px);
    line-height: 1.2;
    letter-spacing: -1px;
}

.intro {
    max-width: 680px;
    color: var(--muted);
    font-size: 13px;
    line-height: 1.8;
}

.header-tag {
    flex-shrink: 0;
    padding: 10px 13px;
    border: 1px solid #ff6a0045;
    border-radius: 9px;
    background: var(--orange-soft);
    color: var(--orange-light);
    font-size: 11px;
    font-weight: 700;
}

/* ERROR MESSAGE */

.notice {
    margin: 20px 0;
    padding: 16px;
    border: 1px solid #ff6a0055;
    border-radius: 12px;
    background: #ff6a000e;
    color: #ffc18f;
    font-size: 12px;
    line-height: 1.8;
    overflow-wrap: anywhere;
}

/* SEARCH BAR */

.search {
    display: grid;
    grid-template-columns: minmax(150px, 1.5fr) minmax(130px, 1fr) auto auto;
    gap: 10px;
    padding: 16px;
    margin: 25px 0;
    border: 1px solid var(--line);
    border-radius: 14px;
    background: var(--panel);
}

.search input {
    width: 100%;
    min-width: 0;
    padding: 13px 14px;
    border: 1px solid #363636;
    border-radius: 9px;
    outline: none;
    background: #0b0b0b;
    color: white;
    font-size: 12px;
    transition: border-color .25s, box-shadow .25s;
}

.search input::placeholder {
    color: #777;
}

.search input:focus {
    border-color: var(--orange);
    box-shadow: 0 0 0 3px #ff6a001b;
}

/* BUTTONS */

.btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    padding: 12px 17px;
    border: 1px solid var(--orange);
    border-radius: 9px;
    background: var(--orange);
    color: #111;
    font-size: 12px;
    font-weight: 800;
    white-space: nowrap;
    cursor: pointer;
    transition: .25s ease;
}

.btn:hover {
    background: var(--orange-light);
    border-color: var(--orange-light);
    box-shadow: 0 7px 22px #ff6a0029;
    transform: translateY(-2px);
}

.btn:active {
    transform: translateY(0);
}

.btn.outline {
    color: #eee;
    border-color: #414141;
    background: #202020;
}

.btn.outline:hover {
    color: var(--orange-light);
    border-color: var(--orange);
    background: var(--orange-soft);
    box-shadow: none;
}

.btn:focus-visible,
.nav-links a:focus-visible {
    outline: 2px solid var(--orange-light);
    outline-offset: 3px;
}

/* RESULT COUNT */

.results-bar {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 12px;
    margin: 26px 0 16px;
}

.count {
    margin: 0;
    color: var(--muted);
    font-size: 12px;
}

.count strong {
    color: var(--orange-light);
    font-size: 15px;
}

/* INTERNSHIP CARDS */

.grid {
    display: grid;
    grid-template-columns: repeat(3, minmax(0, 1fr));
    gap: 18px;
}

.card {
    min-width: 0;
    display: flex;
    flex-direction: column;
    padding: 22px;
    border: 1px solid var(--line);
    border-radius: 15px;
    background: linear-gradient(145deg, #191919, #101010);
    box-shadow: 0 12px 30px #0003;
    opacity: 0;
    animation: cardEnter .5s ease forwards;
    transition: border-color .25s, transform .25s, box-shadow .25s;
}

@keyframes cardEnter {
    from {
        opacity: 0;
        transform: translateY(14px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.card:hover {
    transform: translateY(-5px);
    border-color: #ff6a0075;
    box-shadow: 0 18px 38px #0005, 0 0 20px #ff6a0009;
}

.card h2 {
    margin: 0 0 9px;
    font-size: 17px;
    line-height: 1.5;
    overflow-wrap: anywhere;
}

.company {
    margin: 0 0 15px;
    color: var(--orange-light);
    font-size: 12px;
    font-weight: 700;
}

.description {
    margin: 0 0 15px;
    color: #bcbcbc;
    font-size: 12px;
    line-height: 1.8;
    overflow-wrap: anywhere;
    white-space: pre-line;
}

.skills {
    margin: 0 0 15px;
    color: #c9c9c9;
    font-size: 11px;
    line-height: 1.8;
    overflow-wrap: anywhere;
}

.skills strong {
    color: var(--orange-light);
}

.meta {
    display: flex;
    flex-wrap: wrap;
    gap: 7px;
    margin: 0 0 20px;
}

.pill {
    padding: 7px 9px;
    border: 1px solid #353535;
    border-radius: 7px;
    background: #202020;
    color: #c5c5c5;
    font-size: 10px;
    line-height: 1.5;
    overflow-wrap: anywhere;
}

.card .btn,
.card .applied {
    width: 100%;
    margin-top: auto;
}

.applied {
    padding: 12px;
    border: 1px solid #ff6a0045;
    border-radius: 9px;
    background: var(--orange-soft);
    color: var(--orange-light);
    text-align: center;
    font-size: 12px;
    font-weight: 800;
}

/* EMPTY STATE */

.empty {
    grid-column: 1 / -1;
    padding: 48px 20px;
    border: 1px dashed #414141;
    border-radius: 14px;
    background: #121212;
    text-align: center;
}

.empty-icon {
    margin-bottom: 12px;
    color: var(--orange);
    font-size: 34px;
}

.empty h3 {
    margin: 0 0 10px;
    font-size: 18px;
}

.empty p {
    margin: 0 0 20px;
    color: var(--muted);
    font-size: 12px;
    line-height: 1.8;
}

/* FOOTER */

footer {
    margin-top: 40px;
    padding: 22px 0 8px;
    border-top: 1px solid #242424;
    color: #777;
    text-align: center;
    font-size: 10px;
    letter-spacing: .4px;
}

/* RESPONSIVE */

@media (max-width: 1200px) {
    .grid {
        grid-template-columns: repeat(2, minmax(0, 1fr));
    }

    .main-content {
        padding: 30px;
    }
}

@media (max-width: 850px) {
    .sidebar {
        position: relative;
        inset: auto;
        width: 100%;
        padding: 15px 18px;
        border-right: 0;
        border-bottom: 1px solid var(--line);
    }

    .brand {
        padding: 5px 5px 15px;
        font-size: 22px;
    }

    .side-label,
    .sidebar-bottom {
        display: none;
    }

    .nav-links {
        flex-direction: row;
        flex-wrap: wrap;
        gap: 7px;
    }

    .nav-links a {
        flex: 1 1 auto;
        justify-content: center;
        gap: 7px;
        padding: 11px 12px;
        font-size: 11px;
    }

    .nav-links a.active {
        box-shadow: inset 0 -3px var(--orange);
    }

    .main-content {
        margin-left: 0;
        padding: 28px 22px;
    }
}

@media (max-width: 600px) {
    .main-content {
        padding: 23px 15px;
    }

    .page-header {
        display: block;
    }

    .header-tag {
        display: inline-block;
        margin-top: 8px;
    }

    .search {
        grid-template-columns: 1fr 1fr;
        padding: 12px;
    }

    .search input:first-child {
        grid-column: 1 / -1;
    }

    .search .btn {
        width: 100%;
        padding: 12px 8px;
    }

    .grid {
        grid-template-columns: 1fr;
    }

    .card {
        padding: 19px;
    }

    .nav-links a {
        flex: 1 1 40%;
    }

    .nav-icon {
        font-size: 15px;
    }
}

@media (prefers-reduced-motion: reduce) {
    *,
    *::before,
    *::after {
        animation: none !important;
        transition: none !important;
        scroll-behavior: auto !important;
    }

    .card {
        opacity: 1;
    }
}
</style>
</head>

<body>

<!-- LEFT NAVIGATION -->
<aside class="sidebar">
    <a class="brand" href="dashboard.php">
        Career<span>Bridge</span>
    </a>

    <p class="side-label">STUDENT MENU</p>

    <nav class="nav-links" aria-label="Student navigation">
        <a href="dashboard.php">
            <span class="nav-icon">⌂</span>
            Dashboard
        </a>

        <a href="profile.php">
            <span class="nav-icon">◉</span>
            My Profile
        </a>

        <a class="active" href="internships.php" aria-current="page">
            <span class="nav-icon">▤</span>
            Internships
        </a>

        <a href="applications.php">
            <span class="nav-icon">✓</span>
            Applications
        </a>

        <a href="../logout.php">
            <span class="nav-icon">↪</span>
            Sign out
        </a>
    </nav>

    <div class="sidebar-bottom">
        <div class="account-card">
            <p class="account-title">Career starts here.</p>
            <p class="account-subtitle">
                Find opportunities and build your future.
            </p>
        </div>
    </div>
</aside>

<!-- MAIN CONTENT -->
<main class="main-content">

    <header class="page-header">
        <div>
            <span class="eyebrow">EXPLORE OPPORTUNITIES</span>

            <h1>Find your next internship.</h1>

            <p class="intro">
                Discover opportunities, learn new skills, and take the next
                step in your career.
            </p>
        </div>

        <div class="header-tag">● Student Portal</div>
    </header>

    <?php if ($error !== ''): ?>
        <div class="notice" role="alert">
            <strong>Internships could not be loaded.</strong><br>
            <?= cbEsc($error) ?>
            <br>
            Check that your database tables and column relationships match
            the application configuration.
        </div>
    <?php endif; ?>

    <!-- SEARCH AND LOCATION FILTER -->
    <form class="search" method="get" action="internships.php">
        <input
            type="search"
            name="q"
            placeholder="Search title, company or skills"
            aria-label="Search internships"
            value="<?= cbEsc($q) ?>"
        >

        <input
            type="text"
            name="location"
            placeholder="Filter by location"
            aria-label="Filter by location"
            value="<?= cbEsc($location) ?>"
        >

        <button class="btn" type="submit">Search</button>

        <a class="btn outline" href="internships.php">Clear</a>
    </form>

    <div class="results-bar">
        <p class="count">
            <strong><?= count($internships) ?></strong>
            internship<?= count($internships) === 1 ? '' : 's' ?> found
        </p>
    </div>

    <!-- INTERNSHIP CARDS -->
    <section class="grid" aria-label="Available internships">

        <?php if (!$internships && $error === ''): ?>
            <div class="empty">
                <div class="empty-icon">⌕</div>

                <h3>No matching internships</h3>

                <p>
                    Try another keyword or remove the location filter.
                </p>

                <a class="btn" href="internships.php">
                    Show all internships
                </a>
            </div>
        <?php endif; ?>

        <?php foreach ($internships as $index => $item): ?>
            <article
                class="card"
                style="animation-delay: <?= min($index * 0.07, 0.7) ?>s"
            >
                <h2><?= cbEsc($item['title']) ?></h2>

                <p class="company">
                    <?= cbEsc($item['company_name']) ?>
                </p>

                <p class="description"><?= cbEsc(
                    $item['description'] ?: 'No description provided.'
                ) ?></p>

                <p class="skills">
                    <strong>Skills:</strong>
                    <?= cbEsc(
                        $item['skills_required'] ?: 'Not specified'
                    ) ?>
                </p>

                <div class="meta">
                    <span class="pill">
                        Location:
                        <?= cbEsc($item['location'] ?: 'Not specified') ?>
                    </span>

                    <span class="pill">
                        Duration:
                        <?= cbEsc($item['duration'] ?: 'Not specified') ?>
                    </span>

                    <span class="pill">
                        Stipend:
                        <?= cbEsc($item['stipend'] ?: 'Not specified') ?>
                    </span>

                    <span class="pill">
                        Deadline:
                        <?= cbEsc($item['deadline'] ?: 'Not specified') ?>
                    </span>
                </div>

                <?php if (!empty($item['already_applied'])): ?>
                    <div class="applied">
                        ✓ Already applied
                    </div>
                <?php else: ?>
                    <a
                        class="btn"
                        href="apply.php?id=<?= (int)$item['id'] ?>"
                    >
                        View &amp; Apply
                        <span aria-hidden="true">→</span>
                    </a>
                <?php endif; ?>
            </article>
        <?php endforeach; ?>

    </section>

    <footer>
        CareerBridge · Opportunities that move you forward.
    </footer>
</main>

</body>
</html>
