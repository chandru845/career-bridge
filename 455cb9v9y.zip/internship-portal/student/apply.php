<?php
session_start();
require_once "../config/database.php";
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'student') { header("Location: ../login.php"); exit; }

try {
    $pdo = getPDO();
} catch (Throwable $e) {
    http_response_code(500);
    exit(htmlspecialchars($e->getMessage()));
}

$id = (int)($_GET['id'] ?? $_POST['internship_id'] ?? 0);
$stmt = $pdo->prepare("SELECT i.*, c.company_name FROM internships i JOIN companies c ON c.id=i.company_id WHERE i.id=?");
$stmt->execute([$id]); $internship = $stmt->fetch();

if (!$internship) { die("Internship not found."); }
if ($internship['deadline'] && $internship['deadline'] < date('Y-m-d')) { die("The application deadline has passed."); }

$stmt = $pdo->prepare("SELECT s.id FROM students s WHERE s.user_id=?");
$stmt->execute([$_SESSION['user_id']]); $student = $stmt->fetch();

$error = "";
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $cover = trim($_POST['cover_letter'] ?? '');
    try {
        $stmt = $pdo->prepare("INSERT INTO applications (internship_id,student_id,cover_letter) VALUES (?,?,?)");
        $stmt->execute([$id, $student['id'], $cover]);
        header("Location: applications.php?applied=1"); exit;
    } catch (PDOException $e) {
        $error = ($e->getCode() === '23000') ? "You have already applied for this internship." : "Application could not be submitted.";
    }
}
?>
<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Apply</title><link rel="stylesheet" href="../css/style.css"></head>
<body>
<nav class="navbar"><a class="brand" href="dashboard.php">CareerBridge</a><div><a class="nav-link" href="internships.php">Internships</a><a class="btn btn-small" href="../logout.php">Logout</a></div></nav>
<main class="container narrow page"><a href="internships.php">← Back to internships</a><div class="card apply-card"><span class="badge">APPLICATION</span><h1><?= htmlspecialchars($internship['title']) ?></h1><h3><?= htmlspecialchars($internship['company_name']) ?></h3><p><?= nl2br(htmlspecialchars($internship['description'])) ?></p>
<?php if($error): ?><div class="alert error"><?= htmlspecialchars($error) ?></div><?php endif; ?>
<form method="POST"><input type="hidden" name="internship_id" value="<?= (int)$id ?>">
<label>Cover Letter</label><textarea name="cover_letter" rows="8" placeholder="Tell the company why you are suitable for this internship..."></textarea>
<button class="btn" type="submit">Submit Application</button></form></div></main></body></html>