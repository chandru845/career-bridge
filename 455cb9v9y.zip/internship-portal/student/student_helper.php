
<?php
// student/student_helper.php
// Shared student account/profile validation and creation.

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/../config/database.php';

function getStudentProfile(): array
{
    if (
        empty($_SESSION['user_id']) ||
        ($_SESSION['role'] ?? '') !== 'student'
    ) {
        header('Location: ../login.php');
        exit;
    }

    $pdo = getPDO();
    $userId = (int) $_SESSION['user_id'];

    // Confirm that the logged-in account exists and is a student.
    $stmt = $pdo->prepare(
        'SELECT id, name, email, role
         FROM users
         WHERE id = ?
         LIMIT 1'
    );
    $stmt->execute([$userId]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user || $user['role'] !== 'student') {
        session_unset();
        session_destroy();
        header('Location: ../login.php');
        exit;
    }

    // Check whether this account already has a student profile.
    $stmt = $pdo->prepare(
        'SELECT *
         FROM students
         WHERE user_id = ?
         LIMIT 1'
    );
    $stmt->execute([$userId]);
    $student = $stmt->fetch(PDO::FETCH_ASSOC);

    // Create a missing profile using the existing user's name.
    if (!$student) {
        $columnStmt = $pdo->query('SHOW COLUMNS FROM students');
        $columns = $columnStmt->fetchAll(PDO::FETCH_COLUMN);

        if (!in_array('user_id', $columns, true)) {
            throw new RuntimeException(
                'The students table must contain a user_id column.'
            );
        }

        $insertColumns = ['user_id'];
        $insertValues = [$userId];

        if (in_array('full_name', $columns, true)) {
            $insertColumns[] = 'full_name';
            $insertValues[] = $user['name'];
        } elseif (in_array('name', $columns, true)) {
            $insertColumns[] = 'name';
            $insertValues[] = $user['name'];
        }

        $placeholders = implode(
            ', ',
            array_fill(0, count($insertColumns), '?')
        );

        $quotedColumns = implode(
            ', ',
            array_map(
                static fn($column) => '`' . $column . '`',
                $insertColumns
            )
        );

        try {
            $sql = "INSERT INTO students ($quotedColumns)
                    VALUES ($placeholders)";
            $insertStmt = $pdo->prepare($sql);
            $insertStmt->execute($insertValues);
        } catch (PDOException $e) {
            // Another request may have created the row simultaneously.
            $check = $pdo->prepare(
                'SELECT * FROM students WHERE user_id = ? LIMIT 1'
            );
            $check->execute([$userId]);
            $student = $check->fetch(PDO::FETCH_ASSOC);

            if (!$student) {
                throw $e;
            }
        }

        // Fetch the newly created or existing profile.
        if (!$student) {
            $stmt = $pdo->prepare(
                'SELECT *
                 FROM students
                 WHERE user_id = ?
                 LIMIT 1'
            );
            $stmt->execute([$userId]);
            $student = $stmt->fetch(PDO::FETCH_ASSOC);
        }
    }

    if (!$student) {
        throw new RuntimeException(
            'The student profile could not be created. Check the students table columns.'
        );
    }

    // Supply account details consistently to student pages.
    $student['user_name'] = $user['name'];
    $student['email'] = $user['email'];
    $student['id'] = (int) $student['id'];

    return $student;
}

