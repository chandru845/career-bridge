
<?php
require_once __DIR__ . "/config/database.php";

if (is_logged_in()) {
    redirect(dashboard_path());
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>CareerBridge | Home</title>

<style>
:root {
    --purple: #6d28d9;
    --blue: #2563eb;
    --light: #f5f3ff;
    --dark: #17153b;
    --muted: #64748b;
}

* {
    box-sizing: border-box;
    margin: 0;
    padding: 0;
}

body {
    font-family: "Segoe UI", Arial, sans-serif;
    background: #ffffff;
    color: var(--dark);
}

a {
    text-decoration: none;
}

.navbar {
    width: 100%;
    padding: 20px 7%;
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 18px;
    flex-wrap: wrap;
    background: white;
    border-bottom: 1px solid #eeeaff;
}

.brand {
    display: flex;
    align-items: center;
    gap: 11px;
    color: var(--dark);
    font-size: 24px;
    font-weight: 900;
}

.logo {
    width: 45px;
    height: 45px;
    display: grid;
    place-items: center;
    color: white;
    border-radius: 14px;
    background: linear-gradient(135deg, var(--purple), var(--blue));
}

.brand span:last-child span {
    color: var(--purple);
}

.nav-links {
    display: flex;
    align-items: center;
    gap: 25px;
    flex-wrap: wrap;
}

.nav-links a {
    color: #475569;
    font-size: 14px;
    font-weight: 650;
}

.nav-links a:hover {
    color: var(--purple);
}

.btn {
    display: inline-flex;
    justify-content: center;
    align-items: center;
    gap: 9px;
    padding: 13px 22px;
    border-radius: 12px;
    background: linear-gradient(110deg, var(--purple), var(--blue));
    color: white !important;
    font-weight: 750;
    box-shadow: 0 8px 22px #6d28d926;
    transition: .2s;
}

.btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 12px 28px #6d28d940;
}

.hero {
    position: relative;
    overflow: hidden;
    padding: 90px 7% 85px;
    background:
        radial-gradient(circle at 90% 15%, #ddd6fe 0, transparent 30%),
        radial-gradient(circle at 10% 90%, #dbeafe 0, transparent 30%),
        linear-gradient(135deg, #faf8ff, #f0f5ff);
}

.hero-inner {
    max-width: 1200px;
    margin: auto;
    display: grid;
    grid-template-columns: 1.1fr .9fr;
    gap: 55px;
    align-items: center;
}

.eyebrow {
    display: inline-block;
    padding: 9px 14px;
    border: 1px solid #ddd6fe;
    border-radius: 30px;
    background: #ffffffb8;
    color: var(--purple);
    font-size: 12px;
    font-weight: 800;
    letter-spacing: 1px;
}

h1 {
    margin-top: 25px;
    font-size: clamp(42px, 5.3vw, 69px);
    line-height: 1.08;
    letter-spacing: -2.5px;
}

h1 span {
    display: block;
    background: linear-gradient(100deg, var(--purple), var(--blue));
    -webkit-background-clip: text;
    background-clip: text;
    color: transparent;
}

.hero-text {
    max-width: 560px;
    margin-top: 23px;
    color: var(--muted);
    font-size: 16px;
    line-height: 1.9;
}

.hero-actions {
    display: flex;
    align-items: center;
    gap: 18px;
    flex-wrap: wrap;
    margin-top: 32px;
}

.secondary-btn {
    padding: 13px 20px;
    border: 1px solid #d8d9ef;
    border-radius: 12px;
    background: white;
    color: var(--dark);
    font-weight: 750;
}

.secondary-btn:hover {
    border-color: var(--purple);
    color: var(--purple);
}

.trust {
    margin-top: 27px;
    color: #64748b;
    font-size: 12px;
}

/* Right illustration panel */

.visual {
    position: relative;
    min-height: 370px;
    display: flex;
    align-items: center;
    justify-content: center;
}

.orbit {
    position: absolute;
    width: 330px;
    height: 330px;
    border: 1px dashed #a5b4fc;
    border-radius: 50%;
}

.orbit-two {
    width: 250px;
    height: 250px;
    border-color: #c4b5fd;
}

.visual-card {
    position: relative;
    width: min(100%, 370px);
    padding: 28px;
    border: 1px solid #ffffff;
    border-radius: 25px;
    background: #ffffffed;
    box-shadow: 0 25px 70px #312e811c;
}

.card-top {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 12px;
}

.card-title {
    font-weight: 850;
    font-size: 17px;
}

.live {
    padding: 7px 10px;
    border-radius: 20px;
    background: #dcfce7;
    color: #15803d;
    font-size: 10px;
    font-weight: 800;
}

.card-subtitle {
    margin-top: 8px;
    color: var(--muted);
    font-size: 12px;
}

.job {
    display: flex;
    align-items: center;
    gap: 13px;
    margin-top: 19px;
    padding: 15px;
    border: 1px solid #edf0fa;
    border-radius: 15px;
    background: #fff;
}

.job-icon {
    width: 45px;
    height: 45px;
    display: grid;
    place-items: center;
    border-radius: 13px;
    background: #ede9fe;
    color: var(--purple);
    font-size: 21px;
    font-weight: 900;
}

.job:nth-of-type(3) .job-icon {
    background: #dbeafe;
    color: #1d4ed8;
}

.job:nth-of-type(4) .job-icon {
    background: #fce7f3;
    color: #be185d;
}

.job-info {
    flex: 1;
}

.job-info strong {
    display: block;
    font-size: 13px;
}

.job-info small {
    display: block;
    margin-top: 5px;
    color: var(--muted);
    font-size: 11px;
}

.job-arrow {
    color: var(--purple);
    font-size: 20px;
}

.mini-badge {
    position: absolute;
    right: -20px;
    bottom: -18px;
    padding: 15px 19px;
    border: 1px solid #fff;
    border-radius: 15px;
    background: white;
    box-shadow: 0 12px 35px #312e8118;
    color: var(--purple);
    font-size: 12px;
    font-weight: 850;
}

/* Features */

.features-section {
    padding: 75px 7%;
    text-align: center;
}

.section-label {
    color: var(--purple);
    font-size: 12px;
    font-weight: 850;
    letter-spacing: 1.5px;
}

.features-section h2 {
    margin-top: 13px;
    font-size: clamp(28px, 4vw, 40px);
    letter-spacing: -1px;
}

.section-description {
    max-width: 570px;
    margin: 15px auto 38px;
    color: var(--muted);
    font-size: 14px;
    line-height: 1.8;
}

.feature-grid {
    max-width: 1200px;
    margin: auto;
    display: grid;
    grid-template-columns: repeat(3, minmax(0, 1fr));
    gap: 22px;
    text-align: left;
}

.feature-card {
    padding: 27px;
    border: 1px solid #e9e8f6;
    border-radius: 20px;
    background: white;
    transition: .25s;
}

.feature-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 20px 45px #312e8110;
    border-color: #c4b5fd;
}

.feature-card .feature-icon {
    width: 52px;
    height: 52px;
    display: grid;
    place-items: center;
    border-radius: 16px;
    background: #ede9fe;
    color: var(--purple);
    font-size: 23px;
}

.feature-card:nth-child(2) .feature-icon {
    background: #dbeafe;
    color: #1d4ed8;
}

.feature-card:nth-child(3) .feature-icon {
    background: #dcfce7;
    color: #15803d;
}

.feature-card h3 {
    margin-top: 20px;
    font-size: 17px;
}

.feature-card p {
    margin-top: 11px;
    color: var(--muted);
    font-size: 13px;
    line-height: 1.8;
}

/* Bottom call to action */

.cta {
    margin: 0 7% 70px;
    padding: 43px;
    border-radius: 24px;
    background: linear-gradient(110deg, #312e81, #6d28d9, #2563eb);
    color: white;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 25px;
    flex-wrap: wrap;
}

.cta h2 {
    font-size: clamp(25px, 3vw, 35px);
}

.cta p {
    margin-top: 10px;
    color: #e0e7ff;
    font-size: 13px;
    line-height: 1.8;
}

.cta .btn {
    background: white;
    color: var(--purple) !important;
    box-shadow: none;
    white-space: nowrap;
}

footer {
    padding: 25px 7%;
    border-top: 1px solid #eeeaff;
    color: var(--muted);
    font-size: 12px;
    display: flex;
    justify-content: space-between;
    gap: 15px;
    flex-wrap: wrap;
}

@media(max-width: 900px) {
    .hero-inner {
        grid-template-columns: 1fr;
    }

    .visual {
        min-height: 380px;
    }

    .feature-grid {
        grid-template-columns: 1fr;
    }

    .hero {
        padding-top: 65px;
    }
}

@media(max-width: 540px) {
    .navbar {
        padding: 17px 5%;
    }

    .nav-links {
        width: 100%;
        justify-content: space-between;
        gap: 12px;
    }

    .nav-links a {
        font-size: 12px;
    }

    .nav-links .btn {
        padding: 10px 13px;
    }

    .hero {
        padding: 50px 6%;
    }

    h1 {
        letter-spacing: -1.5px;
    }

    .visual {
        min-height: 340px;
    }

    .orbit {
        width: 280px;
        height: 280px;
    }

    .orbit-two {
        width: 215px;
        height: 215px;
    }

    .visual-card {
        padding: 20px;
    }

    .mini-badge {
        right: -5px;
    }

    .features-section {
        padding: 55px 6%;
    }

    .cta {
        margin: 0 5% 45px;
        padding: 28px 23px;
    }
}
</style>
</head>

<body>

<nav class="navbar">
    <a href="home.php" class="brand">
        <span class="logo">CB</span>
        <span>Career<span>Bridge</span></span>
    </a>

    <div class="nav-links">
        <a href="#home">Home</a>
        <a href="#features">Features</a>
        <a href="register.php">Register</a>
        <a href="index.php" class="btn">Sign In →</a>
    </div>
</nav>

<section class="hero" id="home">
    <div class="hero-inner">

        <div>
            <span class="eyebrow">YOUR FUTURE STARTS HERE</span>

            <h1>
                Find your path.
                <span>Build your future.</span>
            </h1>

            <p class="hero-text">
                Your next opportunity is waiting. Discover internships,
                showcase your skills and projects, and connect with
                companies through one simple platform.
            </p>

            <div class="hero-actions">
                <a href="index.php" class="btn">Get Started →</a>
                <a href="#features" class="secondary-btn">Explore Features ↓</a>
            </div>

            <p class="trust">
                A simpler way to manage your internship journey.
            </p>
        </div>

        <div class="visual" aria-label="Illustration of internship opportunities">
            <div class="orbit"></div>
            <div class="orbit orbit-two"></div>

            <div class="visual-card">
                <div class="card-top">
                    <div class="card-title">Your next opportunity</div>
                    <span class="live">CAREER READY</span>
                </div>

                <p class="card-subtitle">Build your future, step by step.</p>

                <div class="job">
                    <div class="job-icon">⌘</div>
                    <div class="job-info">
                        <strong>Web Development</strong>
                        <small>Build practical skills</small>
                    </div>
                    <span class="job-arrow">↗</span>
                </div>

                <div class="job">
                    <div class="job-icon">✧</div>
                    <div class="job-info">
                        <strong>UI / UX Design</strong>
                        <small>Turn ideas into experiences</small>
                    </div>
                    <span class="job-arrow">↗</span>
                </div>

                <div class="job">
                    <div class="job-icon">⌁</div>
                    <div class="job-info">
                        <strong>Data & Technology</strong>
                        <small>Explore new possibilities</small>
                    </div>
                    <span class="job-arrow">↗</span>
                </div>

                <div class="mini-badge">Your journey begins today ✦</div>
            </div>
        </div>

    </div>
</section>

<section class="features-section" id="features">
    <span class="section-label">WHY CAREERBRIDGE?</span>
    <h2>Everything you need to move forward</h2>
    <p class="section-description">
        Keep your career preparation organised with tools designed
        to help you find opportunities and present your best work.
    </p>

    <div class="feature-grid">

        <article class="feature-card">
            <div class="feature-icon">⌕</div>
            <h3>Discover Internships</h3>
            <p>
                Explore internship listings and find opportunities
                that suit your interests, education and skills.
            </p>
        </article>

        <article class="feature-card">
            <div class="feature-icon">↗</div>
            <h3>Showcase Your Work</h3>
            <p>
                Maintain your profile, add project details and
                provide your resume to present your experience.
            </p>
        </article>

        <article class="feature-card">
            <div class="feature-icon">✓</div>
            <h3>Track Applications</h3>
            <p>
                Follow application statuses and keep your internship
                search organised in one place.
            </p>
        </article>

    </div>
</section>

<section class="cta">
    <div>
        <h2>Ready for your next step?</h2>
        <p>Create an account or sign in to continue to CareerBridge.</p>
    </div>
    <a href="index.php" class="btn">Enter CareerBridge →</a>
</section>

<footer>
    <span>© <?= date('Y') ?> CareerBridge. All rights reserved.</span>
    <span>Learn. Build. Grow.</span>
</footer>

</body>
</html>
