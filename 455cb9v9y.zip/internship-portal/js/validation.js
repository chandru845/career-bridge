document.addEventListener("DOMContentLoaded", function () {
    const roleInputs = document.querySelectorAll('input[name="role"]');
    const studentFields = document.getElementById("studentFields");
    const companyFields = document.getElementById("companyFields");

    function toggleFields() {
        const role = document.querySelector('input[name="role"]:checked')?.value;
        if (studentFields && companyFields) {
            studentFields.classList.toggle("hidden", role !== "student");
            companyFields.classList.toggle("hidden", role !== "company");
        }
    }

    roleInputs.forEach(input => input.addEventListener("change", toggleFields));
    toggleFields();

    const form = document.getElementById("registerForm");
    if (form) {
        form.addEventListener("submit", function (e) {
            const password = form.querySelector('[name="password"]').value;
            const confirm = form.querySelector('[name="confirm_password"]').value;
            if (password.length < 6) {
                e.preventDefault();
                alert("Password must contain at least 6 characters.");
                return;
            }
            if (password !== confirm) {
                e.preventDefault();
                alert("Passwords do not match.");
            }
        });
    }
});