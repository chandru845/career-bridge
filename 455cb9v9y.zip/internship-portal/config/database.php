<?php

$host = "db01.dbhost.dev";
$port = 5051;
$dbname = "db_4558x34yp";
$username = "user_4558x34yp";
$password = "p4558x34yp";

function getPDO()
{
    global $host, $port, $dbname, $username, $password;

    static $pdo = null;

    if ($pdo instanceof PDO) {
        return $pdo;
    }

    try {
        $dsn = "mysql:host=$host;port=$port;dbname=$dbname;charset=utf8mb4";

        $pdo = new PDO(
            $dsn,
            $username,
            $password,
            [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
                PDO::ATTR_TIMEOUT => 10
            ]
        );

        return $pdo;

    } catch (PDOException $e) {
        die(
            "<h2>Database Connection Failed</h2>" .
            "<p>" . htmlspecialchars($e->getMessage()) . "</p>"
        );
    }
}

$pdo = getPDO();

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function is_logged_in()
{
    return isset($_SESSION["user_id"]);
}

function dashboard_path()
{
    if (
        isset($_SESSION["role"]) &&
        $_SESSION["role"] === "company"
    ) {
        return "company/dashboard.php";
    }

    return "student/dashboard.php";
}

function redirect($url)
{
    header("Location: " . $url);
    exit;
}
?>