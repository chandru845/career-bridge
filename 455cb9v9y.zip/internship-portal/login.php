<?php
/* Start the session before loading any application file or producing output.
   This helps ensure the same session is available when the login form is posted. */
if (session_status() !== PHP_SESSION_ACTIVE) {
    $https = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== '' && strtolower((string) $_SERVER['HTTPS']) !== 'off';
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'secure' => $https,
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_start();
}

// Prevent browsers/proxies from reusing a stale login form after session changes.
if (!headers_sent()) {
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    header('Pragma: no-cache');
}

require_once __DIR__ . '/config/database.php';

if (function_exists('is_logged_in') && is_logged_in()) {
    if (function_exists('dashboard_path')) {
        redirect(dashboard_path());
    }
    header('Location: index.php');
    exit;
}

$error = '';
$email = '';

function loginGetColumns(PDO $pdo, string $table): array
{
    if ($table !== 'users') {
        throw new RuntimeException('Invalid table.');
    }
    $stmt = $pdo->query("DESCRIBE `users`");
    return $stmt->fetchAll(PDO::FETCH_COLUMN);
}

function loginFindColumn(array $columns, array $possibleNames): ?string
{
    foreach ($possibleNames as $name) {
        foreach ($columns as $column) {
            if (strcasecmp($column, $name) === 0) {
                return $column;
            }
        }
    }
    return null;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($email === '' || $password === '') {
        $error = 'Please enter your email and password.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Please enter a valid email address.';
    } else {
        try {
            if (!isset($pdo) || !($pdo instanceof PDO)) {
                throw new RuntimeException('The database connection is unavailable.');
            }

            $columns = loginGetColumns($pdo, 'users');
            $emailColumn = loginFindColumn($columns, ['email', 'email_address', 'user_email']);
            $passwordColumn = loginFindColumn($columns, ['password', 'password_hash', 'user_password']);
            $idColumn = loginFindColumn($columns, ['id', 'user_id', 'users_id']);
            $nameColumn = loginFindColumn($columns, ['name', 'full_name', 'username', 'user_name']);
            $roleColumn = loginFindColumn($columns, ['role', 'user_type', 'account_type']);

            if (!$emailColumn || !$passwordColumn || !$idColumn) {
                throw new RuntimeException('Required columns were not found in the users table.');
            }

            $sql = 'SELECT * FROM `users` WHERE `' . $emailColumn . '` = :email LIMIT 1';
            $stmt = $pdo->prepare($sql);
            $stmt->execute(['email' => $email]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$user || !password_verify($password, $user[$passwordColumn])) {
                $error = 'Incorrect email or password.';
            } else {
                session_regenerate_id(true);
                $userId = $user[$idColumn];
                $userName = $nameColumn ? ($user[$nameColumn] ?? 'User') : 'User';
                $userRole = $roleColumn ? strtolower(trim($user[$roleColumn] ?? 'student')) : 'student';

                $_SESSION['user_id'] = $userId;
                $_SESSION['id'] = $userId;
                $_SESSION['user_name'] = $userName;
                $_SESSION['name'] = $userName;
                $_SESSION['user_email'] = $user[$emailColumn];
                $_SESSION['email'] = $user[$emailColumn];
                $_SESSION['user_role'] = $userRole;
                $_SESSION['role'] = $userRole;

                if ($userRole === 'company' || $userRole === 'admin') {
                    header('Location: company/dashboard.php');
                } else {
                    header('Location: student/dashboard.php');
                }
                exit;
            }
        } catch (Throwable $exception) {
            error_log('Login error: ' . $exception->getMessage());
            $error = 'Unable to sign in. Please check your database configuration.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="theme-color" content="#080807">
    <title>Sign In | CareerBridge</title>
    <style>
        :root {
            --black: #080807;
            --panel: rgba(20, 17, 14, .94);
            --orange: #ff6a00;
            --orange-light: #ff913d;
            --orange-pale: #ffd09b;
            --gold: #ffc36b;
            --text: #fff8f0;
            --muted: #aaa097;
            --border: rgba(255, 145, 61, .24);
            --green: #80efb3;
        }
        * { margin: 0; padding: 0; box-sizing: border-box; }
        html { scroll-behavior: smooth; }
        body {
            min-height: 100vh; min-height: 100svh; position: relative; isolation: isolate;
            display: flex; align-items: center; justify-content: center;
            padding: 34px 18px; overflow-x: hidden;
            color: var(--text); background: var(--black);
            font-family: "Segoe UI", Arial, sans-serif;
        }
        #particles { position: fixed; inset: 0; width: 100%; height: 100%; z-index: -3; pointer-events: none; }
        .background-glow {
            position: fixed; inset: 0; z-index: -2; pointer-events: none;
            background: radial-gradient(ellipse at 8% 14%, rgba(255,106,0,.16), transparent 36%),
                        radial-gradient(ellipse at 92% 86%, rgba(255,90,0,.11), transparent 35%),
                        linear-gradient(145deg, #080807 4%, #17110c 52%, #080807 100%);
        }
        .grid-overlay {
            position: fixed; inset: 0; z-index: -1; pointer-events: none; opacity: .13;
            background-image: linear-gradient(rgba(255,145,61,.12) 1px, transparent 1px),
                              linear-gradient(90deg, rgba(255,145,61,.12) 1px, transparent 1px);
            background-size: 55px 55px;
            mask-image: linear-gradient(to bottom, transparent, black 25%, black 75%, transparent);
            animation: gridMove 28s linear infinite;
        }
        .light-beam {
            position: fixed; top: -50%; left: -50%; width: 200%; height: 200%; z-index: -1; pointer-events: none;
            background: linear-gradient(115deg, transparent 43%, rgba(255,106,0,.035) 49%, rgba(255,160,70,.075) 50%, rgba(255,106,0,.025) 51%, transparent 57%);
            animation: beamMove 14s ease-in-out infinite alternate;
        }
        .orb { position: fixed; width: 320px; height: 320px; border-radius: 50%; filter: blur(78px); opacity: .20; pointer-events: none; z-index: -1; background: var(--orange); animation: orbFloat 11s ease-in-out infinite; }
        .orb-one { top: -140px; left: -100px; }
        .orb-two { right: -160px; bottom: -150px; width: 400px; height: 400px; opacity: .13; animation-delay: -5s; }
        @keyframes gridMove { from { background-position: 0 0; } to { background-position: 55px 55px; } }
        @keyframes beamMove { from { transform: translateX(-5%) rotate(-4deg); } to { transform: translateX(5%) rotate(4deg); } }
        @keyframes orbFloat { 0%,100% { transform: translate(0,0) scale(1); } 50% { transform: translate(35px,25px) scale(1.1); } }
        .page { width: 100%; max-width: 465px; position: relative; z-index: 2; animation: pageReveal .85s cubic-bezier(.2,.8,.2,1) both; }
        @keyframes pageReveal { from { opacity: 0; transform: translateY(32px) scale(.975); filter: blur(7px); } to { opacity: 1; transform: translateY(0) scale(1); filter: blur(0); } }
        .brand { text-align: center; margin-bottom: 27px; }
        .brand-icon {
            width: 66px; height: 66px; display: flex; align-items: center; justify-content: center;
            margin: 0 auto 15px; border-radius: 20px; position: relative; isolation: isolate;
            color: #190b02; font-size: 33px; font-weight: 950; font-style: italic;
            background: linear-gradient(135deg, #ffe0a9 0%, #ff9b42 35%, #ff6a00 72%, #d94a00 100%);
            box-shadow: 0 0 22px rgba(255,106,0,.32), 0 0 58px rgba(255,106,0,.13), inset 0 1px 0 rgba(255,255,255,.65);
            animation: iconPulse 3s ease-in-out infinite;
        }
        .brand-icon::after { content: ""; position: absolute; inset: -5px; border: 1px solid rgba(255,169,91,.5); border-radius: 24px; z-index: -1; animation: ringPulse 3s ease-out infinite; }
        @keyframes iconPulse { 0%,100% { box-shadow: 0 0 18px rgba(255,106,0,.25); } 50% { box-shadow: 0 0 30px rgba(255,106,0,.45), 0 0 65px rgba(255,106,0,.16); } }
        @keyframes ringPulse { 0% { transform: scale(.95); opacity: .7; } 100% { transform: scale(1.2); opacity: 0; } }
        .brand h1 { font-size: clamp(28px,5vw,34px); font-weight: 850; letter-spacing: -1.2px; }
        .brand h1 span { color: var(--orange-light); text-shadow: 0 0 25px rgba(255,106,0,.2); }
        .brand p { margin-top: 9px; font-size: 13px; letter-spacing: .45px; color: var(--muted); }
        .card {
            position: relative; overflow: hidden; padding: 36px; border-radius: 25px;
            border: 1px solid var(--border); background: var(--panel);
            backdrop-filter: blur(24px); -webkit-backdrop-filter: blur(24px);
            box-shadow: 0 30px 100px rgba(0,0,0,.58), 0 0 45px rgba(255,106,0,.05), inset 0 1px 0 rgba(255,255,255,.055);
            transition: border-color .35s ease, box-shadow .35s ease;
        }
        .card:hover { border-color: rgba(255,160,80,.4); box-shadow: 0 30px 100px rgba(0,0,0,.58), 0 0 55px rgba(255,106,0,.085), inset 0 1px 0 rgba(255,255,255,.06); }
        .card::before { content: ""; position: absolute; top: 0; left: 12%; right: 12%; height: 1px; background: linear-gradient(90deg,transparent,#ffd09b,var(--orange),transparent); opacity: .95; }
        .card::after { content: ""; position: absolute; top: -100%; left: -60%; width: 35%; height: 300%; pointer-events: none; background: linear-gradient(90deg,transparent,rgba(255,255,255,.025),transparent); transform: rotate(25deg); animation: cardShine 9s ease-in-out infinite; }
        @keyframes cardShine { 0%,75%,100% { left: -60%; } 35% { left: 130%; } }
        .card h2 { font-size: 29px; font-weight: 800; letter-spacing: -.7px; margin-bottom: 9px; }
        .subtitle { color: var(--muted); font-size: 13.5px; line-height: 1.75; margin-bottom: 28px; }
        .subtitle strong { color: var(--orange-pale); font-weight: 650; }
        .alert { padding: 13px 14px; margin-bottom: 20px; border-radius: 12px; background: rgba(255,65,65,.09); border: 1px solid rgba(255,90,90,.3); color: #ffb4ad; font-size: 13px; line-height: 1.55; animation: alertIn .35s ease both; }
        .success-alert { background: rgba(65,210,135,.08); border-color: rgba(65,210,135,.25); color: var(--green); }
        @keyframes alertIn { from { opacity: 0; transform: translateY(-7px); } to { opacity: 1; transform: translateY(0); } }
        .field { margin-bottom: 21px; position: relative; }
        .field label { display: block; margin-bottom: 9px; font-size: 13px; font-weight: 700; color: #eee4dc; }
        .input-wrap { position: relative; }
        .input-wrap input {
            display: block; width: 100%; height: 53px; padding: 0 15px; border-radius: 12px;
            border: 1px solid rgba(255,255,255,.11); outline: none; background: rgba(255,255,255,.035);
            color: var(--text); font-family: inherit; font-size: 14px;
            transition: border-color .25s, box-shadow .25s, background .25s;
        }
        .input-wrap input::placeholder { color: #746b64; }
        .input-wrap input:hover { border-color: rgba(255,145,61,.35); }
        .input-wrap input:focus { border-color: var(--orange-light); background: rgba(255,106,0,.05); box-shadow: 0 0 0 3px rgba(255,106,0,.11), 0 0 24px rgba(255,106,0,.06); }
        .password-input { padding-right: 76px !important; }
        .toggle-password { position: absolute; top: 50%; right: 11px; transform: translateY(-50%); padding: 8px 5px; border: none; background: transparent; color: var(--orange-light); cursor: pointer; font-family: inherit; font-size: 12px; font-weight: 800; transition: color .2s; }
        .toggle-password:hover { color: #ffe0bd; }

        /* Custom premium Remember me checkbox */
        .options { display: flex; justify-content: space-between; align-items: center; gap: 12px; margin: 2px 0 25px; font-size: 12px; }
        .remember { display: inline-flex; align-items: center; gap: 9px; color: #c6bdb4; cursor: pointer; user-select: none; transition: color .25s ease; }
        .remember:hover { color: #fff0e2; }
        .remember input {
            appearance: none; -webkit-appearance: none; flex: 0 0 17px; width: 17px; height: 17px;
            margin: 0; border-radius: 5px; position: relative; cursor: pointer;
            border: 1px solid rgba(255,174,103,.55);
            background: linear-gradient(145deg, #19130f, #0d0b09);
            box-shadow: inset 0 1px 3px rgba(0,0,0,.6), 0 0 0 rgba(255,106,0,0);
            transition: background .25s ease, border-color .25s ease, box-shadow .25s ease, transform .2s ease;
        }
        .remember input::after {
            content: ""; position: absolute; left: 4px; top: 1px; width: 5px; height: 9px;
            border: solid #211005; border-width: 0 2px 2px 0; opacity: 0;
            transform: rotate(45deg) scale(.5); transition: opacity .18s ease, transform .18s ease;
        }
        .remember input:checked {
            border-color: #ffb56c;
            background: linear-gradient(135deg, #ffd18e 0%, #ff8c2e 38%, #ff6500 100%);
            box-shadow: 0 0 9px rgba(255,106,0,.38), 0 0 19px rgba(255,106,0,.14), inset 0 1px 0 rgba(255,255,255,.5);
        }
        .remember input:checked::after { opacity: 1; transform: rotate(45deg) scale(1); }
        .remember input:hover { transform: scale(1.08); border-color: #ffc17f; }
        .remember input:focus-visible { outline: 2px solid #ffb36d; outline-offset: 4px; }
        .remember:has(input:checked) { color: #ffe0c0; }
        .forgot { color: var(--orange-light); text-decoration: none; transition: color .2s; }
        .forgot:hover { color: #ffd0a8; text-decoration: underline; }
        .submit-btn {
            position: relative; isolation: isolate; display: flex; align-items: center; justify-content: center; gap: 9px;
            overflow: hidden; width: 100%; min-height: 54px; padding: 13px 18px;
            border: 1px solid rgba(255,210,150,.55); border-radius: 13px; color: #1b0c02;
            background: linear-gradient(110deg,#d94b00 0%,#ff790d 22%,#ffb15c 48%,#ff8120 70%,#e65100 100%);
            background-size: 250% 100%; font-family: inherit; font-size: 15px; font-weight: 850; letter-spacing: .25px; cursor: pointer;
            box-shadow: 0 8px 25px rgba(255,106,0,.22), inset 0 1px 0 rgba(255,255,255,.35);
            transition: transform .25s, box-shadow .25s, filter .25s; animation: buttonGradient 6s linear infinite;
        }
        .submit-btn::before { content: ""; position: absolute; inset: 0; z-index: -1; background: linear-gradient(105deg,transparent 25%,rgba(255,255,255,.42) 50%,transparent 75%); transform: translateX(-130%); transition: transform .65s ease; }
        .submit-btn:hover { transform: translateY(-3px); box-shadow: 0 13px 35px rgba(255,106,0,.32), 0 0 25px rgba(255,106,0,.12); filter: saturate(1.12) brightness(1.04); }
        .submit-btn:hover::before { transform: translateX(130%); }
        .submit-btn:active { transform: translateY(-1px) scale(.99); }
        .submit-btn .arrow { display: inline-block; transition: transform .25s; }
        .submit-btn:hover .arrow { transform: translateX(5px); }
        @keyframes buttonGradient { 0% { background-position: 100% 50%; } 100% { background-position: -150% 50%; } }
        .divider { display: flex; align-items: center; gap: 13px; margin: 27px 0 22px; color: #887b70; font-size: 10px; font-weight: 750; letter-spacing: 1.5px; }
        .divider::before, .divider::after { content: ""; flex: 1; height: 1px; background: linear-gradient(90deg,transparent,rgba(255,140,50,.3)); }
        .divider::after { background: linear-gradient(90deg,rgba(255,140,50,.3),transparent); }
        .register-text { text-align: center; color: var(--muted); font-size: 13px; line-height: 1.9; }
        .register-text a { display: inline-block; margin-left: 3px; color: var(--orange-light); font-weight: 800; text-decoration: none; transition: color .2s, transform .2s; }
        .register-text a:hover { color: #ffd0a8; transform: translateX(2px); }
        .footer { margin-top: 24px; text-align: center; color: #756b62; font-size: 11px; letter-spacing: .3px; }
        .footer span { color: var(--orange-light); }
        a:focus-visible, button:focus-visible { outline: 2px solid var(--orange-light); outline-offset: 4px; }
        @media (max-width: 480px) {
            body { padding: 25px 15px; }
            .brand { margin-bottom: 23px; }
            .brand-icon { width: 58px; height: 58px; border-radius: 17px; font-size: 29px; }
            .card { padding: 27px 21px; border-radius: 21px; }
            .card h2 { font-size: 26px; }
            .subtitle { margin-bottom: 23px; }
            .options { font-size: 11px; }
        }
        @media (max-width: 350px) {
            .card { padding: 24px 16px; }
            .options { align-items: flex-start; flex-direction: column; }
        }
        @media (prefers-reduced-motion: reduce) {
            *, *::before, *::after { animation-duration: .01ms !important; animation-iteration-count: 1 !important; scroll-behavior: auto !important; transition-duration: .01ms !important; }
        }
    </style>
</head>
<body>
    <canvas id="particles" aria-hidden="true"></canvas>
    <div class="background-glow" aria-hidden="true"></div>
    <div class="grid-overlay" aria-hidden="true"></div>
    <div class="light-beam" aria-hidden="true"></div>
    <div class="orb orb-one" aria-hidden="true"></div>
    <div class="orb orb-two" aria-hidden="true"></div>

    <main class="page">
        <header class="brand">
            <div class="brand-icon" aria-hidden="true">C</div>
            <h1>Career<span>Bridge</span></h1>
            <p>Your next opportunity starts here.</p>
        </header>

        <section class="card">
            <h2>Welcome back!</h2>
            <p class="subtitle">Sign in to discover new opportunities and continue your <strong>career journey.</strong></p>

            <?php if ($error !== ''): ?>
                <div class="alert" role="alert"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></div>
            <?php endif; ?>

            <?php if (isset($_GET['registered'])): ?>
                <div class="alert success-alert" role="status">Registration successful! Please sign in with your account.</div>
            <?php endif; ?>

            <form method="POST" action="<?= htmlspecialchars($_SERVER['PHP_SELF'] ?? 'login.php', ENT_QUOTES, 'UTF-8') ?>" autocomplete="on">
                <div class="field">
                    <label for="email">Email Address</label>
                    <div class="input-wrap">
                        <input type="email" id="email" name="email" placeholder="you@example.com"
                               value="<?= htmlspecialchars($email, ENT_QUOTES, 'UTF-8') ?>"
                               autocomplete="username" maxlength="150" required>
                    </div>
                </div>

                <div class="field">
                    <label for="password">Password</label>
                    <div class="input-wrap">
                        <input type="password" id="password" name="password" class="password-input"
                               placeholder="Enter your password" autocomplete="current-password" required>
                        <button type="button" class="toggle-password" id="togglePassword"
                                aria-controls="password" aria-pressed="false">Show</button>
                    </div>
                </div>

                <div class="options">
                    <label class="remember">
                        <input type="checkbox" name="remember_visual" value="1">
                        <span>Remember me</span>
                    </label>
                    <a class="forgot" href="forgot_password.php">Forgot password?</a>
                </div>

                <button type="submit" class="submit-btn">
                    <span>Sign In</span><span class="arrow" aria-hidden="true">→</span>
                </button>
            </form>

            <div class="divider">NEW TO CAREERBRIDGE?</div>
            <p class="register-text">Don't have an account? <a href="register.php">Create an account ↗</a></p>
        </section>

        <footer class="footer">© <?= date('Y') ?> <span>CareerBridge</span>. All rights reserved.</footer>
    </main>

    <script>
        // Show and hide password.
        const passwordInput = document.getElementById('password');
        const toggleButton = document.getElementById('togglePassword');

        toggleButton.addEventListener('click', function () {
            const isHidden = passwordInput.type === 'password';
            passwordInput.type = isHidden ? 'text' : 'password';
            toggleButton.textContent = isHidden ? 'Hide' : 'Show';
            toggleButton.setAttribute('aria-pressed', String(isHidden));
        });

        // Animated orange particle background.
        (() => {
            const canvas = document.getElementById('particles');
            const ctx = canvas.getContext('2d');
            if (!ctx) return;

            const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
            let particles = [], animationId = null, width = 0, height = 0, dpr = 1;
            const pointer = { x: -1000, y: -1000 };

            function createParticles() {
                const count = Math.min(85, Math.max(28, Math.floor(width / 16)));
                particles = [];
                for (let i = 0; i < count; i++) {
                    particles.push({
                        x: Math.random() * width, y: Math.random() * height,
                        radius: Math.random() * 1.8 + .5,
                        vx: (Math.random() - .5) * .35, vy: (Math.random() - .5) * .35,
                        alpha: Math.random() * .55 + .15, phase: Math.random() * Math.PI * 2
                    });
                }
            }

            function resizeCanvas() {
                width = window.innerWidth;
                height = window.innerHeight;
                dpr = Math.min(window.devicePixelRatio || 1, 2);
                canvas.width = Math.round(width * dpr);
                canvas.height = Math.round(height * dpr);
                canvas.style.width = width + 'px';
                canvas.style.height = height + 'px';
                ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
                createParticles();
                drawFrame();
                if (!reduceMotion.matches) startAnimation();
            }

            function drawFrame() {
                ctx.clearRect(0, 0, width, height);
                for (let i = 0; i < particles.length; i++) {
                    const p = particles[i];
                    if (!reduceMotion.matches) {
                        p.x += p.vx; p.y += p.vy; p.phase += .018;
                        const dx = p.x - pointer.x, dy = p.y - pointer.y;
                        const distance = Math.sqrt(dx * dx + dy * dy);
                        if (distance < 115 && distance > 0) {
                            const force = (115 - distance) / 115;
                            p.x += (dx / distance) * force * .45;
                            p.y += (dy / distance) * force * .45;
                        }
                        if (p.x < -5) p.x = width + 5;
                        if (p.x > width + 5) p.x = -5;
                        if (p.y < -5) p.y = height + 5;
                        if (p.y > height + 5) p.y = -5;
                    }
                    const glow = .6 + Math.sin(p.phase) * .4;
                    ctx.beginPath();
                    ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
                    ctx.fillStyle = `rgba(255, ${105 + Math.floor(glow * 45)}, 30, ${p.alpha})`;
                    ctx.shadowBlur = 12;
                    ctx.shadowColor = 'rgba(255, 106, 0, .65)';
                    ctx.fill();
                    ctx.shadowBlur = 0;

                    for (let j = i + 1; j < particles.length; j++) {
                        const other = particles[j];
                        const dx = p.x - other.x, dy = p.y - other.y;
                        const distance = Math.sqrt(dx * dx + dy * dy);
                        if (distance < 95) {
                            ctx.beginPath();
                            ctx.moveTo(p.x, p.y);
                            ctx.lineTo(other.x, other.y);
                            ctx.strokeStyle = `rgba(255, 125, 35, ${(1 - distance / 95) * .12})`;
                            ctx.lineWidth = .7;
                            ctx.stroke();
                        }
                    }
                }
            }

            function animate() {
                if (reduceMotion.matches) { animationId = null; drawFrame(); return; }
                drawFrame();
                animationId = requestAnimationFrame(animate);
            }
            function startAnimation() {
                if (reduceMotion.matches || animationId !== null) return;
                animationId = requestAnimationFrame(animate);
            }
            function stopAnimation() {
                if (animationId !== null) { cancelAnimationFrame(animationId); animationId = null; }
            }

            window.addEventListener('pointermove', event => {
                pointer.x = event.clientX; pointer.y = event.clientY;
            }, { passive: true });
            window.addEventListener('pointerleave', () => {
                pointer.x = -1000; pointer.y = -1000;
            });
            window.addEventListener('resize', resizeCanvas, { passive: true });
            if (typeof reduceMotion.addEventListener === 'function') {
                reduceMotion.addEventListener('change', () => {
                    stopAnimation(); drawFrame();
                    if (!reduceMotion.matches) startAnimation();
                });
            }
            resizeCanvas();
        })();
    </script>
</body>
</html>
