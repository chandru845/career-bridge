
<?php
/*
|--------------------------------------------------------------------------
| CareerBridge - Registration
|--------------------------------------------------------------------------
| Expected tables:
| users(id, name, email, password, role, created_at)
| students(id, user_id, full_name)
| companies(id, user_id, company_name)
|
| Keep this file in the same directory as config/database.php.
|--------------------------------------------------------------------------
*/

/* Start the session BEFORE including other PHP files. */
if (session_status() !== PHP_SESSION_ACTIVE) {
    $https = (
        (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https')
    );

    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'secure' => $https,
        'httponly' => true,
        'samesite' => 'Lax'
    ]);

    session_start();
}

require_once __DIR__ . '/config/database.php';

/* Use the PDO connection supplied by your database.php. */
try {
    $pdo = getPDO();
} catch (Throwable $e) {
    error_log('Registration database connection: ' . $e->getMessage());
    $pdo = null;
}

function h($value): string
{
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

/* Create a CSRF token only when one does not already exist. */
if (empty($_SESSION['register_csrf'])) {
    $_SESSION['register_csrf'] = bin2hex(random_bytes(32));
}

$error = '';
$success = '';
$name = '';
$email = '';
$companyName = '';
$role = 'student';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $email = strtolower(trim($_POST['email'] ?? ''));
    $companyName = trim($_POST['company_name'] ?? '');
    $role = $_POST['role'] ?? 'student';
    $password = $_POST['password'] ?? '';
    $confirmPassword = $_POST['confirm_password'] ?? '';
    $postedToken = $_POST['csrf_token'] ?? '';
    $acceptedTerms = isset($_POST['terms']);

    /*
     * Do not rotate the token on every request.
     * The token remains valid when validation fails and the form is
     * displayed again. A new token is generated after successful signup.
     */
    if (
        !is_string($postedToken) ||
        !hash_equals($_SESSION['register_csrf'], $postedToken)
    ) {
        $error = 'Your form session could not be verified. Please reload the registration page and try again.';
    } elseif (!$pdo instanceof PDO) {
        $error = 'Database connection failed. Please check config/database.php.';
    } elseif (strlen($name) < 2 || strlen($name) > 100) {
        $error = 'Name must contain between 2 and 100 characters.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($email) > 150) {
        $error = 'Please enter a valid email address.';
    } elseif (!in_array($role, ['student', 'company'], true)) {
        $error = 'Please choose Student or Company.';
    } elseif ($role === 'company' && (strlen($companyName) < 2 || strlen($companyName) > 150)) {
        $error = 'Please enter a company name between 2 and 150 characters.';
    } elseif (
        strlen($password) < 8 ||
        !preg_match('/[A-Za-z]/', $password) ||
        !preg_match('/[0-9]/', $password)
    ) {
        $error = 'Password must be at least 8 characters and contain a letter and a number.';
    } elseif ($password !== $confirmPassword) {
        $error = 'The passwords do not match.';
    } elseif (!$acceptedTerms) {
        $error = 'Please accept the Terms and Privacy Policy.';
    } else {
        try {
            $pdo->beginTransaction();

            /* Check whether this email is already registered. */
            $check = $pdo->prepare(
                'SELECT id FROM users WHERE email = ? LIMIT 1'
            );
            $check->execute([$email]);

            if ($check->fetch(PDO::FETCH_ASSOC)) {
                $pdo->rollBack();
                $error = 'This email is already registered. Please sign in instead.';
            } else {
                $passwordHash = password_hash($password, PASSWORD_DEFAULT);

                $insertUser = $pdo->prepare(
                    'INSERT INTO users (name, email, password, role)
                     VALUES (?, ?, ?, ?)'
                );
                $insertUser->execute([
                    $name,
                    $email,
                    $passwordHash,
                    $role
                ]);

                $userId = (int)$pdo->lastInsertId();

                /*
                 * Create the matching role profile.
                 * These columns must match your database schema.
                 */
                if ($role === 'student') {
                    $profile = $pdo->prepare(
                        'INSERT INTO students (user_id, full_name)
                         VALUES (?, ?)'
                    );
                    $profile->execute([$userId, $name]);
                } else {
                    $profile = $pdo->prepare(
                        'INSERT INTO companies (user_id, company_name)
                         VALUES (?, ?)'
                    );
                    $profile->execute([$userId, $companyName]);
                }

                $pdo->commit();

                /*
                 * Regenerate the session ID only after successful
                 * registration. Do not destroy the active session.
                 */
                session_regenerate_id(true);
                unset($_SESSION['register_csrf']);

                header('Location: login.php?registered=1');
                exit;
            }
        } catch (Throwable $e) {
            if ($pdo instanceof PDO && $pdo->inTransaction()) {
                $pdo->rollBack();
            }

            error_log('CareerBridge registration error: ' . $e->getMessage());

            $error = 'Registration failed. Please check that your users, students and companies tables have the required columns.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="theme-color" content="#090807">
<title>Create Account | CareerBridge</title>

<style>
:root {
    --bg: #090807;
    --panel: rgba(22, 17, 13, .92);
    --orange: #ff6a00;
    --amber: #ffad55;
    --gold: #ffdcac;
    --text: #fff7ef;
    --muted: #aaa097;
    --line: rgba(255, 155, 75, .25);
    --green: #7df0b0;
}

* { box-sizing: border-box; margin: 0; padding: 0; }

body {
    min-height: 100vh;
    display: grid;
    place-items: center;
    padding: 28px 15px;
    overflow-x: hidden;
    isolation: isolate;
    color: var(--text);
    font-family: Inter, "Segoe UI", Arial, sans-serif;
    background:
        radial-gradient(ellipse at 12% 12%, #321606 0, transparent 38%),
        radial-gradient(ellipse at 90% 88%, #351505 0, transparent 34%),
        linear-gradient(145deg, #070706, #17100b 55%, #080807);
}

#particles {
    position: fixed;
    inset: 0;
    width: 100%;
    height: 100%;
    z-index: -3;
    pointer-events: none;
}

.grid {
    position: fixed;
    inset: 0;
    z-index: -2;
    opacity: .12;
    pointer-events: none;
    background-image:
        linear-gradient(#ff9b4218 1px, transparent 1px),
        linear-gradient(90deg, #ff9b4218 1px, transparent 1px);
    background-size: 48px 48px;
    animation: gridMove 25s linear infinite;
}

.orb {
    position: fixed;
    width: 340px;
    height: 340px;
    border-radius: 50%;
    background: var(--orange);
    filter: blur(90px);
    opacity: .15;
    z-index: -2;
    pointer-events: none;
    animation: float 11s ease-in-out infinite;
}

.orb.one { top: -170px; right: -100px; }
.orb.two {
    bottom: -180px;
    left: -120px;
    animation-delay: -5s;
}

.ring {
    position: fixed;
    width: 400px;
    height: 400px;
    border: 1px solid #ff9b4220;
    border-radius: 50%;
    pointer-events: none;
    z-index: -1;
    animation: rotateRing 40s linear infinite;
}

.ring::before, .ring::after {
    content: "";
    position: absolute;
    inset: 12%;
    border: 1px solid #ffd09b17;
    border-radius: 50%;
}

.ring::after { inset: 25%; border-style: dashed; }
.ring.left { left: -300px; top: 25%; }
.ring.right { right: -300px; bottom: 5%; animation-direction: reverse; }

@keyframes gridMove {
    to { background-position: 48px 48px; }
}
@keyframes float {
    50% { transform: translate(25px, 30px) scale(1.08); }
}
@keyframes rotateRing { to { transform: rotate(360deg); } }
@keyframes appear {
    from { opacity: 0; transform: translateY(24px) scale(.98); filter: blur(5px); }
    to { opacity: 1; transform: none; filter: blur(0); }
}
@keyframes pulse {
    50% { box-shadow: 0 0 42px #ff6a0077; }
}
@keyframes ringPulse {
    to { transform: scale(1.25); opacity: 0; }
}
@keyframes slideIn {
    from { opacity: 0; transform: translateY(13px); }
    to { opacity: 1; transform: translateY(0); }
}
@keyframes shine {
    0%, 75%, 100% { transform: translateX(-160%) rotate(20deg); }
    35% { transform: translateX(450%) rotate(20deg); }
}
@keyframes shake {
    25% { transform: translateX(-4px); }
    75% { transform: translateX(4px); }
}
@keyframes spin {
    to { transform: rotate(360deg); }
}

.page {
    width: 100%;
    max-width: 510px;
    position: relative;
    z-index: 1;
    animation: appear .8s cubic-bezier(.2,.8,.2,1) both;
}

.brand { text-align: center; margin-bottom: 24px; }

.brand-icon {
    width: 59px;
    height: 59px;
    display: grid;
    place-items: center;
    margin: 0 auto 13px;
    border-radius: 18px;
    color: #210d00;
    font-size: 32px;
    font-weight: 950;
    background: linear-gradient(135deg, #ffe3b4, #ff9c43 48%, #ff6200);
    box-shadow: 0 0 30px #ff6a0050, inset 0 1px #ffffff99;
    position: relative;
    animation: pulse 3s ease-in-out infinite;
}

.brand-icon::after {
    content: "";
    position: absolute;
    inset: -5px;
    border: 1px solid #ffad6b80;
    border-radius: 22px;
    animation: ringPulse 3s ease-out infinite;
}

.brand h1 {
    font-size: clamp(28px, 5vw, 35px);
    letter-spacing: -1.2px;
    font-weight: 850;
}
.brand h1 span { color: var(--amber); }
.brand p { margin-top: 8px; font-size: 13px; color: var(--muted); }

.card {
    position: relative;
    overflow: hidden;
    padding: 32px;
    border: 1px solid var(--line);
    border-radius: 25px;
    background: var(--panel);
    backdrop-filter: blur(24px);
    -webkit-backdrop-filter: blur(24px);
    box-shadow: 0 30px 90px #0009, 0 0 40px #ff6a000c;
    transition: border-color .3s, box-shadow .3s;
}

.card:hover {
    border-color: #ffad6b66;
    box-shadow: 0 30px 90px #0009, 0 0 55px #ff6a0019;
}

.card::before {
    content: "";
    position: absolute;
    top: 0;
    left: 12%;
    right: 12%;
    height: 1px;
    background: linear-gradient(90deg, transparent, #ffd09b, #ff6a00, transparent);
}

.card::after {
    content: "";
    position: absolute;
    top: -100%;
    left: -50%;
    width: 28%;
    height: 300%;
    pointer-events: none;
    background: linear-gradient(90deg, transparent, #ffffff0a, transparent);
    animation: shine 9s ease-in-out infinite;
}

.card h2 { font-size: 27px; letter-spacing: -.7px; margin-bottom: 8px; }
.subtitle { color: var(--muted); font-size: 13.5px; line-height: 1.7; margin-bottom: 23px; }
.subtitle strong { color: var(--gold); }

.alert {
    padding: 13px 15px;
    margin-bottom: 19px;
    border-radius: 12px;
    background: #ff414115;
    border: 1px solid #ff5a5a55;
    color: #ffb8ae;
    font-size: 13px;
    line-height: 1.6;
    animation: shake .35s ease;
}

.role-label, .field label {
    display: block;
    margin-bottom: 8px;
    color: #eee4dc;
    font-size: 13px;
    font-weight: 700;
}

.roles {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 11px;
    margin-bottom: 19px;
}

.role-card { position: relative; cursor: pointer; }
.role-card input { position: absolute; opacity: 0; }

.role-box {
    display: flex;
    flex-direction: column;
    gap: 5px;
    padding: 14px;
    border: 1px solid #ffffff1c;
    border-radius: 13px;
    background: #ffffff08;
    transition: .25s ease;
}

.role-box b { font-size: 14px; }
.role-box small { color: var(--muted); font-size: 11.5px; line-height: 1.5; }

.role-card:hover .role-box {
    transform: translateY(-2px);
    border-color: #ff913d66;
}

.role-card input:checked + .role-box {
    border-color: var(--amber);
    background: linear-gradient(145deg, #ff6a0029, #ff6a000a);
    box-shadow: 0 0 0 3px #ff6a0018, 0 0 22px #ff6a001f;
}

.role-card input:checked + .role-box b { color: var(--gold); }
.role-card input:focus-visible + .role-box { outline: 2px solid var(--amber); }

.field {
    margin-bottom: 17px;
    animation: slideIn .55s ease both;
    animation-delay: var(--delay, 0ms);
}

.input-wrap { position: relative; }

.input-wrap input {
    display: block;
    width: 100%;
    height: 51px;
    padding: 0 14px;
    border: 1px solid #ffffff1c;
    border-radius: 12px;
    outline: 0;
    background: #ffffff08;
    color: var(--text);
    font: inherit;
    font-size: 14px;
    transition: border-color .25s, box-shadow .25s, background .25s;
}

.input-wrap input::placeholder { color: #746b64; }
.input-wrap input:hover { border-color: #ff913d66; }

.input-wrap input:focus {
    border-color: var(--amber);
    background: #ff6a000d;
    box-shadow: 0 0 0 3px #ff6a001c, 0 0 22px #ff6a0010;
}

.input-wrap input.pw { padding-right: 70px; }

.toggle {
    position: absolute;
    right: 11px;
    top: 50%;
    transform: translateY(-50%);
    padding: 7px 5px;
    border: 0;
    background: none;
    color: var(--amber);
    font-size: 12px;
    font-weight: 800;
    cursor: pointer;
}

.meter { display: flex; gap: 6px; margin-top: 9px; }
.meter i {
    height: 4px;
    flex: 1;
    border-radius: 5px;
    background: #ffffff12;
    transition: background .3s, box-shadow .3s;
}
.meter i.on {
    background: var(--meter-color, var(--orange));
    box-shadow: 0 0 10px var(--meter-color, var(--orange));
}
.hint { min-height: 16px; margin-top: 7px; color: var(--muted); font-size: 11.5px; }

.terms {
    display: flex;
    align-items: flex-start;
    gap: 10px;
    margin: 5px 0 21px;
    color: #c6bdb4;
    font-size: 12px;
    line-height: 1.6;
    cursor: pointer;
}
.terms a { color: var(--amber); text-decoration: none; }
.terms a:hover { text-decoration: underline; }
.terms input { accent-color: var(--orange); margin-top: 3px; }

.submit-btn {
    position: relative;
    isolation: isolate;
    overflow: hidden;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 9px;
    width: 100%;
    min-height: 53px;
    padding: 13px 18px;
    border: 1px solid #ffd29699;
    border-radius: 13px;
    color: #1b0c02;
    background: linear-gradient(110deg, #d94b00, #ff790d 25%, #ffb15c 48%, #ff8120 72%, #e65100);
    background-size: 250% 100%;
    font: inherit;
    font-size: 15px;
    font-weight: 850;
    cursor: pointer;
    box-shadow: 0 8px 25px #ff6a0038, inset 0 1px #ffffff66;
    transition: transform .25s, box-shadow .25s, filter .25s;
    animation: gradientMove 6s linear infinite;
}

@keyframes gradientMove {
    to { background-position: -150% 50%; }
}

.submit-btn::before {
    content: "";
    position: absolute;
    inset: 0;
    z-index: -1;
    background: linear-gradient(105deg, transparent 25%, #ffffff70 50%, transparent 75%);
    transform: translateX(-130%);
    transition: transform .65s;
}

.submit-btn:hover {
    transform: translateY(-3px);
    box-shadow: 0 13px 35px #ff6a0055;
    filter: saturate(1.12) brightness(1.04);
}
.submit-btn:hover::before { transform: translateX(130%); }
.submit-btn:active { transform: translateY(-1px) scale(.99); }
.arrow { transition: transform .25s; }
.submit-btn:hover .arrow { transform: translateX(5px); }
.submit-btn.loading { pointer-events: none; opacity: .8; }

.divider {
    display: flex;
    align-items: center;
    gap: 12px;
    margin: 23px 0 17px;
    color: #887b70;
    font-size: 10px;
    font-weight: 750;
    letter-spacing: 1.4px;
}
.divider::before, .divider::after {
    content: "";
    height: 1px;
    flex: 1;
    background: linear-gradient(90deg, transparent, #ff8c324d);
}
.divider::after { background: linear-gradient(90deg, #ff8c324d, transparent); }

.login-text { text-align: center; color: var(--muted); font-size: 13px; }
.login-text a {
    margin-left: 3px;
    color: var(--amber);
    font-weight: 800;
    text-decoration: none;
}
.login-text a:hover { color: #ffd0a8; }
.footer { text-align: center; margin-top: 22px; color: #756b62; font-size: 11px; }
.footer span { color: var(--amber); }

@media (max-width: 480px) {
    body { padding: 22px 13px; }
    .card { padding: 25px 19px; border-radius: 21px; }
    .card h2 { font-size: 24px; }
    .roles { gap: 9px; }
}
@media (prefers-reduced-motion: reduce) {
    *, *::before, *::after {
        animation-duration: .01ms !important;
        animation-iteration-count: 1 !important;
        transition-duration: .01ms !important;
    }
}
</style>
</head>

<body>
<canvas id="particles" aria-hidden="true"></canvas>
<div class="grid" aria-hidden="true"></div>
<div class="orb one" aria-hidden="true"></div>
<div class="orb two" aria-hidden="true"></div>
<div class="ring left" aria-hidden="true"></div>
<div class="ring right" aria-hidden="true"></div>

<main class="page">
    <header class="brand">
        <div class="brand-icon" aria-hidden="true">C</div>
        <h1>Career<span>Bridge</span></h1>
        <p>Your next opportunity starts here.</p>
    </header>

    <section class="card">
        <h2>Create your account</h2>
        <p class="subtitle">
            Join CareerBridge and start building your
            <strong>career journey.</strong>
        </p>

        <?php if ($error !== ''): ?>
            <div class="alert" role="alert"><?= h($error) ?></div>
        <?php endif; ?>

        <form method="POST" action="" id="registerForm" autocomplete="on">
            <input
                type="hidden"
                name="csrf_token"
                value="<?= h($_SESSION['register_csrf']) ?>"
            >

            <div class="field" style="--delay:50ms">
                <span class="role-label">I am joining as</span>
                <div class="roles">
                    <label class="role-card">
                        <input type="radio" name="role" value="student"
                            <?= $role === 'student' ? 'checked' : '' ?>>
                        <span class="role-box">
                            <b>Student</b>
                            <small>Find jobs and internships</small>
                        </span>
                    </label>

                    <label class="role-card">
                        <input type="radio" name="role" value="company"
                            <?= $role === 'company' ? 'checked' : '' ?>>
                        <span class="role-box">
                            <b>Company</b>
                            <small>Post roles and hire talent</small>
                        </span>
                    </label>
                </div>
            </div>

            <div class="field" style="--delay:100ms">
                <label for="name">Full Name / Contact Person</label>
                <div class="input-wrap">
                    <input type="text" id="name" name="name"
                        placeholder="Enter your full name"
                        maxlength="100" autocomplete="name"
                        value="<?= h($name) ?>" required>
                </div>
            </div>

            <div class="field" id="companyField" style="--delay:150ms">
                <label for="company_name">Company Name</label>
                <div class="input-wrap">
                    <input type="text" id="company_name" name="company_name"
                        placeholder="Enter your registered company name"
                        maxlength="150" autocomplete="organization"
                        value="<?= h($companyName) ?>"
                        <?= $role === 'company' ? 'required' : '' ?>>
                </div>
            </div>

            <div class="field" style="--delay:200ms">
                <label for="email">Email Address</label>
                <div class="input-wrap">
                    <input type="email" id="email" name="email"
                        placeholder="you@example.com"
                        maxlength="150" autocomplete="email"
                        value="<?= h($email) ?>" required>
                </div>
            </div>

            <div class="field" style="--delay:250ms">
                <label for="password">Password</label>
                <div class="input-wrap">
                    <input type="password" id="password" name="password"
                        class="pw" placeholder="Create a password"
                        autocomplete="new-password" required>
                    <button type="button" class="toggle"
                        data-target="password">Show</button>
                </div>
                <div class="meter" aria-hidden="true">
                    <i></i><i></i><i></i><i></i>
                </div>
                <p class="hint" id="strengthHint" aria-live="polite">
                    Use 8+ characters with letters and numbers.
                </p>
            </div>

            <div class="field" style="--delay:300ms">
                <label for="confirm_password">Confirm Password</label>
                <div class="input-wrap">
                    <input type="password" id="confirm_password" name="confirm_password"
                        class="pw" placeholder="Re-enter your password"
                        autocomplete="new-password" required>
                    <button type="button" class="toggle"
                        data-target="confirm_password">Show</button>
                </div>
                <p class="hint" id="matchHint" aria-live="polite"></p>
            </div>

            <label class="terms">
                <input type="checkbox" name="terms" value="1" required>
                <span>
                    I agree to the
                    <a href="terms.php">Terms</a> and
                    <a href="privacy.php">Privacy Policy</a>.
                </span>
            </label>

            <button type="submit" class="submit-btn" id="submitBtn">
                <span>Create Account</span>
                <span class="arrow" aria-hidden="true">→</span>
            </button>
        </form>

        <div class="divider">ALREADY A MEMBER?</div>
        <p class="login-text">
            Have an account? <a href="login.php">Sign in ↗</a>
        </p>
    </section>

    <footer class="footer">
        © <?= date('Y') ?> <span>CareerBridge</span>. All rights reserved.
    </footer>
</main>

<script>
/* Show/hide password buttons */
document.querySelectorAll('.toggle').forEach(button => {
    button.addEventListener('click', () => {
        const input = document.getElementById(button.dataset.target);
        const show = input.type === 'password';
        input.type = show ? 'text' : 'password';
        button.textContent = show ? 'Hide' : 'Show';
    });
});

/* Show the company field only for company registrations. */
const companyField = document.getElementById('companyField');
const companyInput = document.getElementById('company_name');

function updateRoleFields() {
    const role = document.querySelector('input[name="role"]:checked')?.value;
    const isCompany = role === 'company';
    companyField.hidden = !isCompany;
    companyInput.required = isCompany;
}
document.querySelectorAll('input[name="role"]').forEach(radio => {
    radio.addEventListener('change', updateRoleFields);
});
updateRoleFields();

/* Password strength and confirmation feedback. */
const password = document.getElementById('password');
const confirmPassword = document.getElementById('confirm_password');
const bars = document.querySelectorAll('.meter i');
const strengthHint = document.getElementById('strengthHint');
const matchHint = document.getElementById('matchHint');

function checkPassword() {
    const value = password.value;
    let score = 0;

    if (value.length >= 8) score++;
    if (/[a-z]/.test(value) && /[A-Z]/.test(value)) score++;
    if (/[0-9]/.test(value)) score++;
    if (/[^A-Za-z0-9]/.test(value) || value.length >= 12) score++;

    const labels = ['Too weak', 'Fair', 'Good', 'Strong'];
    const colors = ['#ff5a5a', '#ff9b42', '#ffc36b', '#80efb3'];

    bars.forEach((bar, index) => {
        bar.classList.toggle('on', index < score);
        bar.style.setProperty('--meter-color', colors[Math.max(0, score - 1)]);
    });

    strengthHint.textContent = value
        ? labels[Math.max(0, score - 1)]
        : 'Use 8+ characters with letters and numbers.';
    strengthHint.style.color = value ? colors[Math.max(0, score - 1)] : '';

    checkMatch();
}

function checkMatch() {
    if (!confirmPassword.value) {
        matchHint.textContent = '';
        return;
    }

    const matches = password.value === confirmPassword.value;
    matchHint.textContent = matches
        ? 'Passwords match.'
        : 'Passwords do not match yet.';
    matchHint.style.color = matches ? '#80efb3' : '#ffb8ae';
}

password.addEventListener('input', checkPassword);
confirmPassword.addEventListener('input', checkMatch);

/* Client-side checks; PHP repeats the important checks on the server. */
document.getElementById('registerForm').addEventListener('submit', event => {
    if (password.value.length < 8 ||
        !/[A-Za-z]/.test(password.value) ||
        !/[0-9]/.test(password.value)) {
        event.preventDefault();
        alert('Use at least 8 characters, including a letter and a number.');
        password.focus();
        return;
    }

    if (password.value !== confirmPassword.value) {
        event.preventDefault();
        alert('The passwords do not match.');
        confirmPassword.focus();
        return;
    }

    if (companyInput.required && companyInput.value.trim().length < 2) {
        event.preventDefault();
        alert('Please enter your company name.');
        companyInput.focus();
        return;
    }

    document.getElementById('submitBtn').classList.add('loading');
});

/* Animated orange particle network. */
(() => {
    const canvas = document.getElementById('particles');
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
    let width = 0, height = 0, dpr = 1, particles = [];
    const pointer = { x: -1000, y: -1000 };

    function resize() {
        width = window.innerWidth;
        height = window.innerHeight;
        dpr = Math.min(window.devicePixelRatio || 1, 2);
        canvas.width = width * dpr;
        canvas.height = height * dpr;
        ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

        particles = Array.from(
            { length: Math.min(75, Math.max(25, Math.floor(width / 18))) },
            () => ({
                x: Math.random() * width,
                y: Math.random() * height,
                r: Math.random() * 1.5 + .5,
                vx: (Math.random() - .5) * .28,
                vy: (Math.random() - .5) * .28,
                alpha: Math.random() * .45 + .15
            })
        );

        draw();
    }

    function draw() {
        ctx.clearRect(0, 0, width, height);

        particles.forEach((p, i) => {
            if (!reducedMotion.matches) {
                p.x += p.vx;
                p.y += p.vy;

                const dx = p.x - pointer.x;
                const dy = p.y - pointer.y;
                const distance = Math.hypot(dx, dy);

                if (distance < 100 && distance > 0) {
                    p.x += dx / distance * .5;
                    p.y += dy / distance * .5;
                }

                if (p.x < 0) p.x = width;
                if (p.x > width) p.x = 0;
                if (p.y < 0) p.y = height;
                if (p.y > height) p.y = 0;
            }

            ctx.beginPath();
            ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
            ctx.fillStyle = `rgba(255,140,45,${p.alpha})`;
            ctx.fill();

            for (let j = i + 1; j < particles.length; j++) {
                const q = particles[j];
                const distance = Math.hypot(p.x - q.x, p.y - q.y);

                if (distance < 85) {
                    ctx.beginPath();
                    ctx.moveTo(p.x, p.y);
                    ctx.lineTo(q.x, q.y);
                    ctx.strokeStyle = `rgba(255,135,45,${(1 - distance / 85) * .12})`;
                    ctx.lineWidth = .7;
                    ctx.stroke();
                }
            }
        });
    }

    function animate() {
        draw();
        if (!reducedMotion.matches) requestAnimationFrame(animate);
    }

    window.addEventListener('pointermove', event => {
        pointer.x = event.clientX;
        pointer.y = event.clientY;
    }, { passive: true });

    window.addEventListener('resize', resize, { passive: true });
    resize();

    if (!reducedMotion.matches) requestAnimationFrame(animate);
})();
</script>
</body>
</html>
