# InternHub - ByteXL Setup

1. Select your MySQL database in ByteXL and run `database.sql`. This version does not try to create a database, so it also works where `CREATE DATABASE` is blocked.
2. Edit `config/database.php` with your database host, name, username and password. Environment variables `DB_HOST`, `DB_NAME`, `DB_USER`, `DB_PASS` are also supported.
3. Start from the folder that contains `internship-portal`.
4. Open `/health.php` first. It must report **Database connection: OK**.
5. Then open `/` and test Register -> Login -> Student/Company workflow.

If PDO MySQL is not enabled in the ByteXL PHP runtime, the application cannot connect to MySQL until that PHP extension is enabled. The ZIP cannot replace a missing server PHP extension with PHP code.
