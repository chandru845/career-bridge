
<?php
require_once __DIR__ . "/config/database.php";

if (function_exists('is_logged_in') && is_logged_in()) {
    if (function_exists('redirect')) {
        redirect(function_exists('dashboard_path') ? dashboard_path() : 'student/dashboard.php');
    } else {
        header("Location: student/dashboard.php");
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="theme-color" content="#080909">
<title>CareerBridge | Your Future in Motion</title>

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">

<style>
:root {
    --bg: #080909;
    --panel: #111211;
    --orange: #ff841f;
    --orange-light: #ffc17e;
    --white: #f8f6f3;
    --muted: #b6b3b5;
    --border: rgba(255,255,255,.11);
    --green: #36e4a3;
}

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

html {
    scroll-behavior: smooth;
    scroll-padding-top: 85px;
}

body {
    font-family: 'Inter', sans-serif;
    color: var(--white);
    background: var(--bg);
    overflow-x: hidden;
    line-height: 1.6;
}

a {
    color: inherit;
    text-decoration: none;
}

button {
    font: inherit;
}

::selection {
    color: #080909;
    background: var(--orange);
}

.container {
    width: min(1380px, calc(100% - 80px));
    margin: auto;
}

/* ==================================================
   VISIBLE ANIMATED BACKGROUND
================================================== */

.background {
    position: fixed;
    inset: 0;
    z-index: -5;
    overflow: hidden;
    pointer-events: none;
    background:
        radial-gradient(ellipse at 72% 35%, rgba(255,91,10,.16), transparent 36%),
        radial-gradient(ellipse at 8% 85%, rgba(255,114,15,.12), transparent 34%),
        #080909;
}

.ambient-glow {
    position: absolute;
    width: 520px;
    height: 520px;
    border-radius: 50%;
    background: #ff650d;
    filter: blur(130px);
    opacity: .19;
    will-change: transform;
    animation: glowDrift 10s ease-in-out infinite alternate;
}

.ambient-glow.one {
    top: 5%;
    left: 48%;
}

.ambient-glow.two {
    width: 420px;
    height: 420px;
    bottom: -10%;
    left: -10%;
    opacity: .13;
    animation-delay: -4s;
}

.ambient-glow.three {
    width: 350px;
    height: 350px;
    right: -12%;
    top: 55%;
    opacity: .15;
    animation-delay: -7s;
}

.background-grid {
    position: absolute;
    inset: 0;
    opacity: .16;
    background-image:
        linear-gradient(rgba(255,143,48,.09) 1px, transparent 1px),
        linear-gradient(90deg, rgba(255,143,48,.09) 1px, transparent 1px);
    background-size: 65px 65px;
    mask-image: linear-gradient(to bottom, black, transparent 90%);
}

#particles {
    position: fixed;
    inset: 0;
    width: 100%;
    height: 100%;
    z-index: -3;
    pointer-events: none;
}

/* ==================================================
   HEADER
================================================== */

.header {
    position: sticky;
    top: 0;
    z-index: 100;
    background: rgba(8,9,9,.88);
    backdrop-filter: blur(20px);
    border-bottom: 1px solid rgba(255,132,31,.25);
}

.navbar {
    min-height: 73px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 25px;
}

.brand {
    display: inline-flex;
    align-items: center;
    gap: 12px;
    flex-shrink: 0;
}

.brand-icon {
    width: 43px;
    height: 43px;
    display: grid;
    place-items: center;
    border-radius: 13px;
    color: #211308;
    font-size: 27px;
    background: linear-gradient(145deg,#ffd28d,#ff922d,#f16b11);
    box-shadow: 0 0 28px rgba(255,127,31,.32);
    animation: logoPulse 4s ease-in-out infinite;
}

.brand-name {
    font-size: 25px;
    font-weight: 900;
    letter-spacing: -1.3px;
}

.brand-name span {
    color: var(--orange);
}

.nav-links {
    display: flex;
    align-items: center;
    gap: 36px;
}

.nav-links a {
    position: relative;
    color: #d2ced0;
    font-size: 13px;
    font-weight: 600;
    transition: color .25s;
}

.nav-links a:hover,
.nav-links a.active {
    color: var(--orange);
}

.nav-links a::after {
    content: "";
    position: absolute;
    width: 0;
    height: 2px;
    left: 0;
    bottom: -8px;
    background: var(--orange);
    box-shadow: 0 0 12px var(--orange);
    transition: width .3s;
}

.nav-links a:hover::after,
.nav-links a.active::after {
    width: 100%;
}

.nav-actions {
    display: flex;
    align-items: center;
    gap: 13px;
}

.btn {
    min-height: 47px;
    display: inline-flex;
    justify-content: center;
    align-items: center;
    gap: 10px;
    padding: 0 22px;
    border: 1px solid transparent;
    border-radius: 13px;
    font-size: 12px;
    font-weight: 800;
    transition: transform .25s, box-shadow .25s, border-color .25s;
    cursor: pointer;
    white-space: nowrap;
}

.btn:hover {
    transform: translateY(-3px);
}

.btn-primary {
    color: #1a1008;
    background: linear-gradient(110deg,#ffbd72,#ff8b27 70%,#ff9a36);
    box-shadow: 0 8px 25px rgba(255,120,25,.17);
}

.btn-primary:hover {
    box-shadow: 0 10px 35px rgba(255,120,25,.4);
}

.btn-outline {
    color: #f8f5f1;
    border-color: rgba(255,255,255,.28);
    background: rgba(255,255,255,.015);
}

.btn-outline:hover {
    border-color: var(--orange);
    background: rgba(255,131,31,.07);
}

.menu-toggle {
    display: none;
    width: 42px;
    height: 42px;
    border: 1px solid var(--border);
    border-radius: 11px;
    color: white;
    background: #121212;
    font-size: 23px;
    cursor: pointer;
}

/* ==================================================
   HERO SECTION
================================================== */

.hero {
    position: relative;
    isolation: isolate;
    overflow: hidden;
    border-bottom: 1px solid rgba(255,133,31,.35);
}

.hero::before {
    content: "";
    position: absolute;
    z-index: -1;
    inset: 0;
    background:
        radial-gradient(ellipse at 70% 45%, rgba(255,102,15,.14), transparent 37%),
        linear-gradient(110deg,rgba(255,255,255,.015),transparent 55%,rgba(255,100,10,.035));
}

/* Moving light across the bottom of the hero */
.hero-light-line {
    position: absolute;
    left: -30%;
    bottom: 0;
    width: 65%;
    height: 2px;
    background: linear-gradient(90deg,transparent,#ff7015,#ffd09b,transparent);
    box-shadow: 0 0 25px 3px rgba(255,111,17,.65);
    animation: lightSweep 8s linear infinite;
    pointer-events: none;
}

.hero-grid {
    min-height: 550px;
    display: grid;
    grid-template-columns: 1fr 1fr;
    align-items: center;
    gap: 30px;
    padding-top: 43px;
    padding-bottom: 43px;
}

.hero-copy {
    position: relative;
    z-index: 5;
    animation: enterLeft .9s ease both;
}

.eyebrow {
    display: inline-flex;
    align-items: center;
    gap: 10px;
    padding: 9px 15px;
    border: 1px solid rgba(255,139,41,.8);
    border-radius: 999px;
    background: rgba(255,128,25,.07);
    color: #f8e5d2;
    font-size: 10px;
    font-weight: 800;
    letter-spacing: 1.5px;
    text-transform: uppercase;
}

.eyebrow-dot {
    width: 10px;
    height: 10px;
    border-radius: 50%;
    background: var(--orange);
    box-shadow: 0 0 13px var(--orange);
    animation: dotBlink 1.7s infinite;
}

.hero h1 {
    margin-top: 22px;
    font-size: clamp(47px,5.2vw,77px);
    line-height: 1.08;
    font-weight: 900;
    letter-spacing: -4px;
}

.gradient-text {
    background: linear-gradient(95deg,#ffdda9,#ff8a35 55%,#ffb2a4,#ff8a35);
    background-size: 250% auto;
    color: transparent;
    -webkit-background-clip: text;
    background-clip: text;
    animation: textFlow 7s linear infinite;
}

.hero-description {
    max-width: 520px;
    margin-top: 18px;
    color: var(--muted);
    font-size: 13px;
    line-height: 1.9;
}

.hero-actions {
    display: flex;
    align-items: center;
    flex-wrap: wrap;
    gap: 14px;
    margin-top: 24px;
}

.hero-actions .btn {
    min-height: 54px;
    padding: 0 25px;
}

.hero-points {
    display: flex;
    flex-wrap: wrap;
    gap: 18px;
    margin-top: 28px;
    color: #cbc7c7;
    font-size: 10px;
}

.hero-points span {
    display: inline-flex;
    align-items: center;
    gap: 8px;
}

.hero-points b {
    color: var(--orange);
    font-size: 18px;
}

/* ==================================================
   NEW RIGHT-SIDE CAREER ILLUSTRATION
   Old floating labels and dashboard removed.
================================================== */

.hero-visual {
    position: relative;
    min-width: 0;
    min-height: 470px;
    display: flex;
    align-items: center;
    justify-content: center;
    isolation: isolate;
    animation: enterRight 1s ease both;
}

/* Glowing centre */
.visual-aura {
    position: absolute;
    width: 310px;
    height: 310px;
    border-radius: 50%;
    background: rgba(255,108,17,.13);
    filter: blur(65px);
    animation: auraBreath 5s ease-in-out infinite;
}

/* Large orbit rings */
.orbit {
    position: absolute;
    width: 440px;
    height: 260px;
    border: 1px solid rgba(255,132,29,.68);
    border-radius: 50%;
    transform: rotate(-31deg);
    box-shadow: 0 0 25px rgba(255,111,17,.08);
    animation: orbitSpin 24s linear infinite;
}

.orbit::before {
    content: "";
    position: absolute;
    top: 10%;
    left: 16%;
    width: 9px;
    height: 9px;
    border-radius: 50%;
    background: #ffb85f;
    box-shadow: 0 0 18px 5px rgba(255,125,24,.8);
}

.orbit-two {
    width: 510px;
    height: 330px;
    border-color: rgba(255,154,66,.28);
    animation-duration: 35s;
    animation-direction: reverse;
}

.orbit-two::before {
    top: 82%;
    left: 83%;
    width: 7px;
    height: 7px;
}

.orbit-three {
    width: 360px;
    height: 360px;
    border-color: rgba(255,128,31,.2);
    animation-duration: 45s;
}

.orbit-three::before {
    top: 20%;
    left: 87%;
    width: 5px;
    height: 5px;
}

/* A glowing planet */
.planet {
    position: absolute;
    top: 8%;
    right: 3%;
    width: 100px;
    height: 100px;
    border-radius: 50%;
    background:
        radial-gradient(circle at 28% 25%,#ffe0ad,#e98432 26%,#713114 60%,#100b08 100%);
    box-shadow:
        inset -17px -12px 30px #100a07,
        0 0 45px rgba(255,111,20,.25);
    animation: planetFloat 7s ease-in-out infinite;
}

.planet-small {
    position: absolute;
    left: 9%;
    bottom: 17%;
    width: 30px;
    height: 30px;
    border-radius: 50%;
    background: radial-gradient(circle at 30% 25%,#ffe2b8,#ff8b2d 48%,#54220b);
    box-shadow: 0 0 22px rgba(255,120,25,.4);
    animation: planetFloat 5s ease-in-out infinite reverse;
}

/* Main illustration card */
.career-art {
    position: relative;
    z-index: 3;
    width: min(100%,410px);
    aspect-ratio: 1 / 1.04;
    display: grid;
    place-items: center;
    border: 1px solid rgba(255,165,82,.5);
    border-radius: 48% 48% 35% 35%;
    background:
        radial-gradient(ellipse at 50% 35%,rgba(255,127,31,.17),transparent 47%),
        linear-gradient(145deg,rgba(25,23,21,.8),rgba(8,9,9,.92));
    box-shadow:
        0 0 0 8px rgba(255,132,31,.025),
        0 0 0 17px rgba(255,132,31,.018),
        0 0 55px rgba(255,100,10,.14),
        inset 0 0 55px rgba(255,128,31,.045);
    animation: artFloat 6s ease-in-out infinite;
}

/* Rotating light around the art card */
.career-art::before {
    content: "";
    position: absolute;
    inset: -2px;
    padding: 2px;
    border-radius: inherit;
    background: conic-gradient(
        from 0deg,
        transparent 0 45%,
        #ff7417 54%,
        #ffd09a 58%,
        transparent 67% 100%
    );
    -webkitmask: linear-gradient(#fff 0 0) content-box,linear-gradient(#fff 0 0);
    -webkitmask-composite: xor;
    mask-composite: exclude;
    animation: borderRotate 6s linear infinite;
    pointer-events: none;
}

/* Decorative circles inside the art */
.art-inner-ring {
    position: absolute;
    width: 75%;
    height: 75%;
    border: 1px solid rgba(255,155,74,.23);
    border-radius: 50%;
    animation: innerRing 18s linear infinite;
}

.art-inner-ring::before,
.art-inner-ring::after {
    content: "";
    position: absolute;
    width: 9px;
    height: 9px;
    border-radius: 50%;
    background: var(--orange);
    box-shadow: 0 0 15px var(--orange);
}

.art-inner-ring::before {
    top: 9%;
    left: 17%;
}

.art-inner-ring::after {
    right: 12%;
    bottom: 15%;
    background: #ffd09a;
}

/* Main 3D-style symbol */
.art-symbol {
    position: relative;
    width: 150px;
    height: 150px;
    display: grid;
    place-items: center;
    border-radius: 38px;
    color: #211006;
    font-size: 85px;
    background: linear-gradient(145deg,#ffe1ad,#ff9a3d 48%,#f36d12);
    box-shadow:
        0 0 35px rgba(255,131,31,.35),
        0 0 85px rgba(255,131,31,.17),
        inset 0 2px 2px rgba(255,255,255,.65);
    transform: rotate(-9deg);
    animation: symbolFloat 5s ease-in-out infinite;
}

.art-symbol::after {
    content: "";
    position: absolute;
    inset: 9px;
    border: 1px solid rgba(255,255,255,.25);
    border-radius: 30px;
}

.art-symbol span {
    filter: drop-shadow(0 4px 2px rgba(96,35,0,.2));
}

.art-caption {
    position: absolute;
    bottom: 11%;
    left: 0;
    right: 0;
    text-align: center;
}

.art-caption strong {
    display: block;
    font-size: 20px;
    letter-spacing: -.7px;
}

.art-caption strong span {
    color: var(--orange);
}

.art-caption p {
    margin-top: 5px;
    color: #c0b9b5;
    font-size: 11px;
}

/* Small decorative badges: icons only, no old dashboard content */
.art-badge {
    position: absolute;
    z-index: 5;
    width: 62px;
    height: 62px;
    display: grid;
    place-items: center;
    border: 1px solid rgba(255,149,64,.58);
    border-radius: 19px;
    color: #ffc17e;
    background: linear-gradient(145deg,rgba(33,26,20,.98),rgba(12,12,12,.98));
    box-shadow: 0 10px 35px rgba(0,0,0,.45),0 0 22px rgba(255,117,22,.1);
    font-size: 29px;
    backdrop-filter: blur(12px);
    animation: badgeFloat 5s ease-in-out infinite;
}

.badge-search {
    top: 17%;
    left: 1%;
}

.badge-star {
    top: 32%;
    right: -1%;
    animation-delay: -1.4s;
}

.badge-check {
    bottom: 16%;
    right: 5%;
    animation-delay: -2.8s;
}

.badge-arrow {
    bottom: 20%;
    left: 0;
    animation-delay: -3.7s;
}

/* Small light points */
.light-point {
    position: absolute;
    z-index: 2;
    width: 6px;
    height: 6px;
    border-radius: 50%;
    background: #ffb75d;
    box-shadow: 0 0 15px 4px rgba(255,132,31,.45);
    animation: pointPulse 3s ease-in-out infinite;
}

.point-one { top: 14%; left: 20%; }
.point-two { top: 23%; right: 11%; animation-delay: -1s; }
.point-three { bottom: 29%; left: 14%; animation-delay: -2s; }
.point-four { bottom: 17%; right: 21%; animation-delay: -.5s; }

/* ==================================================
   MOVING BENEFITS STRIP
================================================== */

.ticker {
    position: relative;
    overflow: hidden;
    border-bottom: 1px solid rgba(255,135,31,.3);
    background: rgba(255,255,255,.018);
}

.ticker::before,
.ticker::after {
    content: "";
    position: absolute;
    z-index: 2;
    top: 0;
    bottom: 0;
    width: 65px;
    pointer-events: none;
}

.ticker::before {
    left: 0;
    background: linear-gradient(90deg,#080909,transparent);
}

.ticker::after {
    right: 0;
    background: linear-gradient(270deg,#080909,transparent);
}

.ticker-track {
    display: flex;
    width: max-content;
    animation: tickerMove 32s linear infinite;
}

.ticker:hover .ticker-track {
    animation-play-state: paused;
}

.ticker-group {
    display: flex;
    align-items: center;
    gap: 30px;
    padding: 17px 15px;
    white-space: nowrap;
}

.ticker-item {
    display: flex;
    align-items: center;
    gap: 11px;
    color: #ded9d9;
    font-size: 10px;
    font-weight: 800;
    text-transform: uppercase;
    letter-spacing: .5px;
}

.ticker-item span {
    color: var(--orange);
    font-size: 17px;
}

.separator {
    color: var(--orange);
}

/* ==================================================
   FEATURES
================================================== */

.features {
    position: relative;
    overflow: hidden;
    padding: 65px 0 78px;
}

.features::after {
    content: "";
    position: absolute;
    right: -200px;
    bottom: -330px;
    width: 480px;
    height: 480px;
    border: 1px solid rgba(255,132,31,.16);
    border-radius: 50%;
    box-shadow:
        0 0 0 45px rgba(255,132,31,.02),
        0 0 0 90px rgba(255,132,31,.015);
    pointer-events: none;
}

.features-grid {
    display: grid;
    grid-template-columns: .95fr 2.05fr;
    align-items: center;
    gap: 38px;
}

.section-kicker {
    color: var(--orange);
    font-size: 10px;
    font-weight: 900;
    letter-spacing: 1.7px;
    text-transform: uppercase;
}

.features-intro h2 {
    margin-top: 12px;
    font-size: clamp(27px,3vw,36px);
    font-weight: 900;
    line-height: 1.2;
    letter-spacing: -1.4px;
}

.features-intro h2 span {
    color: var(--orange);
}

.features-intro p {
    max-width: 340px;
    margin-top: 13px;
    color: var(--muted);
    font-size: 12px;
    line-height: 1.9;
}

.feature-cards {
    display: grid;
    grid-template-columns: repeat(3,minmax(0,1fr));
    gap: 16px;
}

.feature-card {
    position: relative;
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    min-height: 205px;
    padding: 20px;
    overflow: hidden;
    border: 1px solid rgba(255,255,255,.11);
    border-radius: 16px;
    background: linear-gradient(145deg,rgba(16,17,17,.96),rgba(10,11,11,.96));
    transition: transform .35s,border-color .35s,box-shadow .35s;
}

.feature-card::before {
    content: "";
    position: absolute;
    top: -90px;
    right: -80px;
    width: 150px;
    height: 150px;
    border-radius: 50%;
    background: rgba(255,132,31,.1);
    filter: blur(22px);
    transition: transform .5s;
}

.feature-card:hover {
    transform: translateY(-7px);
    border-color: rgba(255,136,34,.6);
    box-shadow: 0 18px 40px rgba(0,0,0,.28);
}

.feature-card:hover::before {
    transform: scale(1.7);
}

.feature-icon {
    position: relative;
    width: 47px;
    height: 47px;
    display: grid;
    place-items: center;
    border: 1px solid rgba(255,132,31,.5);
    border-radius: 14px;
    color: #ffc17e;
    background: linear-gradient(145deg,rgba(255,132,31,.21),rgba(255,132,31,.05));
    box-shadow: 0 0 16px rgba(255,132,31,.08);
    font-size: 24px;
    transition: transform .3s;
}

.feature-card:hover .feature-icon {
    transform: rotate(-8deg) scale(1.08);
}

.feature-card h3 {
    position: relative;
    margin-top: 13px;
    font-size: 14px;
    font-weight: 800;
    letter-spacing: -.4px;
}

.feature-card p {
    position: relative;
    margin-top: 7px;
    color: #b8b4b6;
    font-size: 11px;
    line-height: 1.8;
}

.feature-arrow {
    position: absolute;
    right: 17px;
    bottom: 13px;
    color: var(--orange);
    font-size: 21px;
    transition: transform .3s;
}

.feature-card:hover .feature-arrow {
    transform: translateX(5px);
}

/* ==================================================
   CALL TO ACTION
================================================== */

.cta-section {
    padding-bottom: 75px;
}

.cta-panel {
    position: relative;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 25px;
    padding: 35px 38px;
    overflow: hidden;
    border: 1px solid rgba(255,136,34,.35);
    border-radius: 22px;
    background:
        radial-gradient(ellipse at 90% 50%,rgba(255,116,22,.19),transparent 40%),
        linear-gradient(110deg,#121313,#0b0c0c);
}

.cta-panel::after {
    content: "";
    position: absolute;
    width: 180px;
    height: 180px;
    top: -125px;
    right: 20%;
    border: 1px solid rgba(255,132,31,.25);
    border-radius: 50%;
    box-shadow: 0 0 0 20px rgba(255,132,31,.025);
    animation: orbitSpin 15s linear infinite;
}

.cta-copy,
.cta-panel .btn {
    position: relative;
    z-index: 1;
}

.cta-copy h2 {
    font-size: clamp(24px,3vw,33px);
    line-height: 1.2;
    letter-spacing: -1px;
}

.cta-copy p {
    margin-top: 8px;
    color: var(--muted);
    font-size: 12px;
}

/* ==================================================
   FOOTER
================================================== */

.footer {
    border-top: 1px solid var(--border);
    background: rgba(0,0,0,.25);
}

.footer-inner {
    min-height: 88px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 20px;
}

.footer .brand-icon {
    width: 33px;
    height: 33px;
    border-radius: 10px;
    font-size: 20px;
}

.footer .brand-name {
    font-size: 18px;
}

.footer-note {
    color: #928d90;
    font-size: 10px;
}

.footer-links {
    display: flex;
    gap: 18px;
    color: #aaa5a8;
    font-size: 10px;
}

.footer-links a:hover {
    color: var(--orange);
}

/* ==================================================
   SCROLL REVEAL
================================================== */

.reveal {
    opacity: 0;
    transform: translateY(25px);
    transition: opacity .8s ease,transform .8s ease;
}

.reveal.visible {
    opacity: 1;
    transform: translateY(0);
}

.feature-card:nth-child(2) {
    transition-delay: .12s;
}

.feature-card:nth-child(3) {
    transition-delay: .24s;
}

/* ==================================================
   KEYFRAME ANIMATIONS
================================================== */

@keyframes glowDrift {
    0%   { transform: translate(-30px,-10px) scale(.9); }
    50%  { transform: translate(50px,25px) scale(1.1); }
    100% { transform: translate(-10px,55px) scale(1.2); }
}

@keyframes logoPulse {
    0%,100% { box-shadow: 0 0 20px rgba(255,127,31,.22); }
    50% { box-shadow: 0 0 38px rgba(255,127,31,.5); }
}

@keyframes dotBlink {
    0%,100% { opacity: 1; transform: scale(1); }
    50% { opacity: .4; transform: scale(.75); }
}

@keyframes textFlow {
    to { background-position: 250% center; }
}

@keyframes enterLeft {
    from { opacity: 0; transform: translateX(-35px); }
    to { opacity: 1; transform: translateX(0); }
}

@keyframes enterRight {
    from { opacity: 0; transform: translateX(35px); }
    to { opacity: 1; transform: translateX(0); }
}

@keyframes orbitSpin {
    from { rotate: 0deg; }
    to { rotate: 360deg; }
}

@keyframes innerRing {
    from { rotate: 0deg; }
    to { rotate: -360deg; }
}

@keyframes planetFloat {
    0%,100% { transform: translateY(0) rotate(0); }
    50% { transform: translateY(-17px) rotate(8deg); }
}

@keyframes artFloat {
    0%,100% { transform: translateY(0) rotate(0); }
    50% { transform: translateY(-10px) rotate(1deg); }
}

@keyframes symbolFloat {
    0%,100% { transform: rotate(-9deg) translateY(0); }
    50% { transform: rotate(-4deg) translateY(-10px); }
}

@keyframes badgeFloat {
    0%,100% { transform: translateY(0) rotate(0); }
    50% { transform: translateY(-13px) rotate(5deg); }
}

@keyframes auraBreath {
    0%,100% { transform: scale(.9); opacity: .55; }
    50% { transform: scale(1.18); opacity: 1; }
}

@keyframes borderRotate {
    from { rotate: 0deg; }
    to { rotate: 360deg; }
}

@keyframes pointPulse {
    0%,100% { opacity: .45; transform: scale(.8); }
    50% { opacity: 1; transform: scale(1.5); }
}

@keyframes tickerMove {
    from { transform: translateX(0); }
    to { transform: translateX(-50%); }
}

@keyframes lightSweep {
    0% { left: -65%; }
    100% { left: 110%; }
}

/* ==================================================
   RESPONSIVE
================================================== */

@media (min-width: 1500px) {
    .hero-grid {
        min-height: 555px;
    }

    .hero-visual {
        min-height: 490px;
    }
}

@media (max-width: 1100px) {
    .container {
        width: calc(100% - 55px);
    }

    .nav-links {
        gap: 20px;
    }

    .hero-grid {
        gap: 15px;
    }

    .hero h1 {
        font-size: clamp(42px,5vw,60px);
        letter-spacing: -3px;
    }

    .hero-visual {
        min-height: 420px;
    }

    .career-art {
        width: min(100%,350px);
    }

    .art-symbol {
        width: 125px;
        height: 125px;
        font-size: 70px;
    }

    .orbit {
        width: 390px;
        height: 240px;
    }

    .orbit-two {
        width: 440px;
        height: 290px;
    }

    .features-grid {
        grid-template-columns: 1fr;
        gap: 28px;
    }

    .features-intro p {
        max-width: 500px;
    }
}

@media (max-width: 760px) {
    .container {
        width: calc(100% - 36px);
    }

    .navbar {
        min-height: 68px;
        gap: 10px;
    }

    .brand {
        gap: 8px;
    }

    .brand-icon {
        width: 37px;
        height: 37px;
        font-size: 23px;
    }

    .brand-name {
        font-size: 20px;
    }

    .menu-toggle {
        display: grid;
        place-items: center;
        margin-left: auto;
    }

    .nav-links {
        position: absolute;
        top: 68px;
        left: 0;
        right: 0;
        display: none;
        flex-direction: column;
        align-items: stretch;
        gap: 0;
        padding: 10px 18px 18px;
        background: rgba(8,9,9,.98);
        border-bottom: 1px solid rgba(255,132,31,.25);
    }

    .nav-links.open {
        display: flex;
    }

    .nav-links a {
        padding: 13px 5px;
        border-bottom: 1px solid rgba(255,255,255,.06);
    }

    .nav-links a::after {
        display: none;
    }

    .nav-actions {
        gap: 6px;
    }

    .nav-actions .btn {
        min-height: 39px;
        padding: 0 10px;
        border-radius: 10px;
        font-size: 10px;
    }

    .nav-actions .btn-outline {
        display: none;
    }

    .hero-grid {
        grid-template-columns: 1fr;
        gap: 16px;
        padding-top: 40px;
        padding-bottom: 30px;
    }

    .hero h1 {
        font-size: clamp(43px,10vw,65px);
        letter-spacing: -2.8px;
    }

    .hero-description {
        font-size: 12px;
    }

    .hero-actions {
        gap: 10px;
    }

    .hero-actions .btn {
        min-height: 49px;
        padding: 0 16px;
        font-size: 11px;
    }

    .hero-points {
        gap: 12px 17px;
        margin-top: 21px;
    }

    .hero-visual {
        min-height: 410px;
        margin-top: 8px;
    }

    .career-art {
        width: min(78%,330px);
    }

    .art-symbol {
        width: 105px;
        height: 105px;
        border-radius: 29px;
        font-size: 60px;
    }

    .art-caption strong {
        font-size: 17px;
    }

    .art-caption p {
        font-size: 10px;
    }

    .orbit {
        width: 90%;
        height: 215px;
    }

    .orbit-two {
        width: 100%;
        height: 270px;
    }

    .orbit-three {
        width: 280px;
        height: 280px;
    }

    .planet {
        width: 65px;
        height: 65px;
        top: 1%;
    }

    .art-badge {
        width: 48px;
        height: 48px;
        border-radius: 15px;
        font-size: 23px;
    }

    .badge-search { top: 18%; left: 0; }
    .badge-star { top: 33%; right: 0; }
    .badge-check { bottom: 14%; right: 4%; }
    .badge-arrow { bottom: 18%; left: 0; }

    .ticker-group {
        gap: 20px;
        padding: 15px 10px;
    }

    .ticker-item {
        font-size: 9px;
    }

    .features {
        padding: 48px 0 58px;
    }

    .feature-cards {
        grid-template-columns: 1fr;
        gap: 12px;
    }

    .feature-card {
        min-height: 170px;
        padding: 19px;
    }

    .feature-card p {
        max-width: 420px;
        font-size: 12px;
    }

    .cta-section {
        padding-bottom: 50px;
    }

    .cta-panel {
        align-items: flex-start;
        flex-direction: column;
        padding: 26px 22px;
    }

    .cta-copy h2 {
        font-size: 27px;
    }

    .footer-inner {
        padding: 20px 0;
        flex-wrap: wrap;
    }

    .footer-note {
        order: 3;
        width: 100%;
    }
}

@media (max-width: 400px) {
    .container {
        width: calc(100% - 28px);
    }

    .brand-name {
        font-size: 17px;
    }

    .nav-actions .btn-primary {
        padding: 0 8px;
        font-size: 9px;
    }

    .hero h1 {
        font-size: 41px;
    }

    .hero-visual {
        min-height: 360px;
    }

    .career-art {
        width: 78%;
    }

    .art-symbol {
        width: 90px;
        height: 90px;
        font-size: 50px;
    }

    .art-caption strong {
        font-size: 15px;
    }

    .footer-links {
        gap: 12px;
    }
}

/* Accessibility */
@media (prefers-reduced-motion: reduce) {
    *,
    *::before,
    *::after {
        animation-duration: .01ms !important;
        animation-iteration-count: 1 !important;
        scroll-behavior: auto !important;
        transition-duration: .01ms !important;
    }

    .reveal {
        opacity: 1;
        transform: none;
    }
}
</style>
</head>

<body>

<!-- Animated background layers -->
<div class="background" aria-hidden="true">
    <div class="background-grid"></div>
    <div class="ambient-glow one"></div>
    <div class="ambient-glow two"></div>
    <div class="ambient-glow three"></div>
</div>

<canvas id="particles" aria-hidden="true"></canvas>

<!-- HEADER -->
<header class="header">
    <div class="container navbar">

        <a href="index.php" class="brand">
            <span class="brand-icon">✦</span>
            <span class="brand-name">Career<span>Bridge</span></span>
        </a>

        <button class="menu-toggle" id="menuToggle"
                aria-label="Toggle navigation" aria-expanded="false">
            ☰
        </button>

        <nav class="nav-links" id="navLinks">
            <a href="#home" class="active">Home</a>
            <a href="#features">Features</a>
            <a href="#about">About</a>
            <a href="#contact">Contact</a>
        </nav>

        <div class="nav-actions">
            <a href="login.php" class="btn btn-outline">Sign In</a>
            <a href="register.php" class="btn btn-primary">
                Create Account <span>↗</span>
            </a>
        </div>

    </div>
</header>

<main>

<!-- HERO -->
<section class="hero" id="home">
    <div class="hero-light-line"></div>

    <div class="container hero-grid">

        <div class="hero-copy">

            <div class="eyebrow">
                <span class="eyebrow-dot"></span>
                Your future is in motion
            </div>

            <h1>
                Think bigger.<br>
                <span class="gradient-text">Move forward.</span>
            </h1>

            <p class="hero-description">
                Discover internships that match your ambition, showcase your skills,
                and keep your applications organised. CareerBridge brings your next
                opportunity one step closer.
            </p>

            <div class="hero-actions">
                <a href="register.php" class="btn btn-primary">
                    Launch Your Journey <span>↗</span>
                </a>

                <a href="login.php" class="btn btn-outline">
                    Welcome Back <span>→</span>
                </a>
            </div>

            <div class="hero-points">
                <span><b>✦</b> Discover opportunities</span>
                <span><b>✓</b> Showcase your strengths</span>
                <span><b>↗</b> Follow your progress</span>
            </div>

        </div>

        <!-- NEW CAREER ARTWORK: no dashboard or floating text labels -->
        <div class="hero-visual" aria-label="Animated CareerBridge career illustration">

            <div class="visual-aura"></div>

            <div class="orbit"></div>
            <div class="orbit orbit-two"></div>
            <div class="orbit orbit-three"></div>

            <div class="planet"></div>
            <div class="planet-small"></div>

            <span class="light-point point-one"></span>
            <span class="light-point point-two"></span>
            <span class="light-point point-three"></span>
            <span class="light-point point-four"></span>

            <div class="career-art">

                <div class="art-inner-ring"></div>

                <div class="art-symbol">
                    <span>✦</span>
                </div>

                <div class="art-caption">
                    <strong>Career<span>Bridge</span></strong>
                    <p>Discover. Build. Become.</p>
                </div>

            </div>

            <!-- Floating icon tiles only -->
            <div class="art-badge badge-search" aria-label="Explore">
                ⌕
            </div>

            <div class="art-badge badge-star" aria-label="Skills">
                ★
            </div>

            <div class="art-badge badge-check" aria-label="Success">
                ✓
            </div>

            <div class="art-badge badge-arrow" aria-label="Growth">
                ↗
            </div>

        </div>

    </div>
</section>

<!-- MOVING BENEFITS STRIP -->
<section class="ticker" aria-label="CareerBridge benefits">
    <div class="ticker-track">

        <div class="ticker-group">
            <div class="ticker-item"><span>✦</span> Discover opportunities</div>
            <span class="separator">•</span>
            <div class="ticker-item"><span>✦</span> Build your profile</div>
            <span class="separator">•</span>
            <div class="ticker-item"><span>✦</span> Showcase your skills</div>
            <span class="separator">•</span>
            <div class="ticker-item"><span>✦</span> Track applications</div>
            <span class="separator">•</span>
            <div class="ticker-item"><span>✦</span> Take the next step</div>
            <span class="separator">•</span>
            <div class="ticker-item"><span>✦</span> Grow with confidence</div>
            <span class="separator">•</span>
        </div>

        <div class="ticker-group" aria-hidden="true">
            <div class="ticker-item"><span>✦</span> Discover opportunities</div>
            <span class="separator">•</span>
            <div class="ticker-item"><span>✦</span> Build your profile</div>
            <span class="separator">•</span>
            <div class="ticker-item"><span>✦</span> Showcase your skills</div>
            <span class="separator">•</span>
            <div class="ticker-item"><span>✦</span> Track applications</div>
            <span class="separator">•</span>
            <div class="ticker-item"><span>✦</span> Take the next step</div>
            <span class="separator">•</span>
            <div class="ticker-item"><span>✦</span> Grow with confidence</div>
            <span class="separator">•</span>
        </div>

    </div>
</section>

<!-- FEATURES -->
<section class="features" id="features">
    <div class="container features-grid">

        <div class="features-intro reveal" id="about">
            <span class="section-kicker">Made for your next move</span>

            <h2>
                Everything you need<br>
                to move <span>forward.</span>
            </h2>

            <p>
                Keep your internship journey clear, organised, and focused on
                the opportunities that matter to you.
            </p>
        </div>

        <div class="feature-cards">

            <a href="login.php" class="feature-card reveal">
                <div class="feature-icon">⌕</div>
                <h3>Discover opportunities</h3>
                <p>
                    Explore internships and find roles that match your interests,
                    skills, and career goals.
                </p>
                <span class="feature-arrow">→</span>
            </a>

            <a href="register.php" class="feature-card reveal">
                <div class="feature-icon">★</div>
                <h3>Show your strengths</h3>
                <p>
                    Present your profile, skills, resume, and project experience
                    in one convenient place.
                </p>
                <span class="feature-arrow">→</span>
            </a>

            <a href="login.php" class="feature-card reveal">
                <div class="feature-icon">☑</div>
                <h3>Stay in the loop</h3>
                <p>
                    Keep track of your applications and follow your progress
                    as you take the next step.
                </p>
                <span class="feature-arrow">→</span>
            </a>

        </div>
    </div>
</section>

<!-- CALL TO ACTION -->
<section class="cta-section" id="contact">
    <div class="container">
        <div class="cta-panel reveal">

            <div class="cta-copy">
                <h2>Your next chapter starts here.</h2>
                <p>Create your profile and take the first step towards your future.</p>
            </div>

            <a href="register.php" class="btn btn-primary">
                Get Started Now <span>↗</span>
            </a>

        </div>
    </div>
</section>

</main>

<!-- FOOTER -->
<footer class="footer">
    <div class="container footer-inner">

        <a href="index.php" class="brand">
            <span class="brand-icon">✦</span>
            <span class="brand-name">Career<span>Bridge</span></span>
        </a>

        <p class="footer-note">
            © <?php echo date('Y'); ?> CareerBridge. Built for your next move.
        </p>

        <div class="footer-links">
            <a href="#home">Home</a>
            <a href="#features">Features</a>
            <a href="login.php">Sign In</a>
            <a href="register.php">Register</a>
        </div>

    </div>
</footer>

<script>
/* ==================================================
   MOBILE NAVIGATION
================================================== */

const menuToggle = document.getElementById('menuToggle');
const navLinks = document.getElementById('navLinks');

menuToggle.addEventListener('click', () => {
    const open = navLinks.classList.toggle('open');

    menuToggle.setAttribute('aria-expanded', String(open));
    menuToggle.textContent = open ? '×' : '☰';
});

document.querySelectorAll('#navLinks a').forEach(link => {
    link.addEventListener('click', () => {
        navLinks.classList.remove('open');
        menuToggle.setAttribute('aria-expanded', 'false');
        menuToggle.textContent = '☰';
    });
});

/* ==================================================
   SCROLL REVEAL
================================================== */

const revealItems = document.querySelectorAll('.reveal');

if ('IntersectionObserver' in window) {
    const revealObserver = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('visible');
                observer.unobserve(entry.target);
            }
        });
    }, { threshold: 0.12 });

    revealItems.forEach(item => revealObserver.observe(item));
} else {
    revealItems.forEach(item => item.classList.add('visible'));
}

/* ==================================================
   PARTICLES AND CONNECTING LIGHT LINES
================================================== */

const canvas = document.getElementById('particles');
const ctx = canvas.getContext('2d');

const reducedMotion = window.matchMedia(
    '(prefers-reduced-motion: reduce)'
).matches;

let width = window.innerWidth;
let height = window.innerHeight;
let particles = [];
let animationFrame = null;
let lastFrameTime = 0;

function createParticles() {
    const count = Math.min(
        95,
        Math.max(35, Math.floor((width * height) / 14000))
    );

    particles = [];

    for (let i = 0; i < count; i++) {
        particles.push({
            x: Math.random() * width,
            y: Math.random() * height,
            radius: Math.random() * 1.8 + .6,
            dx: (Math.random() - .5) * .55,
            dy: (Math.random() - .5) * .45,
            alpha: Math.random() * .55 + .2,
            phase: Math.random() * Math.PI * 2
        });
    }
}

function resizeCanvas() {
    const dpr = Math.min(window.devicePixelRatio || 1, 2);

    width = window.innerWidth;
    height = window.innerHeight;

    canvas.width = Math.floor(width * dpr);
    canvas.height = Math.floor(height * dpr);
    canvas.style.width = width + 'px';
    canvas.style.height = height + 'px';

    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

    createParticles();
    drawParticles(performance.now(), false);
}

function drawParticles(time, move) {
    ctx.clearRect(0, 0, width, height);

    particles.forEach((particle, index) => {
        if (move) {
            particle.x += particle.dx;
            particle.y += particle.dy;

            if (particle.x < -5) particle.x = width + 5;
            if (particle.x > width + 5) particle.x = -5;
            if (particle.y < -5) particle.y = height + 5;
            if (particle.y > height + 5) particle.y = -5;
        }

        const pulse = .7 + .3 * Math.sin(time / 700 + particle.phase);
        const alpha = particle.alpha * pulse;

        // Glowing orange particle
        ctx.beginPath();
        ctx.arc(
            particle.x,
            particle.y,
            particle.radius,
            0,
            Math.PI * 2
        );

        ctx.fillStyle = `rgba(255,145,54,${alpha})`;
        ctx.shadowColor = 'rgba(255,111,17,.8)';
        ctx.shadowBlur = 9;
        ctx.fill();
        ctx.shadowBlur = 0;

        // Connect nearby particles with visible thin lines
        for (let j = index + 1; j < particles.length; j++) {
            const other = particles[j];
            const dx = particle.x - other.x;
            const dy = particle.y - other.y;
            const distance = Math.sqrt(dx * dx + dy * dy);
            const maxDistance = 135;

            if (distance < maxDistance) {
                const opacity = (1 - distance / maxDistance) * .22;

                ctx.beginPath();
                ctx.moveTo(particle.x, particle.y);
                ctx.lineTo(other.x, other.y);
                ctx.strokeStyle = `rgba(255,130,37,${opacity})`;
                ctx.lineWidth = .75;
                ctx.stroke();
            }
        }
    });
}

function animateParticles(time) {
    if (document.hidden || reducedMotion) {
        animationFrame = null;
        return;
    }

    // Limit animation to roughly 30 frames per second for efficiency.
    if (time - lastFrameTime >= 30) {
        drawParticles(time, true);
        lastFrameTime = time;
    }

    animationFrame = requestAnimationFrame(animateParticles);
}

function startParticleAnimation() {
    if (reducedMotion || document.hidden || animationFrame) return;
    animationFrame = requestAnimationFrame(animateParticles);
}

function stopParticleAnimation() {
    if (animationFrame !== null) {
        cancelAnimationFrame(animationFrame);
        animationFrame = null;
    }
}

resizeCanvas();
startParticleAnimation();

let resizeTimeout;

window.addEventListener('resize', () => {
    clearTimeout(resizeTimeout);

    resizeTimeout = setTimeout(() => {
        stopParticleAnimation();
        resizeCanvas();
        startParticleAnimation();
    }, 120);
});

document.addEventListener('visibilitychange', () => {
    if (document.hidden) {
        stopParticleAnimation();
    } else {
        startParticleAnimation();
    }
});
</script>

</body>
</html>
