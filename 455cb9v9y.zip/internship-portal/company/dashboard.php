
<?php
session_start();

require_once "../config/database.php";

/* =========================================
   1. AUTHENTICATION
========================================= */
if (
    !isset($_SESSION['user_id'], $_SESSION['role']) ||
    $_SESSION['role'] !== 'company'
) {
    header("Location: ../login.php");
    exit;
}

$userId = (int) $_SESSION['user_id'];

/* =========================================
   2. INITIALIZE VARIABLES
========================================= */
$user = [];
$company = [];
$internships = [];

$totalInternships = 0;
$totalApplicants = 0;
$pendingApplicants = 0;
$shortlistedApplicants = 0;

$errorMessage = '';

function h($value): string
{
    return htmlspecialchars(
        (string) $value,
        ENT_QUOTES,
        'UTF-8'
    );
}

/* =========================================
   3. DATABASE CONNECTION AND DATA
========================================= */
try {
    // Use the same database connection method as other portal pages.
    $pdo = getPDO();

    // Get logged-in user.
    $stmt = $pdo->prepare("
        SELECT id, name, email, role
        FROM users
        WHERE id = ?
        LIMIT 1
    ");

    $stmt->execute([$userId]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC) ?: [];

    if (!$user) {
        session_unset();
        session_destroy();

        header("Location: ../login.php");
        exit;
    }

    if ($user['role'] !== 'company') {
        header("Location: ../login.php");
        exit;
    }

    // Get company profile.
    $stmt = $pdo->prepare("
        SELECT *
        FROM companies
        WHERE user_id = ?
        LIMIT 1
    ");

    $stmt->execute([$userId]);
    $company = $stmt->fetch(PDO::FETCH_ASSOC) ?: [];

    /*
     * IMPORTANT:
     * internships.company_id refers to companies.id,
     * not users.id.
     */
    $companyId = (int) ($company['id'] ?? 0);

    if ($companyId > 0) {

        // Count internships belonging to this company.
        $stmt = $pdo->prepare("
            SELECT COUNT(*)
            FROM internships
            WHERE company_id = ?
        ");

        $stmt->execute([$companyId]);
        $totalInternships = (int) $stmt->fetchColumn();

        // Count all applications for this company's internships.
        $stmt = $pdo->prepare("
            SELECT COUNT(*)
            FROM applications a
            INNER JOIN internships i
                ON i.id = a.internship_id
            WHERE i.company_id = ?
        ");

        $stmt->execute([$companyId]);
        $totalApplicants = (int) $stmt->fetchColumn();

        // Count applications waiting for review.
        $stmt = $pdo->prepare("
            SELECT COUNT(*)
            FROM applications a
            INNER JOIN internships i
                ON i.id = a.internship_id
            WHERE i.company_id = ?
              AND LOWER(TRIM(a.status))
                  IN ('applied', 'pending', 'under review')
        ");

        $stmt->execute([$companyId]);
        $pendingApplicants = (int) $stmt->fetchColumn();

        // Count shortlisted applications.
        $stmt = $pdo->prepare("
            SELECT COUNT(*)
            FROM applications a
            INNER JOIN internships i
                ON i.id = a.internship_id
            WHERE i.company_id = ?
              AND LOWER(TRIM(a.status)) = 'shortlisted'
        ");

        $stmt->execute([$companyId]);
        $shortlistedApplicants = (int) $stmt->fetchColumn();

        // Get the six most recently posted internships.
        $stmt = $pdo->prepare("
            SELECT
                i.*,
                (
                    SELECT COUNT(*)
                    FROM applications a
                    WHERE a.internship_id = i.id
                ) AS applicant_count
            FROM internships i
            WHERE i.company_id = ?
            ORDER BY i.id DESC
            LIMIT 6
        ");

        $stmt->execute([$companyId]);
        $internships = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

} catch (Throwable $e) {
    // Keep technical details out of the public page.
    error_log("Company dashboard error: " . $e->getMessage());

    $errorMessage =
        "Dashboard information is temporarily unavailable. "
        . "Please check the database connection and table structure.";
}

/* =========================================
   4. DISPLAY VALUES
========================================= */
$companyName = trim(
    (string) (
        $company['company_name']
        ?? $user['name']
        ?? 'Company'
    )
);

if ($companyName === '') {
    $companyName = 'Company';
}

$firstName = explode(' ', $companyName)[0] ?: 'Company';

$avatarLetter = strtoupper(
    substr($firstName, 0, 1)
);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Company Dashboard | CareerBridge</title>

<style>
:root {
    --bg: #090909;
    --surface: #141414;
    --surface2: #1c1c1c;
    --orange: #ff7900;
    --orange2: #ffab55;
    --text: #f8f8f8;
    --muted: #a2a2a2;
    --border: rgba(255,255,255,.09);
    --green: #39d6a0;
    --blue: #70aaff;
    --purple: #bd91ff;
}

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

html {
    scroll-behavior: smooth;
}

body {
    min-height: 100vh;
    color: var(--text);
    font-family: Inter, "Segoe UI", Arial, sans-serif;
    background:
        radial-gradient(
            circle at 80% 0%,
            rgba(255,121,0,.09),
            transparent 32%
        ),
        var(--bg);
}

a {
    color: inherit;
    text-decoration: none;
}

.layout {
    min-height: 100vh;
}

.sidebar {
    position: fixed;
    inset: 0 auto 0 0;
    z-index: 100;
    width: 250px;
    padding: 28px 18px;
    background: #101010;
    border-right: 1px solid var(--border);
    display: flex;
    flex-direction: column;
    animation: slideIn .65s ease both;
}

.brand {
    display: flex;
    align-items: center;
    gap: 11px;
    margin: 0 0 40px 7px;
    font-size: 21px;
    font-weight: 800;
}

.brand-icon {
    width: 40px;
    height: 40px;
    display: grid;
    place-items: center;
    border-radius: 12px;
    color: #111;
    background: linear-gradient(
        135deg,
        var(--orange2),
        var(--orange)
    );
    box-shadow: 0 0 22px rgba(255,121,0,.24);
}

.brand-name span,
.page-title span {
    color: var(--orange);
}

.nav-label {
    padding: 0 12px;
    margin-bottom: 13px;
    color: #777;
    font-size: 10px;
    font-weight: 800;
    letter-spacing: 2px;
}

.nav-links {
    display: grid;
    gap: 8px;
}

.nav-link {
    display: flex;
    align-items: center;
    gap: 13px;
    padding: 13px 14px;
    color: #aaa;
    border: 1px solid transparent;
    border-radius: 12px;
    font-size: 13px;
    transition: .3s ease;
}

.nav-icon {
    width: 23px;
    text-align: center;
    font-size: 18px;
}

.nav-link:hover,
.nav-link.active {
    color: white;
    background: rgba(255,121,0,.12);
    border-color: rgba(255,121,0,.18);
    transform: translateX(4px);
}

.nav-link.active {
    box-shadow: inset 3px 0 var(--orange);
}

.sidebar-bottom {
    margin-top: auto;
}

.tip-card {
    padding: 17px;
    margin-bottom: 20px;
    border-radius: 15px;
    background: linear-gradient(140deg, #2a190c, #18130e);
    border: 1px solid rgba(255,121,0,.2);
}

.tip-card h3 {
    font-size: 13px;
    margin-bottom: 8px;
}

.tip-card p {
    color: var(--muted);
    font-size: 11px;
    line-height: 1.7;
}

.logout {
    display: block;
    padding: 12px;
    text-align: center;
    color: #ff8585;
    border: 1px solid rgba(255,100,100,.18);
    border-radius: 11px;
    font-size: 13px;
    transition: .25s;
}

.logout:hover {
    background: rgba(255,80,80,.1);
}

.main {
    width: calc(100% - 250px);
    margin-left: 250px;
    padding: 28px 35px 35px;
}

.topbar {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 20px;
    margin-bottom: 33px;
    animation: fadeDown .7s ease both;
}

.breadcrumb {
    color: var(--muted);
    font-size: 12px;
    margin-bottom: 8px;
}

.breadcrumb span {
    color: var(--orange);
}

.page-title {
    font-size: clamp(23px, 3vw, 31px);
    letter-spacing: -.8px;
}

.top-right {
    display: flex;
    align-items: center;
    gap: 13px;
}

.date-box {
    padding: 10px 13px;
    color: #bbb;
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: 10px;
    font-size: 12px;
}

.avatar {
    width: 43px;
    height: 43px;
    display: grid;
    place-items: center;
    border-radius: 14px;
    color: #111;
    font-weight: 800;
    background: linear-gradient(
        135deg,
        var(--orange2),
        var(--orange)
    );
}

.alert {
    padding: 14px 16px;
    margin-bottom: 20px;
    border-radius: 12px;
    font-size: 13px;
    line-height: 1.6;
    animation: fadeUp .4s ease both;
}

.alert-error {
    color: #ffaaaa;
    background: #301717;
    border: 1px solid #663030;
}

.alert-info {
    color: #ffd4a6;
    background: #2b1d10;
    border: 1px solid #70441d;
}

.welcome {
    position: relative;
    overflow: hidden;
    padding: 30px;
    margin-bottom: 29px;
    border: 1px solid rgba(255,121,0,.25);
    border-radius: 22px;
    background: linear-gradient(
        115deg,
        #28170a,
        #17120e 60%,
        #111
    );
    animation: fadeUp .7s .1s ease both;
}

.welcome::before {
    content: "";
    position: absolute;
    top: -100px;
    right: 10%;
    width: 230px;
    height: 230px;
    background: rgba(255,121,0,.17);
    filter: blur(65px);
    border-radius: 50%;
    animation: pulse 4s ease-in-out infinite;
}

.welcome-content {
    position: relative;
    z-index: 1;
}

.tag {
    display: inline-block;
    padding: 6px 10px;
    margin-bottom: 14px;
    color: var(--orange2);
    background: rgba(255,121,0,.12);
    border-radius: 6px;
    font-size: 10px;
    font-weight: 800;
    letter-spacing: 1.5px;
}

.welcome h2 {
    font-size: clamp(23px, 3vw, 31px);
    margin-bottom: 10px;
}

.welcome h2 span {
    color: var(--orange);
}

.welcome p {
    max-width: 600px;
    color: #aaa;
    font-size: 13px;
    line-height: 1.8;
    margin-bottom: 22px;
}

.primary-btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 10px;
    padding: 12px 17px;
    color: #111;
    background: linear-gradient(
        135deg,
        var(--orange2),
        var(--orange)
    );
    border-radius: 10px;
    font-size: 12px;
    font-weight: 800;
    transition: .3s ease;
}

.primary-btn:hover {
    transform: translateY(-3px);
    box-shadow: 0 8px 25px rgba(255,121,0,.27);
}

.section-heading {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 12px;
    margin-bottom: 17px;
}

.section-heading h2 {
    font-size: 17px;
}

.section-heading p {
    color: var(--muted);
    font-size: 11px;
    margin-top: 5px;
}

.section-heading > a {
    color: var(--orange2);
    font-size: 12px;
}

.stats-grid {
    display: grid;
    grid-template-columns: repeat(4, minmax(0, 1fr));
    gap: 16px;
    margin-bottom: 30px;
}

.stat-card {
    position: relative;
    overflow: hidden;
    padding: 20px;
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: 17px;
    animation: fadeUp .65s ease both;
    transition:
        transform .3s,
        border-color .3s,
        box-shadow .3s;
}

.stat-card:nth-child(1) { animation-delay: .12s; }
.stat-card:nth-child(2) { animation-delay: .20s; }
.stat-card:nth-child(3) { animation-delay: .28s; }
.stat-card:nth-child(4) { animation-delay: .36s; }

.stat-card::after {
    content: "";
    position: absolute;
    top: -35px;
    right: -35px;
    width: 100px;
    height: 100px;
    border-radius: 50%;
    background: var(--glow);
    filter: blur(30px);
    transition: .35s;
}

.stat-card:hover {
    transform: translateY(-7px);
    border-color: rgba(255,121,0,.45);
    box-shadow: 0 12px 32px rgba(0,0,0,.24);
}

.stat-card:hover::after {
    transform: scale(1.6);
}

.stat-top {
    position: relative;
    z-index: 1;
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 19px;
}

.stat-icon {
    width: 42px;
    height: 42px;
    display: grid;
    place-items: center;
    border-radius: 12px;
    color: var(--icon-color);
    background: var(--icon-bg);
    font-size: 19px;
}

.stat-tag {
    color: #999;
    font-size: 10px;
}

.stat-number {
    position: relative;
    z-index: 1;
    font-size: 31px;
    font-weight: 800;
    letter-spacing: -1px;
}

.stat-label {
    position: relative;
    z-index: 1;
    color: #aaa;
    font-size: 12px;
    margin-top: 7px;
}

.content-grid {
    display: grid;
    grid-template-columns: minmax(0, 1.5fr) minmax(260px, 1fr);
    gap: 22px;
    align-items: start;
}

.panel {
    min-width: 0;
    padding: 22px;
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: 18px;
    animation: fadeUp .8s .2s ease both;
}

.internship-list {
    display: grid;
    gap: 13px;
}

.internship-card {
    padding: 16px;
    background: #191919;
    border: 1px solid rgba(255,255,255,.06);
    border-radius: 13px;
    transition: .3s ease;
}

.internship-card:hover {
    transform: translateY(-4px);
    border-color: rgba(255,121,0,.35);
    background: #1e1a16;
}

.internship-card h3 {
    font-size: 14px;
    margin-bottom: 8px;
}

.meta {
    color: #999;
    font-size: 11px;
    line-height: 1.8;
}

.card-bottom {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 10px;
    margin-top: 13px;
}

.applicant-count {
    color: var(--green);
    font-size: 11px;
    font-weight: 700;
}

.card-actions {
    display: flex;
    align-items: center;
    gap: 12px;
}

.text-link {
    color: var(--orange2);
    font-size: 11px;
    font-weight: 700;
}

.text-link:hover {
    text-decoration: underline;
}

.quick-actions {
    display: grid;
    gap: 12px;
}

.action-link {
    display: flex;
    align-items: center;
    gap: 13px;
    padding: 15px;
    background: #191919;
    border: 1px solid rgba(255,255,255,.06);
    border-radius: 13px;
    transition: .3s ease;
}

.action-link:hover {
    transform: translateX(4px);
    border-color: rgba(255,121,0,.35);
}

.action-icon {
    flex-shrink: 0;
    width: 40px;
    height: 40px;
    display: grid;
    place-items: center;
    border-radius: 12px;
    color: var(--orange2);
    background: rgba(255,121,0,.12);
    font-size: 19px;
}

.action-link h3 {
    font-size: 12px;
    margin-bottom: 5px;
}

.action-link p {
    color: #999;
    font-size: 10px;
    line-height: 1.6;
}

.empty-state {
    padding: 27px 12px;
    text-align: center;
    color: var(--muted);
    font-size: 12px;
    line-height: 1.8;
}

.empty-icon {
    margin-bottom: 10px;
    font-size: 30px;
}

.empty-state .primary-btn {
    margin-top: 15px;
}

.footer {
    padding-top: 28px;
    text-align: center;
    color: #666;
    font-size: 11px;
}

.footer span {
    color: var(--orange);
}

@keyframes slideIn {
    from {
        opacity: 0;
        transform: translateX(-25px);
    }
    to {
        opacity: 1;
        transform: translateX(0);
    }
}

@keyframes fadeDown {
    from {
        opacity: 0;
        transform: translateY(-14px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

@keyframes fadeUp {
    from {
        opacity: 0;
        transform: translateY(20px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

@keyframes pulse {
    0%, 100% {
        opacity: .5;
        transform: scale(1);
    }
    50% {
        opacity: 1;
        transform: scale(1.15);
    }
}

@media (max-width: 1150px) {
    .stats-grid {
        grid-template-columns: repeat(2, minmax(0, 1fr));
    }

    .content-grid {
        grid-template-columns: 1fr;
    }

    .main {
        padding: 25px;
    }
}

@media (max-width: 760px) {
    .sidebar {
        width: 72px;
        padding: 20px 9px;
    }

    .brand {
        justify-content: center;
        margin: 0 0 30px;
    }

    .brand-name,
    .nav-label,
    .nav-text,
    .tip-card {
        display: none;
    }

    .nav-link {
        justify-content: center;
        padding: 13px 5px;
    }

    .main {
        width: calc(100% - 72px);
        margin-left: 72px;
        padding: 20px 15px;
    }

    .date-box {
        display: none;
    }

    .welcome {
        padding: 22px;
    }

    .panel {
        padding: 16px;
    }
}

@media (max-width: 420px) {
    .stats-grid {
        gap: 10px;
    }

    .stat-card {
        padding: 13px;
    }

    .stat-number {
        font-size: 25px;
    }

    .stat-label {
        font-size: 10px;
    }

    .stat-tag {
        display: none;
    }

    .card-bottom {
        align-items: flex-start;
        flex-direction: column;
    }
}

@media (prefers-reduced-motion: reduce) {
    *,
    *::before,
    *::after {
        animation-duration: .01ms !important;
        animation-iteration-count: 1 !important;
        transition-duration: .01ms !important;
        scroll-behavior: auto !important;
    }
}
</style>
</head>

<body>
<div class="layout">

    <aside class="sidebar">
        <a href="dashboard.php" class="brand">
            <span class="brand-icon">C</span>
            <span class="brand-name">
                Career<span>Bridge</span>
            </span>
        </a>

        <div class="nav-label">COMPANY MENU</div>

        <nav class="nav-links">
            <a href="dashboard.php" class="nav-link active">
                <span class="nav-icon">⌂</span>
                <span class="nav-text">Dashboard</span>
            </a>

            <a href="add_internship.php" class="nav-link">
                <span class="nav-icon">＋</span>
                <span class="nav-text">Add Internship</span>
            </a>

            <a href="internships.php" class="nav-link">
                <span class="nav-icon">▣</span>
                <span class="nav-text">My Internships</span>
            </a>

            <a href="applicants.php" class="nav-link">
                <span class="nav-icon">♙</span>
                <span class="nav-text">View Applicants</span>
            </a>
        </nav>

        <div class="sidebar-bottom">
            <div class="tip-card">
                <h3>Hiring tip</h3>
                <p>
                    Write clear internship descriptions and review
                    applications regularly to find suitable candidates.
                </p>
            </div>

            <a href="../logout.php" class="logout">
                ↪ &nbsp; Sign Out
            </a>
        </div>
    </aside>

    <main class="main">

        <header class="topbar">
            <div>
                <div class="breadcrumb">
                    Company Portal / <span>Dashboard</span>
                </div>

                <h1 class="page-title">
                    Company <span>Dashboard</span>
                </h1>
            </div>

            <div class="top-right">
                <div class="date-box" id="todayDate">
                    Welcome back!
                </div>

                <div class="avatar">
                    <?= h($avatarLetter) ?>
                </div>
            </div>
        </header>

        <?php if ($errorMessage !== ''): ?>
            <div class="alert alert-error">
                <?= h($errorMessage) ?>
            </div>
        <?php endif; ?>

        <?php if (!$errorMessage && empty($company)): ?>
            <div class="alert alert-info">
                Your company profile has not been created yet.
                Please complete your company registration before posting
                internships.
            </div>
        <?php endif; ?>

        <section class="welcome">
            <div class="welcome-content">
                <div class="tag">COMPANY WORKSPACE</div>

                <h2>
                    Welcome back,
                    <span><?= h($firstName) ?>!</span> 👋
                </h2>

                <p>
                    Manage your internship opportunities, discover
                    talented students, and track applications from
                    one place. Your next great intern could be waiting.
                </p>

                <a href="add_internship.php" class="primary-btn">
                    + Post an Internship
                </a>
            </div>
        </section>

        <div class="section-heading">
            <div>
                <h2>Hiring Overview</h2>
                <p>Review your internship and applicant statistics.</p>
            </div>
        </div>

        <section class="stats-grid">

            <article class="stat-card"
                style="--glow:rgba(255,121,0,.17);
                       --icon-bg:rgba(255,121,0,.12);
                       --icon-color:#ff9b42;">
                <div class="stat-top">
                    <div class="stat-icon">▣</div>
                    <span class="stat-tag">POSTED</span>
                </div>

                <div class="stat-number counter"
                     data-target="<?= $totalInternships ?>">0</div>

                <div class="stat-label">My Internships</div>
            </article>

            <article class="stat-card"
                style="--glow:rgba(104,169,255,.17);
                       --icon-bg:rgba(104,169,255,.12);
                       --icon-color:#70aaff;">
                <div class="stat-top">
                    <div class="stat-icon">♙</div>
                    <span class="stat-tag">RECEIVED</span>
                </div>

                <div class="stat-number counter"
                     data-target="<?= $totalApplicants ?>">0</div>

                <div class="stat-label">Total Applicants</div>
            </article>

            <article class="stat-card"
                style="--glow:rgba(189,145,255,.17);
                       --icon-bg:rgba(189,145,255,.12);
                       --icon-color:#bd91ff;">
                <div class="stat-top">
                    <div class="stat-icon">◷</div>
                    <span class="stat-tag">TO REVIEW</span>
                </div>

                <div class="stat-number counter"
                     data-target="<?= $pendingApplicants ?>">0</div>

                <div class="stat-label">Pending Applications</div>
            </article>

            <article class="stat-card"
                style="--glow:rgba(57,214,160,.17);
                       --icon-bg:rgba(57,214,160,.12);
                       --icon-color:#39d6a0;">
                <div class="stat-top">
                    <div class="stat-icon">✓</div>
                    <span class="stat-tag">SHORTLISTED</span>
                </div>

                <div class="stat-number counter"
                     data-target="<?= $shortlistedApplicants ?>">0</div>

                <div class="stat-label">Shortlisted Applicants</div>
            </article>

        </section>

        <section class="content-grid">

            <div class="panel">
                <div class="section-heading">
                    <div>
                        <h2>Recent Internships</h2>
                        <p>Manage your latest internship listings.</p>
                    </div>

                    <a href="internships.php">View all →</a>
                </div>

                <div class="internship-list">

                    <?php if (empty($internships)): ?>

                        <div class="empty-state">
                            <div class="empty-icon">💼</div>

                            <strong>No internships posted yet</strong>

                            <p>
                                Create your first listing to start
                                receiving applications.
                            </p>

                            <a href="add_internship.php" class="primary-btn">
                                + Add Internship
                            </a>
                        </div>

                    <?php else: ?>

                        <?php foreach ($internships as $internship): ?>

                            <article class="internship-card">
                                <h3>
                                    <?= h(
                                        $internship['title']
                                        ?? 'Internship'
                                    ) ?>
                                </h3>

                                <div class="meta">
                                    Location:
                                    <?= h(
                                        $internship['location']
                                        ?? 'Not specified'
                                    ) ?>
                                </div>

                                <div class="card-bottom">
                                    <span class="applicant-count">
                                        <?= (int) (
                                            $internship['applicant_count']
                                            ?? 0
                                        ) ?>
                                        applicants
                                    </span>

                                    <div class="card-actions">
                                        <a
                                            class="text-link"
                                            href="applicants.php?internship_id=<?= (int)$internship['id'] ?>"
                                        >
                                            Applicants →
                                        </a>

                                        <a
                                            class="text-link"
                                            href="internships.php"
                                        >
                                            Manage
                                        </a>
                                    </div>
                                </div>
                            </article>

                        <?php endforeach; ?>

                    <?php endif; ?>

                </div>
            </div>

            <div class="panel">
                <div class="section-heading">
                    <div>
                        <h2>Quick Actions</h2>
                        <p>Manage your hiring process.</p>
                    </div>
                </div>

                <div class="quick-actions">

                    <a href="add_internship.php" class="action-link">
                        <div class="action-icon">＋</div>
                        <div>
                            <h3>Post an Internship</h3>
                            <p>Create a new internship opportunity.</p>
                        </div>
                    </a>

                    <a href="internships.php" class="action-link">
                        <div class="action-icon">▣</div>
                        <div>
                            <h3>Manage Internships</h3>
                            <p>Review and manage your listings.</p>
                        </div>
                    </a>

                    <a href="applicants.php" class="action-link">
                        <div class="action-icon">♙</div>
                        <div>
                            <h3>Review Applicants</h3>
                            <p>Review candidates and update their status.</p>
                        </div>
                    </a>

                </div>
            </div>

        </section>

        <footer class="footer">
            © <?= date('Y') ?>
            <span>CareerBridge</span>.
            Connecting talent with opportunity.
        </footer>

    </main>
</div>

<script>
/* Display today's date */
const dateElement = document.getElementById('todayDate');

if (dateElement) {
    dateElement.textContent = new Date().toLocaleDateString(
        'en-IN',
        {
            day: '2-digit',
            month: 'short',
            year: 'numeric'
        }
    );
}

/* Animate statistic counters */
document.querySelectorAll('.counter').forEach(counter => {
    const target = Math.max(
        0,
        Number(counter.dataset.target || 0)
    );

    const duration = 1000;
    const startTime = performance.now();

    function animateCounter(currentTime) {
        const elapsed = currentTime - startTime;
        const progress = Math.min(elapsed / duration, 1);
        const eased = 1 - Math.pow(1 - progress, 3);

        counter.textContent = Math.round(target * eased);

        if (progress < 1) {
            requestAnimationFrame(animateCounter);
        } else {
            counter.textContent = target;
        }
    }

    requestAnimationFrame(animateCounter);
});
</script>
</body>
</html>
