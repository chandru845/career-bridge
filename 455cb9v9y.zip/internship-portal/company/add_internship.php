
<?php
declare(stricttypes=1);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/../config/database.php';

/* DATABASE CONNECTION */
$pdo = $pdo ?? null;

if (!($pdo instanceof PDO)) {
    if (function_exists('getPDO')) {
        $pdo = getPDO();
    } elseif (isset($conn) && $conn instanceof PDO) {
        $pdo = $conn;
    } elseif (isset($db) && $db instanceof PDO) {
        $pdo = $db;
    }
}

if (!($pdo instanceof PDO)) {
    http_response_code(500);
    exit('Database connection error. Check config/database.php.');
}

$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);

function e($value): string
{
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

/* LOGIN CHECK */
if (
    empty($_SESSION['user_id']) ||
    ($_SESSION['role'] ?? '') !== 'company'
) {
    header('Location: ../login.php');
    exit;
}

$userId = (int)$_SESSION['user_id'];

/* CSRF TOKEN */
if (empty($_SESSION['add_internship_csrf'])) {
    $_SESSION['add_internship_csrf'] = bin2hex(random_bytes(32));
}

$csrfToken = $_SESSION['add_internship_csrf'];

/* COMPANY PROFILE */
try {
    $stmt = $pdo->prepare(
        'SELECT id, company_name
         FROM companies
         WHERE user_id = ?
         LIMIT 1'
    );
    $stmt->execute([$userId]);
    $company = $stmt->fetch();

    if (!$company) {
        $stmt = $pdo->prepare(
            'SELECT name FROM users WHERE id = ? LIMIT 1'
        );
        $stmt->execute([$userId]);
        $user = $stmt->fetch();

        if (!$user) {
            exit('User account was not found.');
        }

        $companyName = trim((string)($user['name'] ?? ''))
            ?: 'My Company';

        $stmt = $pdo->prepare(
            'INSERT INTO companies (user_id, company_name)
             VALUES (?, ?)'
        );
        $stmt->execute([$userId, $companyName]);

        $company = [
            'id' => (int)$pdo->lastInsertId(),
            'company_name' => $companyName
        ];
    }

    $companyId = (int)$company['id'];
    $companyName = (string)$company['company_name'];

} catch (PDOException $exception) {
    error_log('Company profile error: ' . $exception->getMessage());
    http_response_code(500);
    exit('Unable to load your company profile. Check your database tables.');
}

/* FORM DEFAULTS */
$form = [
    'title' => '',
    'description' => '',
    'skills_required' => '',
    'location' => '',
    'duration' => '',
    'stipend' => '',
    'deadline' => ''
];

$errors = [];

/* PROCESS FORM */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    foreach ($form as $key => $value) {
        $form[$key] = trim((string)($_POST[$key] ?? ''));
    }

    $submittedToken = (string)($_POST['csrf_token'] ?? '');

    if (!hash_equals($csrfToken, $submittedToken)) {
        $errors[] = 'Your session token is invalid. Refresh and try again.';
    }

    if ($form['title'] === '') {
        $errors[] = 'Please enter the internship title.';
    } elseif (strlen($form['title']) > 150) {
        $errors[] = 'The title must not exceed 150 characters.';
    }

    if ($form['description'] === '') {
        $errors[] = 'Please enter the internship description.';
    }

    if ($form['skills_required'] === '') {
        $errors[] = 'Please enter the required skills.';
    }

    if ($form['location'] === '') {
        $errors[] = 'Please enter the internship location.';
    } elseif (strlen($form['location']) > 150) {
        $errors[] = 'The location must not exceed 150 characters.';
    }

    if ($form['duration'] === '') {
        $errors[] = 'Please enter the internship duration.';
    } elseif (strlen($form['duration']) > 100) {
        $errors[] = 'The duration must not exceed 100 characters.';
    }

    if ($form['stipend'] === '') {
        $errors[] = 'Please enter the stipend. Use 0 for unpaid internships.';
    } elseif (
        !is_numeric($form['stipend']) ||
        !is_finite((float)$form['stipend']) ||
        (float)$form['stipend'] < 0
    ) {
        $errors[] = 'Enter a valid stipend greater than or equal to zero.';
    }

    if ($form['deadline'] === '') {
        $errors[] = 'Please select the application deadline.';
    } else {
        $deadlineDate = DateTime::createFromFormat(
            '!Y-m-d',
            $form['deadline']
        );

        $dateErrors = DateTime::getLastErrors();

        if (
            !$deadlineDate ||
            (
                $dateErrors !== false &&
                (
                    $dateErrors['warning_count'] > 0 ||
                    $dateErrors['error_count'] > 0
                )
            ) ||
            $deadlineDate->format('Y-m-d') !== $form['deadline']
        ) {
            $errors[] = 'Please enter a valid application deadline.';
        } elseif ($form['deadline'] < date('Y-m-d')) {
            $errors[] = 'The deadline cannot be in the past.';
        }
    }

    /* INSERT INTERNSHIP */
    if (!$errors) {
        try {
            $stmt = $pdo->prepare(
                'INSERT INTO internships
                (
                    company_id, title, description, skills_required,
                    location, duration, stipend, deadline
                )
                VALUES
                (
                    :company_id, :title, :description, :skills_required,
                    :location, :duration, :stipend, :deadline
                )'
            );

            $stmt->execute([
                ':company_id' => $companyId,
                ':title' => $form['title'],
                ':description' => $form['description'],
                ':skills_required' => $form['skills_required'],
                ':location' => $form['location'],
                ':duration' => $form['duration'],
                ':stipend' => (float)$form['stipend'],
                ':deadline' => $form['deadline']
            ]);

            $_SESSION['add_internship_csrf'] = bin2hex(random_bytes(32));

            header('Location: internships.php?added=1');
            exit;

        } catch (PDOException $exception) {
            error_log('Internship insert error: ' . $exception->getMessage());
            $errors[] = 'Unable to publish the internship. Check your database schema and try again.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="theme-color" content="#080808">
<title>Add Internship | CareerBridge</title>

<style>
:root {
    --bg: #080808;
    --panel: #111;
    --orange: #ff6500;
    --orange-light: #ff9b38;
    --text: #fff;
    --muted: #a4a4a4;
    --border: rgba(255,101,0,.23);
    --sidebar-width: 265px;
}

* {
    box-sizing: border-box;
    margin: 0;
    padding: 0;
}

html {
    min-height: 100%;
    scroll-behavior: smooth;
    scrollbar-color: var(--orange) #101010;
}

body {
    min-height: 100vh;
    overflow-x: clip;
    background: var(--bg);
    color: var(--text);
    font-family: Inter, "Segoe UI", Arial, sans-serif;
}

body::before {
    content: "";
    position: fixed;
    inset: 0;
    z-index: -3;
    pointer-events: none;
    background:
        radial-gradient(ellipse at 75% 10%, rgba(255,101,0,.12), transparent 38%),
        radial-gradient(ellipse at 15% 80%, rgba(255,101,0,.07), transparent 35%),
        #080808;
}

a {
    color: inherit;
    text-decoration: none;
}

button, input, textarea {
    font: inherit;
}

/* ANIMATED BACKGROUND */

.ambient {
    position: fixed;
    z-index: -2;
    width: 300px;
    height: 300px;
    border-radius: 50%;
    filter: blur(100px);
    opacity: .2;
    pointer-events: none;
    animation: ambientFloat 11s ease-in-out infinite alternate;
}

.ambient-one {
    top: 5%;
    left: 25%;
    background: #ff6500;
}

.ambient-two {
    right: -100px;
    bottom: -100px;
    background: #a83200;
    animation-delay: -4s;
}

.ambient-three {
    top: 60%;
    left: 48%;
    width: 180px;
    height: 180px;
    background: #ff9b00;
    opacity: .1;
    animation-delay: -7s;
}

@keyframes ambientFloat {
    0% { transform: translate(-25px,20px) scale(.8); }
    50% { transform: translate(45px,-35px) scale(1.15); }
    100% { transform: translate(-10px,30px) scale(.95); }
}

/* DESKTOP SIDEBAR: ALWAYS LEFT */

.sidebar {
    position: fixed;
    top: 0;
    bottom: 0;
    left: 0;
    z-index: 1000;
    display: flex;
    flex-direction: column;
    width: var(--sidebar-width);
    height: 100vh;
    height: 100dvh;
    padding: 27px 18px;
    overflow-y: auto;
    background: rgba(12,12,12,.96);
    border-right: 1px solid var(--border);
    box-shadow: 15px 0 55px rgba(0,0,0,.28);
    backdrop-filter: blur(24px);
    -webkit-backdrop-filter: blur(24px);
    transition: transform .4s cubic-bezier(.2,.8,.2,1);
}

.brand {
    display: flex;
    align-items: center;
    gap: 11px;
    padding: 3px 8px 32px;
    font-size: 23px;
    font-weight: 950;
    letter-spacing: -1px;
}

.brand-mark {
    display: grid;
    place-items: center;
    flex-shrink: 0;
    width: 40px;
    height: 40px;
    border-radius: 13px;
    background: linear-gradient(135deg,#ffb347,var(--orange));
    color: #080808;
    box-shadow: 0 0 25px rgba(255,101,0,.32);
    animation: logoPulse 3s ease-in-out infinite;
}

.brand-name span,
.mobile-brand span {
    color: var(--orange);
}

@keyframes logoPulse {
    0%,100% { box-shadow: 0 0 12px rgba(255,101,0,.2); }
    50% { box-shadow: 0 0 35px rgba(255,101,0,.6); }
}

.sidebar-caption {
    margin: 7px 12px 13px;
    color: #777;
    font-size: 10px;
    font-weight: 850;
    letter-spacing: 2px;
    text-transform: uppercase;
}

.nav-links {
    display: grid;
    gap: 8px;
}

.nav-link {
    position: relative;
    display: flex;
    align-items: center;
    gap: 13px;
    min-height: 49px;
    padding: 12px 13px;
    overflow: hidden;
    border: 1px solid transparent;
    border-radius: 12px;
    color: #bdbdbd;
    font-size: 13px;
    font-weight: 650;
    transition: .25s ease;
}

.nav-link:hover {
    transform: translateX(5px);
    color: #fff;
    border-color: rgba(255,101,0,.2);
    background: rgba(255,101,0,.08);
}

.nav-icon {
    display: grid;
    place-items: center;
    width: 24px;
    flex-shrink: 0;
    color: #999;
    font-size: 19px;
    transition: .25s ease;
}

.nav-link:hover .nav-icon {
    color: var(--orange-light);
    transform: scale(1.15);
}

.nav-link.active {
    color: #fff;
    border-color: rgba(255,101,0,.32);
    background: linear-gradient(100deg,rgba(255,101,0,.2),rgba(255,101,0,.035));
    box-shadow: inset 3px 0 var(--orange), 0 5px 25px rgba(255,101,0,.06);
}

.nav-link.active .nav-icon {
    color: var(--orange-light);
}

.sidebar-bottom {
    margin-top: auto;
    padding-top: 30px;
}

.company-card {
    padding: 16px;
    border: 1px solid var(--border);
    border-radius: 15px;
    background: linear-gradient(145deg,rgba(255,101,0,.11),rgba(255,255,255,.015));
}

.company-card small {
    display: block;
    margin-bottom: 9px;
    color: #999;
    font-size: 10px;
    letter-spacing: 1px;
    text-transform: uppercase;
}

.company-card strong {
    display: block;
    overflow-wrap: anywhere;
    font-size: 13px;
}

.status-dot {
    display: inline-block;
    width: 7px;
    height: 7px;
    margin-right: 6px;
    border-radius: 50%;
    background: var(--orange);
    box-shadow: 0 0 12px var(--orange);
    animation: dotPulse 2s infinite;
}

@keyframes dotPulse {
    0%,100% { opacity: 1; }
    50% { opacity: .45; }
}

.sidebar-footer {
    margin-top: 17px;
    color: #686868;
    text-align: center;
    font-size: 9px;
    letter-spacing: .5px;
}

/* MOBILE HEADER */

.mobile-bar {
    display: none;
}

.overlay {
    position: fixed;
    inset: 0;
    z-index: 900;
    visibility: hidden;
    opacity: 0;
    background: rgba(0,0,0,.75);
    backdrop-filter: blur(5px);
    -webkit-backdrop-filter: blur(5px);
    transition: opacity .3s, visibility .3s;
}

.overlay.show {
    visibility: visible;
    opacity: 1;
}

/* MAIN CONTENT */

.main {
    min-height: 100vh;
    margin-left: var(--sidebar-width);
    padding: 36px clamp(22px,5vw,75px) 28px;
}

.topline {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 15px;
    margin-bottom: 39px;
    animation: fadeDown .7s both;
}

.breadcrumb {
    color: #858585;
    font-size: 12px;
}

.breadcrumb span {
    color: var(--orange-light);
}

.top-badge {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 9px 13px;
    border: 1px solid var(--border);
    border-radius: 30px;
    background: rgba(255,101,0,.07);
    color: #ffb17c;
    font-size: 11px;
    font-weight: 750;
    white-space: nowrap;
}

.top-badge::before {
    content: "";
    width: 7px;
    height: 7px;
    border-radius: 50%;
    background: var(--orange);
    box-shadow: 0 0 12px var(--orange);
}

/* HERO */

.page-heading {
    max-width: 850px;
    margin: 0 auto 31px;
    animation: heroReveal .9s cubic-bezier(.16,1,.3,1) both;
}

.eyebrow {
    display: inline-flex;
    align-items: center;
    gap: 9px;
    margin-bottom: 17px;
    padding: 9px 13px;
    border: 1px solid rgba(255,101,0,.3);
    border-radius: 30px;
    background: rgba(255,101,0,.07);
    color: #ff9b58;
    font-size: 10px;
    font-weight: 900;
    letter-spacing: 1.7px;
    text-transform: uppercase;
}

.eyebrow::before {
    content: "✦";
    color: var(--orange);
    font-size: 15px;
}

h1 {
    margin-bottom: 15px;
    font-size: clamp(36px,5vw,62px);
    font-weight: 950;
    letter-spacing: -2.6px;
    line-height: 1.08;
}

h1 span {
    display: inline-block;
    color: var(--orange);
    text-shadow: 0 0 28px rgba(255,101,0,.26);
    animation: titleGlow 4s ease-in-out infinite;
}

@keyframes titleGlow {
    0%,100% { text-shadow: 0 0 12px rgba(255,101,0,.15); }
    50% { text-shadow: 0 0 42px rgba(255,101,0,.55); }
}

.subtitle {
    max-width: 630px;
    color: var(--muted);
    font-size: 14px;
    line-height: 1.9;
}

.company-label {
    margin-top: 15px;
    color: #aaa;
    font-size: 12px;
}

.company-label strong {
    color: var(--orange-light);
}

/* FORM CARD */

.card-wrap {
    max-width: 850px;
    margin: 0 auto;
    perspective: 1200px;
    animation: cardReveal 1s .1s cubic-bezier(.16,1,.3,1) both;
}

.card {
    position: relative;
    isolation: isolate;
    overflow: hidden;
    padding: clamp(23px,4vw,42px);
    border: 1px solid rgba(255,101,0,.24);
    border-radius: 24px;
    background: linear-gradient(145deg,rgba(24,24,24,.97),rgba(10,10,10,.98));
    box-shadow: 0 25px 90px rgba(0,0,0,.42),0 0 45px rgba(255,101,0,.035);
    transition: border-color .4s, box-shadow .4s;
}

.card::before {
    content: "";
    position: absolute;
    top: 0;
    left: -80%;
    z-index: -1;
    width: 55%;
    height: 2px;
    background: linear-gradient(90deg,transparent,var(--orange),transparent);
    animation: borderSweep 5s ease-in-out infinite;
}

.card::after {
    content: "";
    position: absolute;
    top: -120px;
    right: -100px;
    z-index: -1;
    width: 240px;
    height: 240px;
    border-radius: 50%;
    background: rgba(255,101,0,.045);
    filter: blur(30px);
    pointer-events: none;
}

@keyframes borderSweep {
    0%,20% { left: -80%; }
    70%,100% { left: 140%; }
}

.card:hover {
    border-color: rgba(255,101,0,.4);
    box-shadow: 0 30px 100px rgba(0,0,0,.5),0 0 55px rgba(255,101,0,.07);
}

.section-title {
    margin-bottom: 8px;
    font-size: 22px;
    font-weight: 850;
}

.section-description {
    margin-bottom: 29px;
    color: #999;
    font-size: 12px;
    line-height: 1.8;
}

.required {
    color: var(--orange-light);
}

.form-grid {
    display: grid;
    grid-template-columns: repeat(2,minmax(0,1fr));
    gap: 23px 20px;
}

.field {
    min-width: 0;
    animation: fieldReveal .7s cubic-bezier(.16,1,.3,1) both;
}

.field:nth-child(1) { animation-delay: .10s; }
.field:nth-child(2) { animation-delay: .16s; }
.field:nth-child(3) { animation-delay: .22s; }
.field:nth-child(4) { animation-delay: .28s; }
.field:nth-child(5) { animation-delay: .34s; }
.field:nth-child(6) { animation-delay: .40s; }
.field:nth-child(7) { animation-delay: .46s; }

.field.full-width {
    grid-column: 1 / -1;
}

label {
    display: block;
    margin-bottom: 10px;
    color: #ededed;
    font-size: 12px;
    font-weight: 750;
}

input, textarea {
    display: block;
    width: 100%;
    max-width: 100%;
    border: 1px solid #333;
    border-radius: 11px;
    outline: none;
    background: #0b0b0b;
    color: #fff;
    font-size: 13px;
    transition: border-color .3s,box-shadow .3s,background .3s,transform .3s;
}

input {
    min-height: 49px;
    padding: 13px 14px;
}

textarea {
    min-height: 135px;
    padding: 14px;
    resize: vertical;
    line-height: 1.8;
}

input::placeholder, textarea::placeholder {
    color: #666;
}

input:focus, textarea:focus {
    border-color: var(--orange);
    background: #111;
    box-shadow: 0 0 0 3px rgba(255,101,0,.1),0 0 25px rgba(255,101,0,.09);
    transform: translateY(-2px);
}

input[type="date"] {
    color-scheme: dark;
}

.help-text {
    display: block;
    margin-top: 8px;
    color: #818181;
    font-size: 10px;
    line-height: 1.7;
}

/* ERRORS */

.alert {
    margin-bottom: 24px;
    padding: 16px 18px;
    border: 1px solid rgba(255,100,100,.35);
    border-radius: 12px;
    background: rgba(255,65,65,.07);
    color: #ffb5b5;
    font-size: 12px;
    line-height: 1.9;
    animation: errorReveal .5s ease both;
}

.alert ul {
    padding-left: 20px;
    margin-top: 7px;
}

@keyframes errorReveal {
    from { opacity: 0; transform: translateY(-10px); }
    to { opacity: 1; transform: translateY(0); }
}

/* BUTTONS */

.form-actions {
    display: flex;
    align-items: center;
    justify-content: space-between;
    flex-wrap: wrap;
    gap: 14px;
    margin-top: 32px;
    padding-top: 25px;
    border-top: 1px solid #292929;
}

.primary {
    position: relative;
    isolation: isolate;
    overflow: hidden;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 13px;
    min-height: 50px;
    padding: 14px 24px;
    border: 1px solid rgba(255,255,255,.12);
    border-radius: 11px;
    background: linear-gradient(110deg,#ff6500,#ff9b38);
    color: #090909;
    font-size: 12px;
    font-weight: 950;
    cursor: pointer;
    box-shadow: 0 8px 28px rgba(255,101,0,.23);
    transition: transform .3s,box-shadow .3s,filter .3s;
}

.primary::before {
    content: "";
    position: absolute;
    inset: 0;
    z-index: -1;
    background: linear-gradient(110deg,transparent 20%,rgba(255,255,255,.5),transparent 80%);
    transform: translateX(-130%);
    transition: transform .7s;
}

.primary:hover::before {
    transform: translateX(130%);
}

.primary:hover {
    transform: translateY(-4px) scale(1.025);
    box-shadow: 0 14px 38px rgba(255,101,0,.4);
    filter: saturate(1.15);
}

.primary:active {
    transform: scale(.98);
}

.primary:disabled {
    opacity: .65;
    cursor: wait;
    transform: none;
}

.primary span {
    position: relative;
}

.arrow {
    display: inline-block;
    transition: transform .3s;
}

.primary:hover .arrow {
    transform: translateX(5px);
}

.secondary {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    min-height: 46px;
    padding: 12px 18px;
    border: 1px solid #363636;
    border-radius: 10px;
    color: #ddd;
    font-size: 12px;
    transition: border-color .3s,color .3s,background .3s,transform .3s;
}

.secondary:hover {
    transform: translateY(-2px);
    border-color: var(--orange);
    background: rgba(255,101,0,.07);
    color: var(--orange-light);
}

.security-note {
    margin-top: 21px;
    color: #777;
    text-align: center;
    font-size: 10px;
    line-height: 1.9;
}

.footer {
    max-width: 850px;
    margin: 27px auto 0;
    padding: 15px 0;
    color: #777;
    text-align: center;
    font-size: 10px;
}

.footer span {
    color: var(--orange-light);
    font-weight: 800;
}

@keyframes fadeDown {
    from { opacity: 0; transform: translateY(-22px); }
    to { opacity: 1; transform: translateY(0); }
}

@keyframes heroReveal {
    0% { opacity: 0; transform: translateY(35px) scale(.97); filter: blur(8px); }
    100% { opacity: 1; transform: translateY(0) scale(1); filter: blur(0); }
}

@keyframes cardReveal {
    0% { opacity: 0; transform: translateY(40px) rotateX(5deg) scale(.97); filter: blur(6px); }
    100% { opacity: 1; transform: translateY(0) rotateX(0) scale(1); filter: blur(0); }
}

@keyframes fieldReveal {
    from { opacity: 0; transform: translateY(18px); }
    to { opacity: 1; transform: translateY(0); }
}

/* TABLETS AND SMALL LAPTOPS */

@media (max-width: 1000px) and (min-width: 761px) {
    :root {
        --sidebar-width: 225px;
    }

    .sidebar {
        padding-right: 13px;
        padding-left: 13px;
    }

    .main {
        padding-right: 24px;
        padding-left: 24px;
    }

    h1 {
        font-size: clamp(36px,5vw,52px);
    }
}

/*
   IMPORTANT MOBILE FIX:
   The header and menu button are visible on the left.
   The sidebar is a drawer that enters from the LEFT.
   The main page uses the full phone width.
*/

@media (max-width: 760px) {
    .mobile-bar {
        position: sticky;
        top: 0;
        z-index: 850;
        display: flex;
        align-items: center;
        justify-content: flex-start;
        gap: 15px;
        min-height: 66px;
        padding: 10px 16px;
        border-bottom: 1px solid var(--border);
        background: rgba(8,8,8,.96);
        backdrop-filter: blur(18px);
        -webkit-backdrop-filter: blur(18px);
    }

    /* Menu is deliberately placed on the LEFT */
    .menu-button {
        order: 0;
        display: grid;
        place-items: center;
        flex: 0 0 44px;
        width: 44px;
        height: 44px;
        border: 1px solid rgba(255,101,0,.42);
        border-radius: 12px;
        background: rgba(255,101,0,.12);
        color: var(--orange-light);
        font-size: 25px;
        cursor: pointer;
        transition: transform .25s,background .25s,box-shadow .25s;
    }

    .menu-button:hover {
        transform: scale(1.05);
        background: rgba(255,101,0,.2);
        box-shadow: 0 0 22px rgba(255,101,0,.2);
    }

    .mobile-brand {
        order: 1;
        display: inline-block;
        font-size: 20px;
        font-weight: 950;
        letter-spacing: -.7px;
    }

    /*
       Override the desktop sidebar position for phones.
       It is hidden off the LEFT, not the RIGHT.
    */
    .sidebar {
        position: fixed;
        top: 0;
        bottom: 0;
        left: 0;
        right: auto;
        z-index: 1100;
        width: min(290px, 86vw);
        height: 100vh;
        height: 100dvh;
        padding: 25px 17px;
        overflow-y: auto;
        transform: translate3d(-105%,0,0);
        visibility: hidden;
        pointer-events: none;
        transition:
            transform .38s cubic-bezier(.2,.8,.2,1),
            visibility .38s;
        box-shadow: 25px 0 80px rgba(0,0,0,.65);
        will-change: transform;
    }

    .sidebar.open {
        transform: translate3d(0,0,0);
        visibility: visible;
        pointer-events: auto;
    }

    .overlay {
        z-index: 1050;
    }

    .overlay.show {
        visibility: visible;
        opacity: 1;
        pointer-events: auto;
    }

    .main {
        width: 100%;
        min-width: 0;
        margin-left: 0;
        padding: 23px 17px 25px;
    }

    .topline {
        margin-bottom: 28px;
    }

    .top-badge {
        padding: 8px 10px;
        font-size: 9px;
    }

    h1 {
        font-size: clamp(35px,9vw,49px);
        letter-spacing: -1.8px;
        overflow-wrap: anywhere;
    }

    .subtitle {
        font-size: 13px;
    }

    .card {
        padding: 24px 18px;
        border-radius: 18px;
    }

    .form-grid {
        grid-template-columns: minmax(0,1fr);
        gap: 21px;
    }

    .field.full-width {
        grid-column: auto;
    }

    .form-actions {
        align-items: stretch;
        flex-direction: column-reverse;
    }

    .primary,
    .secondary {
        width: 100%;
        min-height: 49px;
    }

    .footer {
        margin-top: 20px;
    }
}

/* SMALL PHONES */

@media (max-width: 400px) {
    .mobile-bar {
        padding-right: 12px;
        padding-left: 12px;
        gap: 12px;
    }

    .mobile-brand {
        font-size: 18px;
    }

    .main {
        padding-right: 12px;
        padding-left: 12px;
    }

    .card {
        padding: 21px 13px;
    }

    .topline {
        align-items: flex-start;
    }

    .top-badge {
        max-width: 135px;
        white-space: normal;
        line-height: 1.5;
    }

    .eyebrow {
        font-size: 9px;
        letter-spacing: 1px;
    }
}

/* ACCESSIBILITY */

.menu-button:focus-visible,
.nav-link:focus-visible,
.primary:focus-visible,
.secondary:focus-visible {
    outline: 2px solid var(--orange-light);
    outline-offset: 3px;
}

@media (prefers-reduced-motion: reduce) {
    *,
    *::before,
    *::after {
        animation-duration: .01ms !important;
        animation-iteration-count: 1 !important;
        scroll-behavior: auto !important;
        transition-duration: .01ms !important;
    }
}
</style>
</head>

<body>

<div class="ambient ambient-one" aria-hidden="true"></div>
<div class="ambient ambient-two" aria-hidden="true"></div>
<div class="ambient ambient-three" aria-hidden="true"></div>

<!-- MOBILE HEADER: MENU ON LEFT -->
<header class="mobile-bar">
    <button
        type="button"
        class="menu-button"
        id="menuButton"
        aria-label="Open navigation menu"
        aria-controls="sidebar"
        aria-expanded="false"
    >☰</button>

    <a href="../index.php" class="mobile-brand">
        Career<span>Bridge.</span>
    </a>
</header>

<div class="overlay" id="overlay"></div>

<!-- LEFT SIDEBAR -->
<aside class="sidebar" id="sidebar" aria-label="Company sidebar">

    <a href="../index.php" class="brand">
        <span class="brand-mark">C</span>
        <span class="brand-name">Career<span>Bridge.</span></span>
    </a>

    <p class="sidebar-caption">Workspace</p>

    <nav class="nav-links" aria-label="Company navigation">

        <a href="dashboard.php" class="nav-link">
            <span class="nav-icon" aria-hidden="true">⌂</span>
            <span>Dashboard</span>
        </a>

        <a href="add_internship.php" class="nav-link active" aria-current="page">
            <span class="nav-icon" aria-hidden="true">＋</span>
            <span>Add Internship</span>
        </a>

        <a href="internships.php" class="nav-link">
            <span class="nav-icon" aria-hidden="true">▤</span>
            <span>My Internships</span>
        </a>

        <a href="applicants.php" class="nav-link">
            <span class="nav-icon" aria-hidden="true">♙</span>
            <span>Applicants</span>
        </a>

        <a href="../index.php" class="nav-link">
            <span class="nav-icon" aria-hidden="true">⌕</span>
            <span>Visit Website</span>
        </a>

        <a href="../logout.php" class="nav-link">
            <span class="nav-icon" aria-hidden="true">↪</span>
            <span>Sign Out</span>
        </a>

    </nav>

    <div class="sidebar-bottom">
        <div class="company-card">
            <small><span class="status-dot"></span>Company account</small>
            <strong><?= e($companyName) ?></strong>
        </div>

        <p class="sidebar-footer">CAREERBRIDGE · COMPANY PORTAL</p>
    </div>

</aside>

<!-- MAIN PAGE -->
<main class="main">

    <div class="topline">
        <p class="breadcrumb">
            Workspace / <span>Add Internship</span>
        </p>
        <div class="top-badge">Company Portal</div>
    </div>

    <header class="page-heading">
        <span class="eyebrow">Build your next opportunity</span>

        <h1>Publish an <span>Internship.</span></h1>

        <p class="subtitle">
            Connect with talented students and discover your next great intern.
            Create an opportunity that helps emerging professionals grow.
        </p>

        <p class="company-label">
            Publishing as: <strong><?= e($companyName) ?></strong>
        </p>
    </header>

    <div class="card-wrap">
        <section class="card">

            <h2 class="section-title">Internship Details</h2>

            <p class="section-description">
                Complete the information below. All fields marked
                <span class="required">*</span> are required.
            </p>

            <?php if ($errors): ?>
                <div class="alert" role="alert">
                    <strong>Please correct the following:</strong>
                    <ul>
                        <?php foreach ($errors as $error): ?>
                            <li><?= e($error) ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endif; ?>

            <form action="add_internship.php" method="POST" id="internshipForm">

                <input
                    type="hidden"
                    name="csrf_token"
                    value="<?= e($csrfToken) ?>"
                >

                <div class="form-grid">

                    <div class="field full-width">
                        <label for="title">Internship Title <span class="required">*</span></label>
                        <input
                            type="text"
                            id="title"
                            name="title"
                            maxlength="150"
                            placeholder="e.g. PHP Web Development Intern"
                            value="<?= e($form['title']) ?>"
                            autocomplete="off"
                            required
                        >
                    </div>

                    <div class="field full-width">
                        <label for="description">Internship Description <span class="required">*</span></label>
                        <textarea
                            id="description"
                            name="description"
                            placeholder="Describe responsibilities, learning opportunities and expectations..."
                            required
                        ><?= e($form['description']) ?></textarea>
                        <small class="help-text">
                            Explain what the intern will learn and work on.
                        </small>
                    </div>

                    <div class="field full-width">
                        <label for="skills_required">Required Skills <span class="required">*</span></label>
                        <textarea
                            id="skills_required"
                            name="skills_required"
                            placeholder="e.g. HTML, CSS, JavaScript, PHP, MySQL"
                            required
                        ><?= e($form['skills_required']) ?></textarea>
                        <small class="help-text">Separate skills with commas.</small>
                    </div>

                    <div class="field">
                        <label for="location">Location <span class="required">*</span></label>
                        <input
                            type="text"
                            id="location"
                            name="location"
                            maxlength="150"
                            placeholder="e.g. Chennai / Remote"
                            value="<?= e($form['location']) ?>"
                            required
                        >
                    </div>

                    <div class="field">
                        <label for="duration">Duration <span class="required">*</span></label>
                        <input
                            type="text"
                            id="duration"
                            name="duration"
                            maxlength="100"
                            placeholder="e.g. 3 months"
                            value="<?= e($form['duration']) ?>"
                            required
                        >
                    </div>

                    <div class="field">
                        <label for="stipend">Monthly Stipend (₹) <span class="required">*</span></label>
                        <input
                            type="number"
                            id="stipend"
                            name="stipend"
                            min="0"
                            step="0.01"
                            placeholder="e.g. 10000"
                            value="<?= e($form['stipend']) ?>"
                            required
                        >
                        <small class="help-text">Enter 0 if the internship is unpaid.</small>
                    </div>

                    <div class="field">
                        <label for="deadline">Application Deadline <span class="required">*</span></label>
                        <input
                            type="date"
                            id="deadline"
                            name="deadline"
                            min="<?= e(date('Y-m-d')) ?>"
                            value="<?= e($form['deadline']) ?>"
                            required
                        >
                    </div>

                </div>

                <div class="form-actions">
                    <a href="dashboard.php" class="secondary">← Back to Dashboard</a>

                    <button type="submit" class="primary" id="publishButton">
                        <span id="buttonText">Publish Internship</span>
                        <span class="arrow" aria-hidden="true">→</span>
                    </button>
                </div>

                <p class="security-note">
                    Your information is submitted securely through CareerBridge.
                    Review your details before publishing.
                </p>

            </form>
        </section>
    </div>

    <footer class="footer">
        © <?= date('Y') ?> <span>CareerBridge</span>.
        Connecting talent with opportunity.
    </footer>

</main>

<script>
/* MOBILE LEFT DRAWER */
const sidebar = document.getElementById('sidebar');
const overlay = document.getElementById('overlay');
const menuButton = document.getElementById('menuButton');

function openMenu() {
    sidebar.classList.add('open');
    overlay.classList.add('show');

    menuButton.setAttribute('aria-expanded', 'true');
    menuButton.setAttribute('aria-label', 'Close navigation menu');
    menuButton.textContent = '×';

    document.body.style.overflow = 'hidden';
}

function closeMenu() {
    sidebar.classList.remove('open');
    overlay.classList.remove('show');

    menuButton.setAttribute('aria-expanded', 'false');
    menuButton.setAttribute('aria-label', 'Open navigation menu');
    menuButton.textContent = '☰';

    document.body.style.overflow = '';
}

menuButton.addEventListener('click', function () {
    if (sidebar.classList.contains('open')) {
        closeMenu();
    } else {
        openMenu();
    }
});

overlay.addEventListener('click', closeMenu);

document.addEventListener('keydown', function (event) {
    if (event.key === 'Escape') {
        closeMenu();
    }
});

sidebar.querySelectorAll('.nav-link').forEach(function (link) {
    link.addEventListener('click', function () {
        if (window.innerWidth <= 760) {
            closeMenu();
        }
    });
});

/* Restore desktop layout after rotating the phone */
window.addEventListener('resize', function () {
    if (window.innerWidth > 760) {
        closeMenu();
    }
});

/* DEADLINE VALIDATION */
const form = document.getElementById('internshipForm');
const deadline = document.getElementById('deadline');
const publishButton = document.getElementById('publishButton');
const buttonText = document.getElementById('buttonText');

function localDateString() {
    const now = new Date();

    return [
        now.getFullYear(),
        String(now.getMonth() + 1).padStart(2, '0'),
        String(now.getDate()).padStart(2, '0')
    ].join('-');
}

function setMinimumDeadline() {
    deadline.min = localDateString();
}

setMinimumDeadline();

form.addEventListener('submit', function (event) {
    setMinimumDeadline();

    if (deadline.value && deadline.value < deadline.min) {
        event.preventDefault();
        alert('Please select today or a future date for the deadline.');
        deadline.focus();
        return;
    }

    if (!form.checkValidity()) {
        event.preventDefault();
        form.reportValidity();
        return;
    }

    publishButton.disabled = true;
    buttonText.textContent = 'Publishing...';
});

window.addEventListener('pageshow', function () {
    publishButton.disabled = false;
    buttonText.textContent = 'Publish Internship';
});
</script>

</body>
</html>
