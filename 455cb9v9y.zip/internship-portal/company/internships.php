
<?php
session_start();

require_once "../config/database.php";

if (
    !isset($_SESSION['user_id']) ||
    !isset($_SESSION['role']) ||
    $_SESSION['role'] !== 'company'
) {
    header("Location: ../login.php");
    exit;
}

try {
    $pdo = getPDO();
} catch (Throwable $e) {
    http_response_code(500);
    exit("Database connection failed. Please check your database configuration.");
}

$stmt = $pdo->prepare("SELECT id FROM companies WHERE user_id = ?");
$stmt->execute([$_SESSION['user_id']]);
$company = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$company) {
    http_response_code(403);
    exit("Company profile not found.");
}

$stmt = $pdo->prepare("
    SELECT i.*,
        (
            SELECT COUNT(*)
            FROM applications a
            WHERE a.internship_id = i.id
        ) AS applicant_count
    FROM internships i
    WHERE i.company_id = ?
    ORDER BY i.created_at DESC
");

$stmt->execute([$company['id']]);
$jobs = $stmt->fetchAll(PDO::FETCH_ASSOC);

$totalJobs = count($jobs);
$totalApplicants = 0;
$openDeadlines = 0;
$today = date('Y-m-d');

foreach ($jobs as $job) {
    $totalApplicants += (int) $job['applicant_count'];

    if (empty($job['deadline']) || $job['deadline'] >= $today) {
        $openDeadlines++;
    }
}

function e($value): string
{
    return htmlspecialchars(
        (string) ($value ?? ''),
        ENT_QUOTES,
        'UTF-8'
    );
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="theme-color" content="#090909">

<title>My Internships | CareerBridge</title>

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">

<style>
:root {
    --orange: #ff7900;
    --orange-light: #ffc078;
    --orange-dark: #e94b00;
    --black: #090909;
    --surface: #151515;
    --muted: #a3a3a3;
    --border: rgba(255,255,255,.09);
    --green: #70e8a0;
    --sidebar-width: 255px;
}

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

html {
    scroll-behavior: smooth;
    scroll-padding-top: 30px;
}

body {
    min-height: 100vh;
    overflow-x: hidden;
    background: var(--black);
    color: #fff;
    font-family: Inter, Arial, sans-serif;
}

body, button, a {
    -webkit-tap-highlight-color: transparent;
}

body.menu-open {
    overflow: hidden;
}

a {
    color: inherit;
    text-decoration: none;
}

button {
    font: inherit;
}

button:focus-visible,
a:focus-visible {
    outline: 2px solid var(--orange-light);
    outline-offset: 4px;
}

/* ==================================================
   ANIMATED BACKGROUND
================================================== */

.background-grid {
    position: fixed;
    inset: 0;
    z-index: -5;
    pointer-events: none;
    background-image:
        linear-gradient(rgba(255,121,0,.045) 1px, transparent 1px),
        linear-gradient(90deg,rgba(255,121,0,.045) 1px, transparent 1px);
    background-size: 42px 42px;
    mask-image: linear-gradient(to bottom,#000,transparent 95%);
}

.ambient {
    position: fixed;
    z-index: -4;
    width: 400px;
    height: 400px;
    border-radius: 50%;
    pointer-events: none;
    filter: blur(110px);
    opacity: .20;
    animation: ambientMove 12s ease-in-out infinite alternate;
}

.ambient.one {
    top: -180px;
    right: -100px;
    background: #ff5900;
}

.ambient.two {
    left: -180px;
    bottom: -150px;
    background: #ff9900;
    animation-delay: -5s;
}

.ambient.three {
    width: 280px;
    height: 280px;
    top: 45%;
    right: 12%;
    background: #ff3c00;
    opacity: .10;
    animation-duration: 16s;
}

@keyframes ambientMove {
    0% {
        transform: translate(0,0) scale(1);
    }
    50% {
        transform: translate(-35px,30px) scale(1.15);
    }
    100% {
        transform: translate(25px,-25px) scale(.92);
    }
}

@keyframes entrance {
    from {
        opacity: 0;
        transform: translateY(28px) scale(.98);
    }
    to {
        opacity: 1;
        transform: translateY(0) scale(1);
    }
}

@keyframes slideSidebar {
    from {
        opacity: 0;
        transform: translateX(-100%);
    }
    to {
        opacity: 1;
        transform: translateX(0);
    }
}

@keyframes glowPulse {
    0%,100% {
        box-shadow: 0 0 8px rgba(255,121,0,.18);
    }
    50% {
        box-shadow: 0 0 28px rgba(255,121,0,.48);
    }
}

@keyframes dotPulse {
    0%,100% {
        opacity: 1;
        transform: scale(1);
    }
    50% {
        opacity: .45;
        transform: scale(.72);
    }
}

@keyframes shine {
    0%,50% {
        left: -130%;
    }
    85%,100% {
        left: 160%;
    }
}

@keyframes gradientMove {
    0%,100% {
        background-position: 0% 50%;
    }
    50% {
        background-position: 100% 50%;
    }
}

@keyframes floatIcon {
    0%,100% {
        transform: translateY(0) rotate(0);
    }
    50% {
        transform: translateY(-8px) rotate(5deg);
    }
}

@keyframes borderGlow {
    0%,100% {
        border-color: rgba(255,121,0,.22);
    }
    50% {
        border-color: rgba(255,121,0,.65);
    }
}

/* ==================================================
   MOBILE OVERLAY
================================================== */

.sidebar-overlay {
    position: fixed;
    inset: 0;
    z-index: 800;
    background: rgba(0,0,0,.72);
    backdrop-filter: blur(5px);
    opacity: 0;
    visibility: hidden;
    transition: opacity .3s, visibility .3s;
}

.sidebar-overlay.visible {
    opacity: 1;
    visibility: visible;
}

/* ==================================================
   LEFT SIDEBAR
================================================== */

.sidebar {
    position: fixed;
    z-index: 900;
    top: 0;
    bottom: 0;
    left: 0;
    display: flex;
    flex-direction: column;
    width: var(--sidebar-width);
    padding: 25px 17px 18px;
    overflow-x: hidden;
    overflow-y: auto;
    border-right: 1px solid rgba(255,121,0,.18);
    background:
        radial-gradient(ellipse at top left,rgba(255,121,0,.12),transparent 48%),
        linear-gradient(180deg,#121212,#090909 75%);
    box-shadow: 12px 0 55px rgba(0,0,0,.25);
    animation: sidebarEntrance .8s ease both;
}

@keyframes sidebarEntrance {
    from {
        opacity: 0;
        transform: translateX(-35px);
    }
    to {
        opacity: 1;
        transform: translateX(0);
    }
}

.sidebar-brand-row {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 8px;
    padding: 3px 8px 28px;
    border-bottom: 1px solid var(--border);
}

.brand {
    font-size: 25px;
    font-weight: 900;
    letter-spacing: -1.4px;
    white-space: nowrap;
}

.brand span {
    color: var(--orange);
    text-shadow: 0 0 25px rgba(255,121,0,.45);
}

.brand-symbol {
    display: inline-grid;
    place-items: center;
    width: 35px;
    height: 35px;
    margin-right: 7px;
    border: 1px solid rgba(255,121,0,.45);
    border-radius: 11px;
    color: white;
    background: linear-gradient(135deg,#ff9d00,#ed4300);
    box-shadow: 0 0 25px rgba(255,121,0,.25);
    font-size: 17px;
    vertical-align: middle;
}

.sidebar-close {
    display: none;
    place-items: center;
    flex-shrink: 0;
    width: 36px;
    height: 36px;
    border: 1px solid var(--border);
    border-radius: 10px;
    color: #fff;
    background: #1b1b1b;
    cursor: pointer;
}

.sidebar-label {
    padding: 26px 10px 13px;
    color: #737373;
    font-size: 9px;
    font-weight: 900;
    letter-spacing: 2px;
}

.sidebar-nav {
    display: flex;
    flex-direction: column;
    gap: 8px;
}

.side-link {
    position: relative;
    display: flex;
    align-items: center;
    gap: 13px;
    min-height: 49px;
    padding: 12px 13px;
    border: 1px solid transparent;
    border-radius: 13px;
    color: #a8a8a8;
    font-size: 12px;
    font-weight: 750;
    transition:
        color .25s,
        background .25s,
        border-color .25s,
        transform .25s,
        box-shadow .25s;
}

.side-link::before {
    content: "";
    position: absolute;
    top: 10px;
    bottom: 10px;
    left: -1px;
    width: 3px;
    border-radius: 5px;
    background: var(--orange);
    opacity: 0;
    transition: opacity .25s;
}

.side-link:hover {
    color: #fff;
    transform: translateX(4px);
    border-color: rgba(255,121,0,.2);
    background: rgba(255,121,0,.07);
}

.side-link.active {
    color: var(--orange-light);
    border-color: rgba(255,121,0,.27);
    background: linear-gradient(110deg,rgba(255,121,0,.17),rgba(255,121,0,.035));
    box-shadow: inset 0 0 20px rgba(255,121,0,.035);
}

.side-link.active::before {
    opacity: 1;
}

.side-icon {
    display: grid;
    place-items: center;
    flex-shrink: 0;
    width: 25px;
    height: 25px;
    border-radius: 8px;
    color: inherit;
    background: rgba(255,255,255,.055);
    font-size: 15px;
    transition: transform .3s, background .3s;
}

.side-link:hover .side-icon,
.side-link.active .side-icon {
    color: var(--orange-light);
    background: rgba(255,121,0,.13);
    transform: scale(1.08);
}

.side-link .link-text {
    flex: 1;
}

.side-badge {
    display: grid;
    place-items: center;
    min-width: 22px;
    height: 22px;
    padding: 0 6px;
    border-radius: 7px;
    color: var(--orange-light);
    background: rgba(255,121,0,.12);
    font-size: 10px;
    font-weight: 900;
}

.sidebar-spacer {
    flex: 1;
    min-height: 25px;
}

.sidebar-promo {
    position: relative;
    overflow: hidden;
    padding: 17px;
    border: 1px solid rgba(255,121,0,.25);
    border-radius: 16px;
    background:
        radial-gradient(circle at top right,rgba(255,121,0,.20),transparent 60%),
        #15110e;
    animation: borderGlow 4s ease infinite;
}

.sidebar-promo::after {
    content: "";
    position: absolute;
    top: 0;
    bottom: 0;
    left: -120%;
    width: 70%;
    background: linear-gradient(90deg,transparent,rgba(255,255,255,.07),transparent);
    transform: skewX(-20deg);
    animation: shine 6s ease infinite;
    pointer-events: none;
}

.promo-icon {
    display: grid;
    place-items: center;
    width: 36px;
    height: 36px;
    margin-bottom: 13px;
    border-radius: 11px;
    color: #fff;
    background: linear-gradient(135deg,#ff9900,#ef4d00);
    font-size: 17px;
}

.sidebar-promo strong {
    font-size: 12px;
}

.sidebar-promo p {
    margin-top: 8px;
    color: #9a9188;
    font-size: 10px;
    line-height: 1.8;
}

.sidebar-bottom {
    padding-top: 18px;
}

.logout-link {
    color: #ff9696;
    border-color: rgba(255,90,90,.12);
}

.logout-link:hover {
    color: #fff;
    border-color: rgba(255,90,90,.35);
    background: rgba(255,70,70,.09);
}

.sidebar-user {
    display: flex;
    align-items: center;
    gap: 11px;
    margin-top: 18px;
    padding: 14px 7px 3px;
    border-top: 1px solid var(--border);
}

.user-avatar {
    display: grid;
    place-items: center;
    flex-shrink: 0;
    width: 38px;
    height: 38px;
    border: 1px solid rgba(255,121,0,.35);
    border-radius: 12px;
    color: #fff;
    background: linear-gradient(135deg,#ff9900,#e74600);
    font-weight: 900;
}

.user-info {
    min-width: 0;
}

.user-info strong {
    display: block;
    font-size: 11px;
}

.user-info span {
    display: block;
    margin-top: 4px;
    color: #777;
    font-size: 10px;
}

/* ==================================================
   MOBILE TOP BAR
================================================== */

.mobile-topbar {
    display: none;
    position: sticky;
    top: 0;
    z-index: 700;
    align-items: center;
    gap: 12px;
    min-height: 66px;
    padding: 10px 16px;
    border-bottom: 1px solid var(--border);
    background: rgba(9,9,9,.92);
    backdrop-filter: blur(20px);
}

.mobile-menu-btn {
    display: grid;
    place-items: center;
    flex-shrink: 0;
    width: 43px;
    height: 43px;
    border: 1px solid rgba(255,121,0,.28);
    border-radius: 12px;
    color: #fff;
    background: linear-gradient(145deg,#24170d,#111);
    cursor: pointer;
    transition: transform .25s, box-shadow .25s;
}

.mobile-menu-btn:hover {
    transform: scale(1.06);
    box-shadow: 0 0 22px rgba(255,121,0,.22);
}

.mobile-topbar .brand {
    font-size: 22px;
}

.mobile-topbar .mobile-notice {
    display: grid;
    place-items: center;
    width: 40px;
    height: 40px;
    margin-left: auto;
    border: 1px solid var(--border);
    border-radius: 12px;
    color: var(--orange-light);
    background: #171717;
    cursor: pointer;
}

/* ==================================================
   NOTIFICATIONS
================================================== */

.notification-panel {
    position: fixed;
    z-index: 1100;
    top: 20px;
    right: 20px;
    width: min(350px,calc(100vw - 30px));
    max-height: min(520px,85vh);
    overflow-y: auto;
    padding: 21px;
    border: 1px solid rgba(255,121,0,.35);
    border-radius: 20px;
    background: rgba(16,16,16,.97);
    backdrop-filter: blur(25px);
    box-shadow: 0 25px 80px rgba(0,0,0,.7),0 0 35px rgba(255,121,0,.12);
    opacity: 0;
    visibility: hidden;
    transform: translateY(-12px) scale(.96);
    transform-origin: top right;
    transition: opacity .25s, transform .25s, visibility .25s;
}

.notification-panel.open {
    opacity: 1;
    visibility: visible;
    transform: translateY(0) scale(1);
}

.notification-heading {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 12px;
    margin-bottom: 17px;
}

.notification-heading h2 {
    font-size: 17px;
    font-weight: 900;
}

.notification-heading p {
    margin-top: 5px;
    color: var(--muted);
    font-size: 10px;
    line-height: 1.6;
}

.panel-close {
    display: grid;
    place-items: center;
    flex-shrink: 0;
    width: 33px;
    height: 33px;
    border: 1px solid var(--border);
    border-radius: 10px;
    color: #fff;
    background: #222;
    cursor: pointer;
}

.panel-close:hover {
    color: var(--orange-light);
    border-color: var(--orange);
}

.notice-item {
    display: flex;
    align-items: flex-start;
    gap: 12px;
    padding: 14px 0;
    border-top: 1px solid var(--border);
    animation: entrance .4s both;
}

.notice-icon {
    display: grid;
    place-items: center;
    flex-shrink: 0;
    width: 39px;
    height: 39px;
    border: 1px solid rgba(255,121,0,.25);
    border-radius: 12px;
    color: var(--orange-light);
    background: rgba(255,121,0,.1);
    font-size: 17px;
}

.notice-item strong {
    font-size: 11px;
    line-height: 1.6;
}

.notice-item p {
    margin-top: 5px;
    color: var(--muted);
    font-size: 10px;
    line-height: 1.8;
}

.notice-link {
    display: inline-block;
    margin-top: 8px;
    color: var(--orange-light);
    font-size: 10px;
    font-weight: 800;
}

/* ==================================================
   MAIN CONTENT
================================================== */

.main-content {
    min-height: 100vh;
    margin-left: var(--sidebar-width);
    padding: 36px clamp(20px,4vw,60px) 55px;
}

.content-inner {
    width: min(1300px,100%);
    margin-inline: auto;
}

.page-head {
    display: flex;
    justify-content: space-between;
    align-items: flex-end;
    gap: 25px;
    margin-bottom: 35px;
    animation: entrance .8s both;
}

.eyebrow {
    display: inline-flex;
    align-items: center;
    gap: 9px;
    padding: 9px 13px;
    margin-bottom: 18px;
    border: 1px solid rgba(255,121,0,.3);
    border-radius: 30px;
    color: var(--orange-light);
    background: rgba(255,121,0,.07);
    font-size: 10px;
    font-weight: 900;
    letter-spacing: 1.5px;
}

.pulse-dot {
    width: 8px;
    height: 8px;
    border-radius: 50%;
    background: var(--orange);
    box-shadow: 0 0 15px var(--orange);
    animation: dotPulse 1.5s infinite;
}

h1 {
    font-size: clamp(38px,4.5vw,65px);
    line-height: 1.08;
    font-weight: 900;
    letter-spacing: -3px;
}

h1 span {
    color: var(--orange);
    background: linear-gradient(100deg,#ffbd76,#ff7900,#ff4b00,#ffc078);
    background-size: 250% auto;
    -webkit-background-clip: text;
    background-clip: text;
    -webkit-text-fill-color: transparent;
    animation: gradientMove 6s linear infinite;
}

.subtitle {
    max-width: 560px;
    margin-top: 16px;
    color: var(--muted);
    font-size: 13px;
    line-height: 1.9;
}

.btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 9px;
    padding: 13px 18px;
    border: 1px solid transparent;
    border-radius: 11px;
    font-size: 11px;
    font-weight: 900;
    cursor: pointer;
    transition: transform .25s, box-shadow .25s, border-color .25s;
}

.btn-primary {
    color: #fff;
    background: linear-gradient(120deg,#ff9900,#ff5b00,#df3b00);
    background-size: 200% 200%;
    box-shadow: 0 8px 25px rgba(255,100,0,.22);
    animation: gradientMove 5s ease infinite;
}

.btn-primary:hover {
    transform: translateY(-4px) scale(1.025);
    box-shadow: 0 14px 36px rgba(255,100,0,.4);
}

.btn-outline {
    color: #ddd;
    border-color: #383838;
    background: #171717;
}

.btn-outline:hover {
    color: var(--orange-light);
    border-color: var(--orange);
    transform: translateY(-2px);
}

.alert-success {
    display: flex;
    align-items: center;
    gap: 13px;
    padding: 17px 20px;
    margin-bottom: 25px;
    border: 1px solid rgba(78,220,142,.25);
    border-radius: 13px;
    color: #8cf0b7;
    background: rgba(78,220,142,.07);
    font-size: 12px;
    line-height: 1.8;
    animation: entrance .6s both;
}

.alert-icon {
    display: grid;
    place-items: center;
    flex-shrink: 0;
    width: 34px;
    height: 34px;
    border-radius: 50%;
    background: rgba(78,220,142,.12);
    font-weight: 900;
}

/* ==================================================
   STATISTICS
================================================== */

.stats-grid {
    display: grid;
    grid-template-columns: repeat(3,minmax(0,1fr));
    gap: 18px;
    margin-bottom: 36px;
}

.stat-card {
    position: relative;
    isolation: isolate;
    overflow: hidden;
    padding: 25px;
    border: 1px solid var(--border);
    border-radius: 20px;
    background: linear-gradient(145deg,#1d1d1d,#0c0c0c);
    box-shadow: 0 12px 35px rgba(0,0,0,.15);
    animation: entrance .8s cubic-bezier(.2,.8,.2,1) both;
    transition: transform .35s, border-color .35s, box-shadow .35s;
}

.stat-card:nth-child(2) {
    animation-delay: .12s;
}

.stat-card:nth-child(3) {
    animation-delay: .24s;
}

.stat-card::before {
    content: "";
    position: absolute;
    z-index: -1;
    top: -80px;
    right: -60px;
    width: 160px;
    height: 160px;
    border-radius: 50%;
    background: var(--orange);
    filter: blur(55px);
    opacity: .17;
    transition: opacity .35s, transform .35s;
}

.stat-card::after {
    content: "";
    position: absolute;
    top: 0;
    left: -130%;
    width: 80%;
    height: 100%;
    background: linear-gradient(100deg,transparent,rgba(255,255,255,.06),transparent);
    transform: skewX(-18deg);
    animation: shine 7s ease-in-out infinite;
    pointer-events: none;
}

.stat-card:hover {
    transform: translateY(-9px) scale(1.02);
    border-color: rgba(255,121,0,.55);
    box-shadow: 0 18px 48px rgba(255,100,0,.13);
}

.stat-card:hover::before {
    opacity: .35;
    transform: scale(1.3);
}

.stat-label {
    margin-bottom: 15px;
    color: var(--muted);
    font-size: 11px;
    font-weight: 700;
}

.stat-number {
    font-size: clamp(31px,3.5vw,44px);
    font-weight: 900;
    letter-spacing: -2px;
}

.stat-number.orange {
    color: var(--orange);
    text-shadow: 0 0 25px rgba(255,121,0,.25);
}

.stat-caption {
    margin-top: 10px;
    color: #828282;
    font-size: 10px;
    line-height: 1.7;
}

/* ==================================================
   INTERNSHIP CARDS
================================================== */

.section-head {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 15px;
    margin: 35px 0 20px;
}

.section-head h2 {
    font-size: 19px;
    font-weight: 900;
    letter-spacing: -.5px;
}

.section-count {
    color: var(--muted);
    font-size: 11px;
    white-space: nowrap;
}

.jobs-grid {
    display: grid;
    grid-template-columns: repeat(2,minmax(0,1fr));
    gap: 22px;
}

.job-card {
    position: relative;
    isolation: isolate;
    overflow: hidden;
    display: flex;
    flex-direction: column;
    min-width: 0;
    padding: 26px;
    border: 1px solid var(--border);
    border-radius: 21px;
    background: linear-gradient(145deg,#1c1c1c,#0c0c0c);
    box-shadow: 0 12px 35px rgba(0,0,0,.15);
    animation: entrance .8s cubic-bezier(.2,.8,.2,1) both;
    transition: transform .35s, border-color .35s, box-shadow .35s;
}

.job-card::before {
    content: "";
    position: absolute;
    z-index: -1;
    inset: 0 0 auto;
    height: 3px;
    background: linear-gradient(90deg,transparent,#ff4d00,#ffbd76,#ff7900,transparent);
    background-size: 250% 100%;
    animation: gradientMove 4s linear infinite;
}

.job-card::after {
    content: "";
    position: absolute;
    z-index: -1;
    top: -100px;
    right: -100px;
    width: 200px;
    height: 200px;
    border-radius: 50%;
    background: rgba(255,121,0,.13);
    filter: blur(65px);
    opacity: 0;
    transition: opacity .35s;
}

.job-card:hover {
    transform: translateY(-8px) scale(1.008);
    border-color: rgba(255,121,0,.5);
    box-shadow: 0 24px 60px rgba(0,0,0,.35),0 0 28px rgba(255,121,0,.08);
}

.job-card:hover::after {
    opacity: 1;
}

.job-top {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 12px;
    margin-bottom: 19px;
}

.job-icon {
    display: grid;
    place-items: center;
    flex-shrink: 0;
    width: 48px;
    height: 48px;
    border: 1px solid rgba(255,121,0,.3);
    border-radius: 15px;
    color: var(--orange-light);
    background: linear-gradient(145deg,rgba(255,121,0,.2),rgba(255,121,0,.04));
    font-size: 23px;
    transition: transform .4s, box-shadow .4s;
}

.job-card:hover .job-icon {
    transform: rotate(-8deg) scale(1.1);
    box-shadow: 0 0 25px rgba(255,121,0,.18);
}

.deadline-badge {
    display: inline-flex;
    align-items: center;
    gap: 7px;
    padding: 8px 11px;
    border-radius: 30px;
    font-size: 10px;
    font-weight: 800;
}

.deadline-badge.open {
    border: 1px solid rgba(67,210,128,.2);
    color: #7de4a5;
    background: rgba(67,210,128,.09);
}

.deadline-badge.closed {
    border: 1px solid rgba(255,80,80,.2);
    color: #ff8585;
    background: rgba(255,80,80,.09);
}

.job-title {
    font-size: 21px;
    line-height: 1.4;
    font-weight: 900;
    letter-spacing: -.6px;
    overflow-wrap: anywhere;
}

.job-location {
    margin-top: 9px;
    color: var(--orange-light);
    font-size: 11px;
    font-weight: 700;
    overflow-wrap: anywhere;
}

.job-description {
    margin-top: 17px;
    color: #a7a7a7;
    font-size: 12px;
    line-height: 1.9;
    overflow-wrap: anywhere;
}

.job-details {
    display: grid;
    grid-template-columns: repeat(2,minmax(0,1fr));
    gap: 11px;
    margin-top: 22px;
}

.detail-box {
    min-width: 0;
    padding: 14px;
    border: 1px solid rgba(255,255,255,.065);
    border-radius: 12px;
    background: rgba(255,255,255,.025);
    transition: border-color .25s, background .25s;
}

.job-card:hover .detail-box {
    border-color: rgba(255,121,0,.12);
    background: rgba(255,121,0,.025);
}

.detail-label {
    margin-bottom: 8px;
    color: #858585;
    font-size: 10px;
}

.detail-value {
    color: #f3f3f3;
    font-size: 12px;
    font-weight: 800;
    line-height: 1.6;
    overflow-wrap: anywhere;
}

.detail-value.orange {
    color: var(--orange-light);
}

.skills {
    display: flex;
    flex-wrap: wrap;
    gap: 8px;
    margin-top: 18px;
}

.skill-tag {
    display: inline-block;
    max-width: 100%;
    padding: 8px 10px;
    border: 1px solid rgba(255,121,0,.17);
    border-radius: 8px;
    color: #ffc18b;
    background: rgba(255,121,0,.06);
    font-size: 10px;
    font-weight: 700;
    overflow-wrap: anywhere;
    transition: background .25s, border-color .25s, transform .25s;
}

.skill-tag:hover {
    transform: translateY(-2px);
    border-color: rgba(255,121,0,.4);
    background: rgba(255,121,0,.13);
}

.job-footer {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 13px;
    margin-top: auto;
    padding-top: 23px;
}

.posted-date {
    color: #777;
    font-size: 10px;
    line-height: 1.9;
}

.posted-date strong {
    color: #d4d4d4;
    font-size: 11px;
}

.job-footer .btn {
    flex-shrink: 0;
}

/* ==================================================
   EMPTY STATE AND BOTTOM NOTE
================================================== */

.empty-state {
    display: flex;
    flex-direction: column;
    align-items: center;
    padding: 65px 25px;
    border: 1px dashed rgba(255,121,0,.3);
    border-radius: 22px;
    text-align: center;
    background: rgba(255,121,0,.025);
    animation: entrance .8s both;
}

.empty-icon {
    display: grid;
    place-items: center;
    width: 76px;
    height: 76px;
    margin-bottom: 24px;
    border: 1px solid rgba(255,121,0,.28);
    border-radius: 22px;
    color: var(--orange);
    background: rgba(255,121,0,.09);
    font-size: 32px;
    animation: floatIcon 3s ease-in-out infinite;
}

.empty-state h3 {
    font-size: 22px;
    font-weight: 900;
}

.empty-state p {
    max-width: 440px;
    margin: 13px 0 24px;
    color: var(--muted);
    font-size: 12px;
    line-height: 1.9;
}

.bottom-note {
    display: flex;
    align-items: flex-start;
    gap: 15px;
    margin-top: 31px;
    padding: 21px;
    border: 1px solid rgba(255,121,0,.17);
    border-radius: 16px;
    background: linear-gradient(120deg,rgba(255,121,0,.065),rgba(255,255,255,.012));
    animation: entrance .9s both;
}

.note-icon {
    flex-shrink: 0;
    font-size: 22px;
}

.bottom-note strong {
    font-size: 12px;
}

.bottom-note p {
    margin-top: 7px;
    color: var(--muted);
    font-size: 11px;
    line-height: 1.9;
}

/* ==================================================
   TABLET
================================================== */

@media (max-width: 1100px) {
    :root {
        --sidebar-width: 225px;
    }

    .sidebar {
        padding-inline: 13px;
    }

    .main-content {
        padding-inline: 25px;
    }

    .stats-grid {
        gap: 12px;
    }

    .stat-card {
        padding: 20px;
    }

    .jobs-grid {
        gap: 15px;
    }

    .job-card {
        padding: 20px;
    }

    .job-footer {
        align-items: stretch;
        flex-direction: column;
    }

    .job-footer .btn {
        width: 100%;
    }
}

@media (max-width: 850px) {
    :root {
        --sidebar-width: 210px;
    }

    .brand {
        font-size: 22px;
    }

    .sidebar {
        padding-inline: 11px;
    }

    .side-link {
        gap: 10px;
        padding-inline: 10px;
    }

    .main-content {
        padding-inline: 20px;
    }

    .stats-grid {
        grid-template-columns: 1fr;
    }

    .stat-card {
        padding: 22px;
    }

    .stat-number {
        font-size: 35px;
    }

    .jobs-grid {
        grid-template-columns: 1fr;
    }

    .job-footer {
        align-items: center;
        flex-direction: row;
    }

    .job-footer .btn {
        width: auto;
    }
}

/* ==================================================
   PHONE: SLIDE-IN LEFT SIDEBAR
================================================== */

@media (max-width: 650px) {
    .sidebar {
        width: min(290px,86vw);
        padding: 22px 16px 17px;
        transform: translateX(-105%);
        visibility: hidden;
        transition: transform .32s cubic-bezier(.2,.8,.2,1), visibility .32s;
        animation: none;
    }

    .sidebar.open {
        transform: translateX(0);
        visibility: visible;
        box-shadow: 25px 0 70px rgba(0,0,0,.65);
    }

    .sidebar-close {
        display: grid;
    }

    .mobile-topbar {
        display: flex;
    }

    .main-content {
        margin-left: 0;
        padding: 29px 16px 42px;
    }

    .page-head {
        align-items: stretch;
        flex-direction: column;
        gap: 20px;
        margin-bottom: 26px;
    }

    .page-head > .btn {
        width: 100%;
        min-height: 47px;
    }

    .eyebrow {
        margin-bottom: 15px;
        font-size: 9px;
        letter-spacing: 1px;
    }

    h1 {
        font-size: clamp(33px,8vw,46px);
        letter-spacing: -2px;
    }

    .subtitle {
        font-size: 12px;
    }

    .stats-grid {
        gap: 13px;
        margin-bottom: 29px;
    }

    .stat-card {
        padding: 21px;
        border-radius: 17px;
    }

    .stat-number {
        font-size: 36px;
    }

    .section-head {
        align-items: flex-start;
        margin-top: 28px;
    }

    .section-head h2 {
        font-size: 15px;
    }

    .section-count {
        padding-top: 3px;
        font-size: 10px;
    }

    .jobs-grid {
        gap: 17px;
    }

    .job-card {
        padding: 18px;
        border-radius: 18px;
    }

    .job-title {
        font-size: 19px;
    }

    .job-footer {
        align-items: stretch;
        flex-direction: column;
    }

    .job-footer .btn {
        width: 100%;
        min-height: 45px;
    }

    .bottom-note {
        padding: 15px;
    }

    .empty-state {
        padding: 40px 15px;
    }

    .alert-success {
        align-items: flex-start;
        padding: 15px;
    }

    .notification-panel {
        top: 75px;
        right: 12px;
        width: min(350px,calc(100vw - 24px));
        max-height: calc(100vh - 95px);
    }
}

@media (max-width: 380px) {
    .mobile-topbar {
        padding-inline: 10px;
    }

    .mobile-topbar .brand {
        font-size: 20px;
    }

    .main-content {
        padding-inline: 12px;
    }

    .job-card {
        padding: 14px;
    }

    .job-details {
        grid-template-columns: 1fr;
    }

    .deadline-badge {
        padding: 7px 8px;
        font-size: 9px;
    }

    .section-head h2 {
        font-size: 13px;
    }

    .job-footer {
        align-items: stretch;
        flex-direction: column;
    }

    .job-footer .btn {
        width: 100%;
    }
}

/* ==================================================
   ACCESSIBILITY
================================================== */

@media (prefers-reduced-motion: reduce) {
    *,
    *::before,
    *::after {
        scroll-behavior: auto !important;
        animation-duration: .01ms !important;
        animation-iteration-count: 1 !important;
        transition-duration: .01ms !important;
    }
}
</style>
</head>

<body>

<div class="background-grid" aria-hidden="true"></div>
<div class="ambient one" aria-hidden="true"></div>
<div class="ambient two" aria-hidden="true"></div>
<div class="ambient three" aria-hidden="true"></div>

<!-- MOBILE SIDEBAR OVERLAY -->
<div class="sidebar-overlay" id="sidebarOverlay"></div>

<!-- ==================================================
     LEFT SIDEBAR
================================================== -->

<aside class="sidebar" id="sidebar" aria-label="Company navigation">

    <div class="sidebar-brand-row">
        <a class="brand" href="dashboard.php">
            <span class="brand-symbol">C</span>Career<span>Bridge.</span>
        </a>

        <button
            class="sidebar-close"
            id="sidebarClose"
            type="button"
            aria-label="Close navigation"
        >✕</button>
    </div>

    <div class="sidebar-label">MAIN MENU</div>

    <nav class="sidebar-nav">

        <a class="side-link" href="dashboard.php">
            <span class="side-icon">⌂</span>
            <span class="link-text">Dashboard</span>
        </a>

        <a class="side-link active" href="internships.php" aria-current="page">
            <span class="side-icon">▤</span>
            <span class="link-text">My Internships</span>
            <span class="side-badge"><?= $totalJobs ?></span>
        </a>

        <a class="side-link" href="add_internship.php">
            <span class="side-icon">＋</span>
            <span class="link-text">Add Internship</span>
        </a>

        <a class="side-link" href="applicants.php">
            <span class="side-icon">♙</span>
            <span class="link-text">Applicants</span>
            <span class="side-badge"><?= $totalApplicants ?></span>
        </a>

        <button class="side-link" id="sidebarNotificationToggle" type="button"
                style="width:100%;text-align:left;background-color:transparent;cursor:pointer;">
            <span class="side-icon">♧</span>
            <span class="link-text">Notifications</span>
            <span class="side-icon" style="color:var(--orange-light)">↗</span>
        </button>

    </nav>

    <div class="sidebar-label">WORKSPACE</div>

    <div class="sidebar-promo">
        <div class="promo-icon">✦</div>
        <strong>Build your next team</strong>
        <p>Post opportunities, review applications, and connect with talented students.</p>
    </div>

    <div class="sidebar-spacer"></div>

    <div class="sidebar-bottom">
        <a class="side-link logout-link" href="../logout.php">
            <span class="side-icon">⇥</span>
            <span class="link-text">Logout</span>
        </a>

        <div class="sidebar-user">
            <div class="user-avatar">C</div>
            <div class="user-info">
                <strong>Company Account</strong>
                <span>Recruitment workspace</span>
            </div>
        </div>
    </div>

</aside>

<!-- ==================================================
     MOBILE TOP BAR
================================================== -->

<header class="mobile-topbar">

    <button
        class="mobile-menu-btn"
        id="mobileMenuToggle"
        type="button"
        aria-label="Open navigation"
        aria-expanded="false"
        aria-controls="sidebar"
    >
        <svg width="22" height="22" viewBox="0 0 24 24"
             fill="none" stroke="currentColor" stroke-width="2"
             stroke-linecap="round" aria-hidden="true">
            <path d="M4 6h16M4 12h16M4 18h16"/>
        </svg>
    </button>

    <a class="brand" href="dashboard.php">
        Career<span>Bridge.</span>
    </a>

    <button
        class="mobile-notice"
        id="mobileNotificationToggle"
        type="button"
        aria-label="Open notifications"
        aria-expanded="false"
    >♧</button>

</header>

<!-- ==================================================
     NOTIFICATION PANEL
================================================== -->

<section
    class="notification-panel"
    id="notificationPanel"
    aria-label="Company notifications"
    aria-hidden="true"
    inert
>
    <div class="notification-heading">
        <div>
            <h2>Notifications</h2>
            <p>Your company workspace summary</p>
        </div>

        <button
            class="panel-close"
            id="notificationClose"
            type="button"
            aria-label="Close notifications"
        >✕</button>
    </div>

    <?php if (isset($_GET['added'])): ?>
    <div class="notice-item">
        <div class="notice-icon">✓</div>
        <div>
            <strong>Internship published</strong>
            <p>Your internship has been added to your listings.</p>
            <a class="notice-link" href="internships.php">View listings ↗</a>
        </div>
    </div>
    <?php endif; ?>

    <div class="notice-item">
        <div class="notice-icon">✦</div>
        <div>
            <strong>Internship overview</strong>
            <p>
                You currently have <?= $totalJobs ?>
                posted internship<?= $totalJobs === 1 ? '' : 's' ?>.
            </p>
            <a class="notice-link" href="#internshipListings">View internships ↗</a>
        </div>
    </div>

    <div class="notice-item">
        <div class="notice-icon">♧</div>
        <div>
            <strong>Applicant overview</strong>
            <p>
                Your listings have received <?= $totalApplicants ?>
                application<?= $totalApplicants === 1 ? '' : 's' ?>.
            </p>
            <a class="notice-link" href="applicants.php">Review applicants ↗</a>
        </div>
    </div>

    <div class="notice-item">
        <div class="notice-icon">◷</div>
        <div>
            <strong>Open opportunities</strong>
            <p>
                <?= $openDeadlines ?>
                internship<?= $openDeadlines === 1 ? '' : 's' ?>
                have no deadline or a deadline that has not passed.
            </p>
            <a class="notice-link" href="#internshipListings">Check listings ↗</a>
        </div>
    </div>
</section>

<!-- ==================================================
     MAIN CONTENT
================================================== -->

<main class="main-content">
<div class="content-inner">

    <header class="page-head">
        <div>
            <div class="eyebrow">
                <span class="pulse-dot"></span>
                COMPANY WORKSPACE
            </div>

            <h1>My <span>Internships.</span></h1>

            <p class="subtitle">
                Manage your opportunities, track applicants,
                and connect with talented students.
            </p>
        </div>

        <a href="add_internship.php" class="btn btn-primary">
            <span>＋</span> Add Internship
        </a>
    </header>

    <?php if (isset($_GET['added'])): ?>
    <div class="alert-success" role="status">
        <div class="alert-icon">✓</div>
        <div>
            <strong>Internship published successfully!</strong><br>
            Your internship has been added to your listings.
        </div>
    </div>
    <?php endif; ?>

    <!-- STATISTICS -->
    <section class="stats-grid" aria-label="Internship statistics">

        <div class="stat-card">
            <div class="stat-label">Total Internships</div>
            <div class="stat-number orange" data-count="<?= $totalJobs ?>">0</div>
            <div class="stat-caption">Internships you have posted</div>
        </div>

        <div class="stat-card">
            <div class="stat-label">Total Applicants</div>
            <div class="stat-number" data-count="<?= $totalApplicants ?>">0</div>
            <div class="stat-caption">Applications received across your listings</div>
        </div>

        <div class="stat-card">
            <div class="stat-label">Open Opportunities</div>
            <div class="stat-number" data-count="<?= $openDeadlines ?>">0</div>
            <div class="stat-caption">No deadline or deadline not passed</div>
        </div>

    </section>

    <!-- INTERNSHIP LIST -->
    <div class="section-head" id="internshipListings">
        <h2>Your Posted Internships</h2>
        <span class="section-count">
            <?= $totalJobs ?>
            listing<?= $totalJobs === 1 ? '' : 's' ?>
        </span>
    </div>

    <?php if (empty($jobs)): ?>

    <section class="empty-state">
        <div class="empty-icon">✦</div>
        <h3>No Internships Yet</h3>
        <p>
            You haven't posted any internships. Create your first
            opportunity to start receiving student applications.
        </p>
        <a href="add_internship.php" class="btn btn-primary">
            ＋ Post Your First Internship
        </a>
    </section>

    <?php else: ?>

    <section class="jobs-grid">

        <?php foreach ($jobs as $index => $j): ?>

            <?php
                $deadline = $j['deadline'] ?? null;
                $isClosed = !empty($deadline) && $deadline < $today;

                $deadlineText = empty($deadline)
                    ? 'Open'
                    : ($isClosed ? 'Deadline passed' : 'Open');

                $description = trim((string) ($j['description'] ?? ''));
                $skillsText = trim((string) ($j['skills_required'] ?? ''));

                $skillsList = $skillsText !== ''
                    ? array_slice(
                        array_filter(
                            array_map('trim', explode(',', $skillsText)),
                            fn($skill) => $skill !== ''
                        ),
                        0,
                        8
                    )
                    : [];

                if (function_exists('mb_strlen') && function_exists('mb_substr')) {
                    $shortDescription = mb_strlen($description) > 220
                        ? mb_substr($description, 0, 220) . '...'
                        : ($description ?: 'No description provided.');
                } else {
                    $shortDescription = strlen($description) > 220
                        ? substr($description, 0, 220) . '...'
                        : ($description ?: 'No description provided.');
                }
            ?>

            <article
                class="job-card"
                style="animation-delay: <?= min($index * 0.09, 0.6) ?>s"
            >

                <div class="job-top">
                    <div class="job-icon">✦</div>

                    <span class="deadline-badge <?= $isClosed ? 'closed' : 'open' ?>">
                        ● <?= e($deadlineText) ?>
                    </span>
                </div>

                <h3 class="job-title"><?= e($j['title'] ?? '') ?></h3>

                <div class="job-location">
                    ⌖ <?= e($j['location'] ?: 'Location not specified') ?>
                </div>

                <p class="job-description"><?= e($shortDescription) ?></p>

                <div class="job-details">

                    <div class="detail-box">
                        <div class="detail-label">Applicants</div>
                        <div class="detail-value orange">
                            <?= (int) $j['applicant_count'] ?>
                        </div>
                    </div>

                    <div class="detail-box">
                        <div class="detail-label">Duration</div>
                        <div class="detail-value">
                            <?= e($j['duration'] ?: 'Not specified') ?>
                        </div>
                    </div>

                    <div class="detail-box">
                        <div class="detail-label">Stipend</div>
                        <div class="detail-value">
                            <?= e($j['stipend'] ?: 'Not specified') ?>
                        </div>
                    </div>

                    <div class="detail-box">
                        <div class="detail-label">Deadline</div>
                        <div class="detail-value">
                            <?php if (!empty($deadline) && strtotime($deadline) !== false): ?>
                                <?= e(date('d M Y', strtotime($deadline))) ?>
                            <?php else: ?>
                                No deadline
                            <?php endif; ?>
                        </div>
                    </div>

                </div>

                <?php if (!empty($skillsList)): ?>
                <div class="skills">
                    <?php foreach ($skillsList as $skill): ?>
                        <span class="skill-tag"><?= e($skill) ?></span>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>

                <div class="job-footer">
                    <div class="posted-date">
                        Posted on<br>
                        <strong>
                            <?php if (
                                !empty($j['created_at']) &&
                                strtotime($j['created_at']) !== false
                            ): ?>
                                <?= e(date('d M Y', strtotime($j['created_at']))) ?>
                            <?php else: ?>
                                Date unavailable
                            <?php endif; ?>
                        </strong>
                    </div>

                    <a
                        href="applicants.php?internship_id=<?= (int) $j['id'] ?>"
                        class="btn btn-primary"
                    >
                        View Applicants ↗
                    </a>
                </div>

            </article>

        <?php endforeach; ?>

    </section>

    <?php endif; ?>

    <div class="bottom-note">
        <div class="note-icon">💡</div>
        <div>
            <strong>Recruit smarter with CareerBridge</strong>
            <p>
                Keep internship descriptions clear, review applications
                regularly, and update candidate statuses from the Applicants
                page to manage your recruitment workflow.
            </p>
        </div>
    </div>

</div>
</main>

<script>
/* ==================================================
   ANIMATED COUNTERS
================================================== */

const reduceMotion = window.matchMedia(
    '(prefers-reduced-motion: reduce)'
).matches;

document.querySelectorAll('[data-count]').forEach(function (element) {
    const target = Number(element.dataset.count) || 0;

    if (reduceMotion) {
        element.textContent = target;
        return;
    }

    const duration = 1400;
    let startTime = null;

    function updateCounter(now) {
        if (startTime === null) {
            startTime = now;
        }

        const progress = Math.min((now - startTime) / duration, 1);
        const eased = 1 - Math.pow(1 - progress, 4);

        element.textContent = Math.round(target * eased);

        if (progress < 1) {
            requestAnimationFrame(updateCounter);
        }
    }

    requestAnimationFrame(updateCounter);
});

/* ==================================================
   RESPONSIVE SIDEBAR
================================================== */

const sidebar = document.getElementById('sidebar');
const sidebarOverlay = document.getElementById('sidebarOverlay');
const mobileMenuToggle = document.getElementById('mobileMenuToggle');
const sidebarClose = document.getElementById('sidebarClose');

function openSidebar() {
    sidebar.classList.add('open');
    sidebarOverlay.classList.add('visible');
    sidebarOverlay.setAttribute('aria-hidden', 'false');
    mobileMenuToggle.setAttribute('aria-expanded', 'true');
    document.body.classList.add('menu-open');
}

function closeSidebar() {
    sidebar.classList.remove('open');
    sidebarOverlay.classList.remove('visible');
    sidebarOverlay.setAttribute('aria-hidden', 'true');
    mobileMenuToggle.setAttribute('aria-expanded', 'false');
    document.body.classList.remove('menu-open');
}

mobileMenuToggle.addEventListener('click', function () {
    if (sidebar.classList.contains('open')) {
        closeSidebar();
    } else {
        openSidebar();
    }
});

sidebarClose.addEventListener('click', closeSidebar);
sidebarOverlay.addEventListener('click', closeSidebar);

sidebar.querySelectorAll('a').forEach(function (link) {
    link.addEventListener('click', function () {
        if (window.innerWidth <= 650) {
            closeSidebar();
        }
    });
});

window.addEventListener('resize', function () {
    if (window.innerWidth > 650) {
        closeSidebar();
    }
});

/* ==================================================
   NOTIFICATION PANEL
================================================== */

const notificationPanel = document.getElementById('notificationPanel');
const notificationClose = document.getElementById('notificationClose');
const sidebarNotificationToggle = document.getElementById('sidebarNotificationToggle');
const mobileNotificationToggle = document.getElementById('mobileNotificationToggle');

function setNotificationPanel(open) {
    notificationPanel.classList.toggle('open', open);
    notificationPanel.setAttribute('aria-hidden', String(!open));
    notificationPanel.inert = !open;

    sidebarNotificationToggle.setAttribute('aria-expanded', String(open));
    mobileNotificationToggle.setAttribute('aria-expanded', String(open));
}

function toggleNotifications() {
    const open = !notificationPanel.classList.contains('open');
    setNotificationPanel(open);
}

sidebarNotificationToggle.addEventListener('click', function () {
    closeSidebar();
    toggleNotifications();
});

mobileNotificationToggle.addEventListener('click', toggleNotifications);

notificationClose.addEventListener('click', function () {
    setNotificationPanel(false);
});

notificationPanel.addEventListener('click', function (event) {
    if (event.target.closest('.notice-link')) {
        setNotificationPanel(false);
    }
});

document.addEventListener('click', function (event) {
    if (
        !notificationPanel.contains(event.target) &&
        !sidebarNotificationToggle.contains(event.target) &&
        !mobileNotificationToggle.contains(event.target)
    ) {
        setNotificationPanel(false);
    }
});

/* ==================================================
   KEYBOARD ACCESSIBILITY
================================================== */

document.addEventListener('keydown', function (event) {
    if (event.key === 'Escape') {
        closeSidebar();
        setNotificationPanel(false);
    }
});

/* ==================================================
   SUCCESS MESSAGE
================================================== */

const successMessage = document.querySelector('.alert-success');

if (successMessage && !reduceMotion) {
    window.setTimeout(function () {
        successMessage.style.transition =
            'opacity .5s ease, transform .5s ease';

        successMessage.style.opacity = '0';
        successMessage.style.transform = 'translateY(-10px)';

        window.setTimeout(function () {
            successMessage.remove();
        }, 550);
    }, 4500);
}
</script>

</body>
</html>
