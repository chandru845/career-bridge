
<?php
session_start();

require_once "../config/database.php";

/* --------------------------------
   1. CHECK COMPANY LOGIN
--------------------------------- */
if (
    !isset($_SESSION['user_id'], $_SESSION['role']) ||
    $_SESSION['role'] !== 'company'
) {
    header("Location: ../login.php");
    exit;
}

/* --------------------------------
   2. DATABASE CONNECTION
--------------------------------- */
try {
    $pdo = getPDO();
} catch (Throwable $e) {
    http_response_code(500);
    exit("Database connection failed. Please check your database configuration.");
}

/* --------------------------------
   3. ACCEPT POST REQUEST ONLY
--------------------------------- */
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: applicants.php");
    exit;
}

/* --------------------------------
   4. GET FORM DATA
--------------------------------- */
$application_id = filter_input(
    INPUT_POST,
    'application_id',
    FILTER_VALIDATE_INT
);

$status = trim($_POST['status'] ?? '');

$allowed_statuses = [
    'Applied',
    'Under Review',
    'Shortlisted',
    'Interview',
    'Selected',
    'Rejected'
];

/* --------------------------------
   5. VALIDATE INPUT
--------------------------------- */
if (
    !$application_id ||
    $application_id < 1 ||
    !in_array($status, $allowed_statuses, true)
) {
    $_SESSION['flash_message'] = [
        'type' => 'error',
        'text' => 'Invalid application ID or status.'
    ];

    header("Location: applicants.php");
    exit;
}

/* --------------------------------
   6. VERIFY COMPANY OWNERSHIP
--------------------------------- */
try {
    $check = $pdo->prepare("
        SELECT a.id
        FROM applications a
        INNER JOIN internships i
            ON i.id = a.internship_id
        INNER JOIN companies c
            ON c.id = i.company_id
        WHERE a.id = ?
          AND c.user_id = ?
        LIMIT 1
    ");

    $check->execute([
        $application_id,
        $_SESSION['user_id']
    ]);

    if (!$check->fetch(PDO::FETCH_ASSOC)) {
        $_SESSION['flash_message'] = [
            'type' => 'error',
            'text' => 'Application not found or you are not authorized to update it.'
        ];

        header("Location: applicants.php");
        exit;
    }

    /* --------------------------------
       7. UPDATE APPLICATION STATUS
    --------------------------------- */
    $update = $pdo->prepare("
        UPDATE applications
        SET status = ?
        WHERE id = ?
    ");

    $update->execute([
        $status,
        $application_id
    ]);

    $_SESSION['flash_message'] = [
        'type' => 'success',
        'text' => 'Application status updated successfully to ' . $status . '.'
    ];

} catch (Throwable $e) {
    error_log("Application status update failed: " . $e->getMessage());

    $_SESSION['flash_message'] = [
        'type' => 'error',
        'text' => 'Unable to update the application status. Please try again.'
    ];
}

/* --------------------------------
   8. REDIRECT BACK TO APPLICANTS
--------------------------------- */
header("Location: applicants.php");
exit;
?>
