<?php
session_start();
require_once "../config/database.php";

if (
    !isset($_SESSION['user_id'], $_SESSION['role']) ||
    $_SESSION['role'] !== 'company'
) {
    header("Location: ../login.php");
    exit;
}

function e($value): string
{
    return htmlspecialchars(
        (string)($value ?? ''),
        ENT_QUOTES,
        'UTF-8'
    );
}

function statusClass($status): string
{
    return strtolower(str_replace(' ', '-', (string)$status));
}

try {
    $pdo = getPDO();

    $stmt = $pdo->prepare(
        "SELECT id FROM companies WHERE user_id = ? LIMIT 1"
    );
    $stmt->execute([(int)$_SESSION['user_id']]);
    $company = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$company) {
        exit("Company profile not found.");
    }

    $companyId = (int)$company['id'];

    $statuses = [
        'Applied',
        'Under Review',
        'Shortlisted',
        'Interview',
        'Selected',
        'Rejected'
    ];

    $stmt = $pdo->prepare(
        "SELECT a.*, i.title, u.name, u.email,
                s.phone, s.college, s.course, s.skills,
                s.resume
         FROM applications a
         INNER JOIN internships i ON i.id = a.internship_id
         INNER JOIN students s ON s.id = a.student_id
         INNER JOIN users u ON u.id = s.user_id
         WHERE i.company_id = ?
         ORDER BY a.id DESC"
    );

    $stmt->execute([$companyId]);
    $applications = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $countStmt = $pdo->prepare(
        "SELECT a.status, COUNT(*) AS total
         FROM applications a
         INNER JOIN internships i ON i.id = a.internship_id
         WHERE i.company_id = ?
         GROUP BY a.status"
    );

    $countStmt->execute([$companyId]);

    $counts = array_fill_keys($statuses, 0);

    foreach ($countStmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
        if (isset($counts[$row['status']])) {
            $counts[$row['status']] = (int)$row['total'];
        }
    }

    $total = count($applications);

    $filter = trim((string)($_GET['status'] ?? ''));

    if (in_array($filter, $statuses, true)) {
        $applications = array_values(array_filter(
            $applications,
            fn($app) => ($app['status'] ?? 'Applied') === $filter
        ));
    }

} catch (Throwable $e) {
    error_log($e->getMessage());
    http_response_code(500);
    exit(
        "Unable to load applicants. Check your database connection, "
        . "table names, and column names."
    );
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Applicants | CareerBridge</title>

<style>
:root {
    --orange: #ff6500;
    --orange-light: #ff9b45;
    --black: #080808;
    --panel: #131313;
    --line: #292929;
    --muted: #a5a5a5;
}

* {
    box-sizing: border-box;
}

html {
    scroll-behavior: smooth;
}

body {
    margin: 0;
    background: var(--black);
    color: #fff;
    font-family: "Segoe UI", Arial, sans-serif;
    overflow-x: hidden;
}

body::before {
    content: "";
    position: fixed;
    inset: 0;
    z-index: -1;
    pointer-events: none;
    background:
        radial-gradient(circle at 15% 15%, #ff650025, transparent 35%),
        radial-gradient(circle at 85% 80%, #ff650018, transparent 35%);
    animation: backgroundGlow 6s ease-in-out infinite alternate;
}

a {
    color: inherit;
    text-decoration: none;
}

button,
select,
input {
    font: inherit;
}

.sidebar {
    position: fixed;
    inset: 0 auto 0 0;
    width: 250px;
    padding: 25px 18px;
    background: #101010;
    border-right: 1px solid #332012;
    z-index: 1000;
    overflow-y: auto;
    animation: sidebarEnter .6s ease both;
}

.brand {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 5px 7px 32px;
    font-size: 22px;
    font-weight: 900;
}

.brand-mark {
    display: grid;
    place-items: center;
    width: 40px;
    height: 40px;
    border-radius: 12px;
    background: var(--orange);
    color: #111;
    animation: orangePulse 2.5s infinite;
}

.brand-name span,
.mobile-brand span {
    color: var(--orange);
}

.nav-label {
    margin: 15px 10px;
    color: #777;
    font-size: 10px;
    font-weight: 800;
    letter-spacing: 2px;
}

.nav-link {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 13px 12px;
    margin: 6px 0;
    border: 1px solid transparent;
    border-radius: 11px;
    color: #bdbdbd;
    font-size: 14px;
    transition: .3s ease;
}

.nav-icon {
    width: 22px;
    text-align: center;
    font-size: 18px;
}

.nav-link:hover,
.nav-link.active {
    color: var(--orange-light);
    background: #ff650016;
    border-color: #ff650055;
    transform: translateX(5px);
    box-shadow: 0 0 22px #ff650018;
}

.sidebar-bottom {
    margin-top: 30px;
    padding-top: 18px;
    border-top: 1px solid #292929;
}

.main {
    min-height: 100vh;
    margin-left: 250px;
    padding: 30px clamp(18px, 4vw, 45px) 50px;
}

.mobile-bar,
.overlay {
    display: none;
}

.page-head {
    display: flex;
    align-items: center;
    justify-content: space-between;
    flex-wrap: wrap;
    gap: 20px;
    margin: 10px 0 28px;
    animation: fadeDown .7s ease both;
}

.eyebrow {
    display: inline-block;
    margin-bottom: 12px;
    color: var(--orange-light);
    font-size: 11px;
    font-weight: 800;
    letter-spacing: 2px;
}

.page-head h1 {
    margin: 0;
    font-size: clamp(30px, 4vw, 44px);
    letter-spacing: -1px;
}

.page-head h1 span {
    color: var(--orange);
}

.page-head p {
    color: var(--muted);
    line-height: 1.6;
}

.button {
    display: inline-flex;
    justify-content: center;
    align-items: center;
    padding: 11px 16px;
    border: 1px solid transparent;
    border-radius: 9px;
    background: var(--orange);
    color: #111;
    font-weight: 800;
    cursor: pointer;
    transition: .25s ease;
}

.button:hover {
    background: var(--orange-light);
    transform: translateY(-3px);
    box-shadow: 0 8px 25px #ff650040;
}

.button.secondary {
    background: #191919;
    border-color: #393939;
    color: #eee;
}

.stats {
    display: grid;
    grid-template-columns: repeat(4, minmax(0, 1fr));
    gap: 15px;
    margin-bottom: 24px;
}

.stat {
    position: relative;
    overflow: hidden;
    padding: 22px;
    border: 1px solid #303030;
    border-radius: 15px;
    background: linear-gradient(145deg, #191919, #101010);
    animation: riseIn .7s ease both;
    transition: .3s ease;
}

.stat:nth-child(2) { animation-delay: .1s; }
.stat:nth-child(3) { animation-delay: .2s; }
.stat:nth-child(4) { animation-delay: .3s; }

.stat::after {
    content: "";
    position: absolute;
    top: -40px;
    right: -40px;
    width: 100px;
    height: 100px;
    border-radius: 50%;
    background: #ff650020;
    transition: .5s;
}

.stat:hover {
    transform: translateY(-7px);
    border-color: var(--orange);
    box-shadow: 0 12px 35px #ff650018;
}

.stat:hover::after {
    transform: scale(1.8);
}

.stat-label {
    color: #aaa;
    font-size: 12px;
}

.stat-number {
    margin-top: 12px;
    font-size: 32px;
    font-weight: 900;
}

.orange {
    color: var(--orange);
}

.stat-note {
    margin-top: 6px;
    color: #777;
    font-size: 11px;
}

.filters {
    display: flex;
    align-items: center;
    gap: 10px;
    flex-wrap: wrap;
    margin-bottom: 20px;
    padding: 14px;
    border: 1px solid var(--line);
    border-radius: 13px;
    background: var(--panel);
    animation: riseIn .7s .15s both;
}

.filters select,
.status-form select {
    min-height: 42px;
    padding: 0 12px;
    border: 1px solid #363636;
    border-radius: 8px;
    background: #0b0b0b;
    color: white;
    outline: none;
    transition: .25s;
}

.filters select:focus,
.status-form select:focus {
    border-color: var(--orange);
    box-shadow: 0 0 0 3px #ff650020;
}

.result-count {
    margin-left: auto;
    color: var(--muted);
    font-size: 12px;
}

.applicant {
    position: relative;
    display: grid;
    grid-template-columns: minmax(0, 1fr) 210px;
    gap: 22px;
    margin-bottom: 15px;
    padding: 22px;
    overflow: hidden;
    border: 1px solid #292929;
    border-radius: 15px;
    background: linear-gradient(135deg, #171717, #101010);
    animation: riseIn .65s ease both;
    transition: .3s ease;
}

.applicant::before {
    content: "";
    position: absolute;
    top: 0;
    bottom: 0;
    left: 0;
    width: 3px;
    background: linear-gradient(transparent, var(--orange), transparent);
    opacity: 0;
    transition: .3s;
}

.applicant:hover {
    transform: translateY(-5px);
    border-color: #ff650077;
    box-shadow: 0 15px 35px #ff650018;
}

.applicant:hover::before {
    opacity: 1;
}

.candidate-top {
    display: flex;
    align-items: flex-start;
    gap: 13px;
}

.avatar {
    display: grid;
    flex: 0 0 48px;
    place-items: center;
    width: 48px;
    height: 48px;
    border: 1px solid #ff650055;
    border-radius: 13px;
    background: #ff650018;
    color: var(--orange-light);
    font-size: 19px;
    font-weight: 900;
    transition: .3s;
}

.applicant:hover .avatar {
    transform: scale(1.08) rotate(-5deg);
    box-shadow: 0 0 25px #ff650025;
}

.candidate-name {
    margin: 0 0 6px;
    font-size: 19px;
    overflow-wrap: anywhere;
}

.muted {
    color: var(--muted);
    font-size: 13px;
    line-height: 1.6;
    overflow-wrap: anywhere;
}

.details {
    display: flex;
    flex-wrap: wrap;
    gap: 8px 18px;
    margin-top: 17px;
    color: #ccc;
    font-size: 12px;
}

.details strong {
    color: #fff;
}

.skills {
    margin-top: 15px;
    color: #ccc;
    font-size: 13px;
    line-height: 1.7;
    overflow-wrap: anywhere;
}

.cover {
    margin-top: 14px;
    padding: 13px;
    border-left: 2px solid var(--orange);
    border-radius: 0 8px 8px 0;
    background: #191919;
    color: #bbb;
    font-size: 13px;
    line-height: 1.7;
    white-space: pre-wrap;
    overflow-wrap: anywhere;
}

.cover strong {
    display: block;
    margin-bottom: 5px;
    color: #fff;
}

.status-box {
    display: flex;
    flex-direction: column;
    align-items: stretch;
    gap: 14px;
    padding-left: 20px;
    border-left: 1px solid #2a2a2a;
}

.status {
    align-self: flex-start;
    padding: 7px 10px;
    border: 1px solid #3b3b3b;
    border-radius: 100px;
    background: #202020;
    color: #eee;
    font-size: 11px;
    font-weight: 800;
}

.status.applied { color: #f9b35c; }
.status.under-review { color: #8ec9ff; }
.status.shortlisted,
.status.interview { color: #d7a4ff; }
.status.selected { color: #74e1a0; }
.status.rejected { color: #ff8585; }

.status-form {
    display: flex;
    flex-direction: column;
    gap: 9px;
}

.status-form select {
    width: 100%;
    font-size: 12px;
}

.status-form .button {
    width: 100%;
    font-size: 12px;
}

.empty {
    padding: 45px 20px;
    border: 1px dashed #ff650055;
    border-radius: 15px;
    background: #111;
    text-align: center;
    animation: riseIn .7s ease both;
}

.empty-icon {
    color: var(--orange-light);
    font-size: 38px;
    animation: floatIcon 3s ease-in-out infinite;
}

.empty h2 {
    margin: 12px 0 8px;
}

.empty p {
    color: var(--muted);
    font-size: 13px;
}

.menu-toggle {
    display: grid;
    place-items: center;
    width: 42px;
    height: 42px;
    border: 1px solid #444;
    border-radius: 10px;
    background: #171717;
    color: var(--orange-light);
    font-size: 25px;
    cursor: pointer;
    transition: .25s;
}

.menu-toggle:hover {
    background: var(--orange);
    color: #111;
    transform: rotate(90deg);
}

@keyframes riseIn {
    from {
        opacity: 0;
        transform: translateY(24px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

@keyframes fadeDown {
    from {
        opacity: 0;
        transform: translateY(-18px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

@keyframes sidebarEnter {
    from { opacity: 0; transform: translateX(-25px); }
    to { opacity: 1; transform: translateX(0); }
}

@keyframes backgroundGlow {
    from { opacity: .5; }
    to { opacity: 1; }
}

@keyframes orangePulse {
    0%, 100% { box-shadow: 0 0 0 0 #ff650050; }
    50% { box-shadow: 0 0 0 9px #ff650000; }
}

@keyframes floatIcon {
    0%, 100% { transform: translateY(0); }
    50% { transform: translateY(-8px); }
}

@media (max-width: 1000px) {
    .stats {
        grid-template-columns: repeat(2, minmax(0, 1fr));
    }

    .applicant {
        grid-template-columns: minmax(0, 1fr) 185px;
    }
}

@media (max-width: 700px) {
    .sidebar {
        width: min(290px, 85vw);
        transform: translateX(-110%);
        visibility: hidden;
        transition: transform .35s ease, visibility .35s;
        box-shadow: 20px 0 60px #0009;
    }

    .sidebar.open {
        transform: translateX(0);
        visibility: visible;
    }

    .overlay {
        display: block;
        position: fixed;
        inset: 0;
        z-index: 900;
        background: #000b;
        opacity: 0;
        visibility: hidden;
        backdrop-filter: blur(4px);
        transition: .3s;
    }

    .overlay.show {
        opacity: 1;
        visibility: visible;
    }

    .mobile-bar {
        position: sticky;
        top: 0;
        z-index: 800;
        display: flex;
        align-items: center;
        gap: 13px;
        margin: -20px -14px 24px;
        padding: 12px 14px;
        background: #080808ed;
        border-bottom: 1px solid #ff650033;
        backdrop-filter: blur(15px);
    }

    .mobile-brand {
        font-size: 19px;
        font-weight: 900;
    }

    .main {
        margin-left: 0;
        padding: 20px 14px 35px;
    }

    .page-head {
        align-items: flex-start;
        flex-direction: column;
    }

    .page-head .button {
        width: 100%;
    }

    .applicant {
        grid-template-columns: minmax(0, 1fr);
        gap: 17px;
        padding: 17px;
    }

    .status-box {
        padding: 15px 0 0;
        border-left: 0;
        border-top: 1px solid #2a2a2a;
    }

    .status-form {
        display: grid;
        grid-template-columns: minmax(0, 1fr) auto;
        align-items: center;
    }

    .status-form .button {
        width: auto;
    }

    .filters select {
        width: 100%;
        flex: 1;
    }

    .result-count {
        width: 100%;
        margin: 3px 0 0;
    }
}

@media (max-width: 430px) {
    .stats {
        gap: 10px;
    }

    .stat {
        padding: 15px;
    }

    .stat-number {
        font-size: 26px;
    }

    .applicant {
        padding: 15px;
    }
}

@media (prefers-reduced-motion: reduce) {
    *,
    *::before,
    *::after {
        animation-duration: .01ms !important;
        animation-iteration-count: 1 !important;
        transition-duration: .01ms !important;
        scroll-behavior: auto !important;
    }
}
</style>
</head>

<body>

<aside class="sidebar" id="sidebar">
    <a class="brand" href="dashboard.php">
        <span class="brand-mark">C</span>
        <span class="brand-name">Career<span>Bridge</span></span>
    </a>

    <div class="nav-label">WORKSPACE</div>

    <a class="nav-link" href="dashboard.php">
        <span class="nav-icon">⌂</span> Dashboard
    </a>

    <a class="nav-link" href="add_internship.php">
        <span class="nav-icon">＋</span> Post Internship
    </a>

    <a class="nav-link" href="internships.php">
        <span class="nav-icon">▤</span> My Internships
    </a>

    <a class="nav-link active" href="applicants.php">
        <span class="nav-icon">♙</span> Applicants
    </a>

    <div class="sidebar-bottom">
        <div class="nav-label">ACCOUNT</div>

        <a class="nav-link" href="../logout.php">
            <span class="nav-icon">↪</span> Logout
        </a>
    </div>
</aside>

<div class="overlay" id="overlay" onclick="closeMenu()"></div>

<main class="main">

    <div class="mobile-bar">
        <button
            class="menu-toggle"
            id="menuToggle"
            type="button"
            aria-label="Open menu"
            aria-expanded="false"
            onclick="toggleMenu()"
        >☰</button>

        <a class="mobile-brand" href="dashboard.php">
            Career<span>Bridge</span>
        </a>
    </div>

    <header class="page-head">
        <div>
            <span class="eyebrow">CANDIDATE MANAGEMENT</span>
            <h1>Manage <span>Applicants.</span></h1>
            <p>Review candidates and manage their application progress.</p>
        </div>

        <a class="button secondary" href="internships.php">
            ← My Internships
        </a>
    </header>

    <section class="stats">

        <div class="stat">
            <div class="stat-label">Total Applicants</div>
            <div class="stat-number orange"><?= $total ?></div>
            <div class="stat-note">All applications received</div>
        </div>

        <div class="stat">
            <div class="stat-label">Under Review</div>
            <div class="stat-number"><?= $counts['Under Review'] ?></div>
            <div class="stat-note">Awaiting evaluation</div>
        </div>

        <div class="stat">
            <div class="stat-label">Shortlisted</div>
            <div class="stat-number"><?= $counts['Shortlisted'] ?></div>
            <div class="stat-note">Potential candidates</div>
        </div>

        <div class="stat">
            <div class="stat-label">Selected</div>
            <div class="stat-number"><?= $counts['Selected'] ?></div>
            <div class="stat-note">Successful applicants</div>
        </div>

    </section>

    <form class="filters" method="GET" action="applicants.php">

        <select name="status" aria-label="Filter by status">
            <option value="">All application statuses</option>

            <?php foreach ($statuses as $status): ?>
                <option
                    value="<?= e($status) ?>"
                    <?= $filter === $status ? 'selected' : '' ?>
                >
                    <?= e($status) ?>
                </option>
            <?php endforeach; ?>
        </select>

        <button class="button" type="submit">Apply Filter</button>

        <a class="button secondary" href="applicants.php">Clear</a>

        <span class="result-count">
            Showing <?= count($applications) ?> applicant(s)
        </span>

    </form>

    <?php if (empty($applications)): ?>

        <section class="empty">
            <div class="empty-icon">♙</div>
            <h2>No applicants found</h2>
            <p>Student applications will appear here when they apply.</p>
        </section>

    <?php else: ?>

        <?php foreach ($applications as $app): ?>

            <?php
                $name = (string)($app['name'] ?? 'Student');
                $initial = strtoupper(substr($name, 0, 1));
                $status = $app['status'] ?? 'Applied';
            ?>

            <article class="applicant">

                <div>
                    <div class="candidate-top">
                        <div class="avatar"><?= e($initial) ?></div>

                        <div>
                            <h2 class="candidate-name">
                                <?= e($name) ?>
                            </h2>

                            <div class="muted">
                                <?= e($app['email'] ?? '') ?>
                            </div>
                        </div>
                    </div>

                    <div class="details">
                        <span>
                            <strong>Internship:</strong>
                            <?= e($app['title'] ?? '') ?>
                        </span>

                        <?php if (!empty($app['phone'])): ?>
                            <span>
                                <strong>Phone:</strong>
                                <?= e($app['phone']) ?>
                            </span>
                        <?php endif; ?>

                        <?php if (!empty($app['college'])): ?>
                            <span>
                                <strong>College:</strong>
                                <?= e($app['college']) ?>
                            </span>
                        <?php endif; ?>

                        <?php if (!empty($app['course'])): ?>
                            <span>
                                <strong>Course:</strong>
                                <?= e($app['course']) ?>
                            </span>
                        <?php endif; ?>
                    </div>

                    <div class="skills">
                        <strong>Skills:</strong>
                        <?= e($app['skills'] ?: 'Not provided') ?>
                    </div>

                    <div class="cover">
                        <strong>Cover Letter</strong>
                        <?= e($app['cover_letter'] ?? 'Not provided') ?>
                    </div>

                    <?php if (!empty($app['resume'])): ?>
                        <p class="muted">
                            <strong>Resume:</strong>
                            <?= e($app['resume']) ?>
                        </p>
                    <?php endif; ?>

                </div>

                <div class="status-box">

                    <span class="status <?= e(statusClass($status)) ?>">
                        <?= e($status) ?>
                    </span>

                    <form
                        class="status-form"
                        method="POST"
                        action="update_application.php"
                    >
                        <input
                            type="hidden"
                            name="application_id"
                            value="<?= (int)$app['id'] ?>"
                        >

                        <select name="status" required>
                            <?php foreach ($statuses as $option): ?>
                                <option
                                    value="<?= e($option) ?>"
                                    <?= $status === $option ? 'selected' : '' ?>
                                >
                                    <?= e($option) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>

                        <button class="button" type="submit">
                            Update Status
                        </button>
                    </form>

                </div>

            </article>

        <?php endforeach; ?>

    <?php endif; ?>

</main>

<script>
const sidebar = document.getElementById('sidebar');
const overlay = document.getElementById('overlay');
const menuToggle = document.getElementById('menuToggle');

function toggleMenu() {
    if (sidebar.classList.contains('open')) {
        closeMenu();
    } else {
        openMenu();
    }
}

function openMenu() {
    sidebar.classList.add('open');
    overlay.classList.add('show');
    document.body.style.overflow = 'hidden';

    menuToggle.textContent = '×';
    menuToggle.setAttribute('aria-expanded', 'true');
    menuToggle.setAttribute('aria-label', 'Close menu');
}

function closeMenu() {
    sidebar.classList.remove('open');
    overlay.classList.remove('show');
    document.body.style.overflow = '';

    menuToggle.textContent = '☰';
    menuToggle.setAttribute('aria-expanded', 'false');
    menuToggle.setAttribute('aria-label', 'Open menu');
}

document.addEventListener('keydown', function(event) {
    if (event.key === 'Escape') {
        closeMenu();
    }
});

window.addEventListener('resize', function() {
    if (window.innerWidth > 700) {
        closeMenu();
    }
});

sidebar.querySelectorAll('a').forEach(function(link) {
    link.addEventListener('click', function() {
        if (window.innerWidth <= 700) {
            closeMenu();
        }
    });
});

/* Animated statistic counters */
document.querySelectorAll('.stat-number').forEach(function(element) {
    const target = Number(element.textContent) || 0;
    const startTime = performance.now();
    const duration = 900;

    function animateCounter(now) {
        const progress = Math.min((now - startTime) / duration, 1);
        const eased = 1 - Math.pow(1 - progress, 3);

        element.textContent = Math.round(target * eased);

        if (progress < 1) {
            requestAnimationFrame(animateCounter);
        }
    }

    element.textContent = '0';
    requestAnimationFrame(animateCounter);
});
</script>

</body>
</html>