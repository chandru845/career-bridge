# InternHub - Internship Portal

## Architecture

- Student: Register, Login, Profile, Skills, Resume Upload, Search Internships, Apply, Track Application
- Company/Admin: Register, Login, Add Internship, View Applicants, Update Status
- Database: users, students, companies, internships, applications
- Technologies: PHP, MySQL, PDO, Sessions, CRUD, Relationships, Joins, Forms, File Upload, Search/Filter

## Setup

1. Create a MySQL database by importing `database.sql`.
2. Open `config/database.php`.
3. Change `$host`, `$dbname`, `$username`, and `$password` to match your server.
4. Put the complete `internship-portal` folder inside your web server directory.
5. Open `http://localhost/internship-portal/`.
6. Register a Student and a Company account.
7. Login as Company and create an internship.
8. Login as Student, complete the profile, search and apply.
9. Login as Company and update the applicant status.

## Important

- `users.password` is VARCHAR(255) because `password_hash()` output must not be stored in a short column.
- The portal uses prepared PDO statements.
- Student resume uploads are limited to PDF/DOC/DOCX and 5 MB.
- Create an `uploads/resumes` directory if your server does not allow PHP to create it automatically.
- For production, add CSRF protection, HTTPS, stricter upload MIME validation, and server-side authorization hardening.
